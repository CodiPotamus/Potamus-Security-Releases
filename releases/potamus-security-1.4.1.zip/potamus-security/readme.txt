=== Potamus Security ===
Contributors: codipotamus
Tags: segurança, security, login, hide wordpress, hardening
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.4.1
License: GPLv2 or later

Segurança leve e simples para WordPress.

== Description ==

O Potamus Security protege o site sem o tornar mais lento:

* Esconde que o site usa WordPress (versões, assinaturas, cabeçalhos, readme.html).
* Endereço de login personalizado: o wp-login.php e o /wp-admin deixam de existir para visitantes.
* Limite de tentativas de login contra ataques de força bruta.
* Mensagens de erro neutras e nomes de utilizador escondidos.
* Desativa o XML-RPC e controla a API REST.
* Cabeçalhos de segurança, editor de ficheiros desligado e PHP bloqueado na pasta de uploads.
* Proteção de ficheiros sensíveis (wp-config.php, .env, .git, debug.log, cópias de segurança) e listagem de pastas desligada.
* Verificação em dois passos (2FA) com app de autenticação e códigos de recuperação.
* Verificação de integridade dos ficheiros do WordPress, a pedido ou semanal, com inspeção de ficheiros suspeitos.
* Personalização da página de login: logótipo e link, fundo (cor, degradê ou imagem), cantos arredondados e cores, com pré-visualização ao vivo.

Porque é leve:

* Sem tabelas novas na base de dados.
* A única ligação externa é ao WordPress.org, na verificação de integridade (a pedido ou uma vez por semana, desligável).
* As regras de bloqueio ficam no .htaccess (Apache/LiteSpeed) e são aplicadas pelo servidor antes de o WordPress arrancar.
* Cada funcionalidade desligada não corre de todo.
* Os estilos e scripts só carregam na página do próprio plugin.

== Ficou sem acesso? ==

Acrescente esta linha ao wp-config.php, acima de "That's all, stop editing!":

define( 'POTAMUS_SECURITY_RECOVERY', true );

O endereço de login volta a ser o wp-login.php e a verificação em dois passos deixa de ser pedida. Depois de entrar, remova a linha.
Em alternativa, mude o nome da pasta wp-content/plugins/potamus-security pelo Gestor de Ficheiros do alojamento.

== Changelog ==

= 1.4.1 =
* Quando ainda não há nenhuma versão nova publicada, o separador Atualizações mostra "Está na versão mais recente" em vez de um erro 404.
* Primeira versão distribuída pelo canal de atualizações assinadas.

= 1.4.0 =
* Novo: atualizações automáticas assinadas digitalmente (Ed25519), publicadas em CodiPotamus/potamus-security-releases.
* Novo: definições de ameaças diárias, também assinadas, com avisos de plugins e temas com vulnerabilidades conhecidas.
* Novo: separador "Atualizações".

= 1.3.0 =
* Novo: separador "Aparência do login" para personalizar logótipo, link, fundo, cantos arredondados e cores da página de login, com pré-visualização ao vivo.

= 1.2.1 =
* A inspeção de ficheiros abre numa janela (lightbox) sem sair da página.

= 1.2.0 =
* Novo: botão "Inspecionar" nos ficheiros encontrados pela verificação de integridade. Lê o ficheiro como texto (sem o executar), procura padrões de código malicioso e mostra o conteúdo.

= 1.1.4 =
* Corrigido: sites instalados em inglês e depois mudados para outra língua já não mostram falsos alertas na verificação de integridade (aceita-se a lista oficial da língua ou a inglesa).

= 1.1.3 =
* A nota sobre ficheiros traduzidos mostra a língua real do site em vez de assumir português.

= 1.1.2 =
* Corrigido: no WordPress traduzido (ex.: português), a verificação de integridade já não marca como alterados os ficheiros que a tradução muda (version.php, wp-config-sample.php, readme.html). Esses ficheiros passam a ser analisados à procura de código suspeito.
* Segurança: a versão do WordPress é lida sem executar o version.php.

= 1.1.1 =
* Novo slogan no painel.

= 1.1.0 =
* Novo: verificação em dois passos (2FA), opcionalmente obrigatória para administradores.
* Novo: verificação de integridade do WordPress (manual e semanal).
* Novo: proteção de ficheiros sensíveis e listagem de pastas desligada.
* Novo: autoteste do .htaccess, que repõe a versão anterior se o site der erro.
* Novo: mais verificações no Painel (registo de utilizadores, wp-config.php, debug.log, prefixo das tabelas).

= 1.0.0 =
* Primeira versão.
