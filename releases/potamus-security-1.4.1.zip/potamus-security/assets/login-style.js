/* Potamus Security — aparência do login: seletores de cor, imagens e pré-visualização ao vivo */
(function ($) {
	var panel = document.querySelector('[data-panel="appearance"]');
	var lp = document.getElementById('psec-lp');
	if (!panel || !lp || !window.PotamusLS) return;

	var defaults = PotamusLS.defaults;

	function field(key) {
		return panel.querySelector('[name$="[' + key + ']"]:not([type=radio])');
	}
	function val(key) {
		var f = field(key);
		return f ? f.value : defaults[key];
	}
	function bgType() {
		var r = panel.querySelector('[name$="[ls_bg_type]"]:checked');
		return r ? r.value : 'color';
	}
	function mediaUrl(key) {
		var f = field(key);
		return f && Number(f.value) ? f.dataset.url : '';
	}

	function update() {
		var type = bgType();
		var bg = val('ls_bg_color');
		var bgCss = bg;
		if (type === 'gradient') bgCss = 'linear-gradient(135deg,' + bg + ' 0%,' + val('ls_bg_color2') + ' 100%)';
		var img = type === 'image' ? mediaUrl('ls_bg_image_id') : '';
		if (img) bgCss = 'url("' + img + '") center/cover no-repeat, ' + bg;

		var s = lp.style;
		s.setProperty('--lp-bg', bgCss);
		s.setProperty('--lp-overlay', img ? (Number(val('ls_bg_overlay')) / 100) : 0);
		s.setProperty('--lp-form-bg', val('ls_form_bg'));
		s.setProperty('--lp-text', val('ls_text'));
		s.setProperty('--lp-input-bg', val('ls_input_bg'));
		s.setProperty('--lp-input-border', val('ls_input_border'));
		s.setProperty('--lp-btn', val('ls_button_bg'));
		s.setProperty('--lp-btn-text', val('ls_button_text'));
		s.setProperty('--lp-link', val('ls_link'));
		s.setProperty('--lp-accent', val('ls_accent'));
		s.setProperty('--lp-rb', val('ls_radius_box') + 'px');
		s.setProperty('--lp-rf', val('ls_radius_fields') + 'px');

		// Logótipo: a pré-visualização é ~85% do tamanho real.
		var logo = mediaUrl('ls_logo_id');
		var imgEl = lp.querySelector('.psec-lp__logo img');
		var svgEl = lp.querySelector('.psec-lp__logo svg');
		var w = Math.round(Number(val('ls_logo_width')) * 0.85);
		if (logo) {
			imgEl.src = logo;
			imgEl.style.width = w + 'px';
			imgEl.hidden = false;
			svgEl.style.display = 'none';
		} else {
			imgEl.hidden = true;
			svgEl.style.display = '';
			svgEl.style.width = w + 'px';
		}

		panel.querySelectorAll('.psec-when').forEach(function (el) {
			el.hidden = el.dataset.when !== type;
		});
	}

	// Seletores de cor do WordPress.
	$(panel).find('.psec-color').wpColorPicker({
		change: function (e, ui) {
			e.target.value = ui.color.toString();
			update();
		},
		clear: function () {
			setTimeout(update, 0);
		}
	});

	// Barras deslizantes.
	panel.querySelectorAll('.psec-range input').forEach(function (r) {
		r.addEventListener('input', function () {
			r.parentNode.querySelector('output').textContent = r.value + r.dataset.unit;
			update();
		});
	});

	panel.querySelectorAll('[name$="[ls_bg_type]"]').forEach(function (r) {
		r.addEventListener('change', update);
	});

	// Imagens da biblioteca de multimédia.
	function setMedia(box, id, url) {
		var input = box.querySelector('input[type=hidden]');
		var thumb = box.querySelector('.psec-media__thumb');
		input.value = id || 0;
		input.dataset.url = url || '';
		thumb.innerHTML = '';
		if (url) {
			var im = document.createElement('img');
			im.src = url;
			im.alt = '';
			thumb.appendChild(im);
		} else {
			var sp = document.createElement('span');
			sp.textContent = box.dataset.key === 'ls_logo_id' ? 'Logótipo do WordPress' : 'Sem imagem';
			thumb.appendChild(sp);
		}
		box.querySelector('.psec-media__remove').hidden = !url;
		update();
	}

	panel.querySelectorAll('.psec-media').forEach(function (box) {
		var frame;
		box.querySelector('.psec-media__pick').addEventListener('click', function () {
			if (!window.wp || !wp.media) return;
			if (!frame) {
				frame = wp.media({
					title: box.dataset.key === 'ls_logo_id' ? 'Escolher logótipo' : 'Escolher imagem de fundo',
					button: { text: 'Usar esta imagem' },
					library: { type: 'image' },
					multiple: false
				});
				frame.on('select', function () {
					var a = frame.state().get('selection').first().toJSON();
					var url = (a.sizes && a.sizes.large && a.sizes.large.url) || a.url;
					setMedia(box, a.id, url);
				});
			}
			frame.open();
		});
		box.querySelector('.psec-media__remove').addEventListener('click', function () {
			setMedia(box, 0, '');
		});
	});

	// Repor o aspeto do WordPress (não mexe no interruptor nem no link do logótipo).
	var reset = panel.querySelector('.psec-ls-reset');
	if (reset) {
		reset.addEventListener('click', function () {
			$(panel).find('.psec-color').each(function () {
				$(this).wpColorPicker('color', defaults[this.dataset.key]);
			});
			panel.querySelectorAll('.psec-range input').forEach(function (r) {
				r.value = defaults[r.dataset.key];
				r.parentNode.querySelector('output').textContent = r.value + r.dataset.unit;
			});
			var radio = panel.querySelector('[name$="[ls_bg_type]"][value="color"]');
			if (radio) radio.checked = true;
			panel.querySelectorAll('.psec-media').forEach(function (box) { setMedia(box, 0, ''); });
			reset.textContent = 'Reposto — falta guardar';
			update();
		});
	}

	update();
})(jQuery);
