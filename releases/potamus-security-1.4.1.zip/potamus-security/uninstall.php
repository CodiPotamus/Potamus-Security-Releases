<?php
/**
 * Limpeza ao apagar o plugin: remove as definições e as regras do .htaccess.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'potamus_security' );
delete_option( 'potamus_security_htaccess' );
delete_option( 'potamus_security_lockouts' );
delete_option( 'potamus_security_integrity' );
delete_option( 'potamus_security_definitions' );
delete_option( 'potamus_security_updates_status' );
delete_site_transient( 'potamus_security_manifest' );
wp_clear_scheduled_hook( 'potamus_security_definitions_cron' );
wp_clear_scheduled_hook( 'potamus_security_integrity_cron' );
delete_metadata( 'user', 0, '_potamus_2fa_secret', '', true );
delete_metadata( 'user', 0, '_potamus_2fa_enabled', '', true );
delete_metadata( 'user', 0, '_potamus_2fa_pending', '', true );
delete_metadata( 'user', 0, '_potamus_2fa_backup', '', true );
delete_metadata( 'user', 0, '_potamus_2fa_last', '', true );

require_once ABSPATH . 'wp-admin/includes/file.php';
require_once ABSPATH . 'wp-admin/includes/misc.php';
$potamus_file = get_home_path() . '.htaccess';
if ( file_exists( $potamus_file ) && wp_is_writable( $potamus_file ) ) {
	insert_with_markers( $potamus_file, 'Potamus Security', array() );
}

global $wpdb;
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_psec\_%' OR option_name LIKE '\_transient\_timeout\_psec\_%'" ); // phpcs:ignore
