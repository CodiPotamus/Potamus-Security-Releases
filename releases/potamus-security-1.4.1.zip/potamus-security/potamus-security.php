<?php
/**
 * Plugin Name:       Potamus Security
 * Description:       Segurança leve e simples para WordPress: esconde que o site usa WordPress, protege o login e fecha portas desnecessárias, sem pesar no site.
 * Version:           1.4.1
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            CodiPotamus
 * Author URI:        https://codipotamus.site
 * License:           GPL-2.0-or-later
 * Text Domain:       potamus-security
 * Update URI:        https://github.com/CodiPotamus/potamus-security-releases
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'POTAMUS_SECURITY_VERSION', '1.4.1' );
define( 'POTAMUS_SECURITY_FILE', __FILE__ );
define( 'POTAMUS_SECURITY_DIR', plugin_dir_path( __FILE__ ) );
define( 'POTAMUS_SECURITY_URL', plugin_dir_url( __FILE__ ) );

/*
 * Canal de atualizações (preenchido pela CodiPotamus antes de distribuir o plugin).
 * - POTAMUS_UPDATE_REPO: "utilizador/repositório" público no GitHub com update.json e definitions.json.
 * - POTAMUS_SIGNING_PUBLIC_KEY: chave PÚBLICA (base64) gerada no Potamus Assinador.
 *   A chave PRIVADA nunca é colocada aqui nem no GitHub.
 * Enquanto estiverem vazios, as atualizações automáticas e as definições ficam desligadas.
 */
if ( ! defined( 'POTAMUS_UPDATE_REPO' ) ) {
	define( 'POTAMUS_UPDATE_REPO', 'CodiPotamus/potamus-security-releases' );
}
if ( ! defined( 'POTAMUS_SIGNING_PUBLIC_KEY' ) ) {
	define( 'POTAMUS_SIGNING_PUBLIC_KEY', 'AM+eE/+l2EqidcWCbfMp5oL0P+HPoLHR6K2hs8vG8eQ=' );
}

require_once POTAMUS_SECURITY_DIR . 'includes/class-potamus-settings.php';
require_once POTAMUS_SECURITY_DIR . 'includes/class-potamus-htaccess.php';
require_once POTAMUS_SECURITY_DIR . 'includes/class-potamus-hardening.php';
require_once POTAMUS_SECURITY_DIR . 'includes/class-potamus-login.php';
require_once POTAMUS_SECURITY_DIR . 'includes/class-potamus-twofa.php';
require_once POTAMUS_SECURITY_DIR . 'includes/class-potamus-integrity.php';
require_once POTAMUS_SECURITY_DIR . 'includes/class-potamus-login-style.php';
require_once POTAMUS_SECURITY_DIR . 'includes/class-potamus-updates.php';

// Os módulos ligam-se apenas ao que está ativo nas definições: o que está desligado não corre.
Potamus_Hardening::init();
Potamus_Login::init();
Potamus_TwoFA::init();
Potamus_Integrity::init();
Potamus_Login_Style::init();
Potamus_Updates::init();

if ( is_admin() ) {
	require_once POTAMUS_SECURITY_DIR . 'includes/class-potamus-admin.php';
	Potamus_Admin::init();
}

register_activation_hook( __FILE__, array( 'Potamus_Settings', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Potamus_Settings', 'deactivate' ) );
