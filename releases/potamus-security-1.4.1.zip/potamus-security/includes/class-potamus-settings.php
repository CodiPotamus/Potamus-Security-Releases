<?php
/**
 * Definições: valores por defeito, leitura e validação.
 * Tudo fica numa única opção, carregada uma vez por pedido.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Potamus_Settings {

	const OPTION = 'potamus_security';

	private static $cache = null;

	/** Valores recomendados. O URL de login começa desligado para ninguém ficar trancado de fora. */
	public static function defaults() {
		return array(
			// Ocultar WordPress.
			'hide_versions'      => 1,
			'clean_head'         => 1,
			'strip_generators'   => 1,
			'block_files'        => 1,
			'block_author_enum'  => 1,
			// Acesso e login.
			'login_enabled'      => 0,
			'login_slug'         => 'entrar',
			'limit_login'        => 1,
			'max_attempts'       => 5,
			'lockout_minutes'    => 30,
			'generic_errors'     => 1,
			'twofa_enabled'      => 1,
			'twofa_force_admins' => 0,
			'ip_source'          => 'remote_addr',
			// Proteções.
			'disable_xmlrpc'     => 1,
			'rest_mode'          => 'users',
			'rest_allow'         => "contact-form-7",
			'security_headers'   => 1,
			'disable_file_edit'  => 1,
			'block_uploads_php'  => 1,
			'protect_sensitive'  => 1,
			'disable_indexes'    => 1,
			// Integridade.
			'integrity_weekly'   => 1,
			// Atualizações.
			'auto_update_self'   => 1,
			'definitions_daily'  => 1,
		) + Potamus_Login_Style::defaults();
	}

	public static function all() {
		if ( null === self::$cache ) {
			$saved       = get_option( self::OPTION, array() );
			self::$cache = wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
		}
		return self::$cache;
	}

	public static function get( $key ) {
		$all = self::all();
		return isset( $all[ $key ] ) ? $all[ $key ] : null;
	}

	public static function flush_cache() {
		self::$cache = null;
	}

	/** Palavras que não podem ser usadas como endereço de login. */
	public static function reserved_slugs() {
		return array( 'wp-admin', 'wp-login', 'wp-login.php', 'login', 'admin', 'dashboard', 'wp-content', 'wp-includes', 'wp-json', 'feed', 'comments', 'xmlrpc', 'xmlrpc.php', 'wp-cron', 'sitemap', 'search', 'page', 'author', 'category', 'tag', '404' );
	}

	public static function sanitize( $input ) {
		$old      = self::all();
		$defaults = self::defaults();
		$input    = is_array( $input ) ? $input : array();
		$clean    = array();

		$toggles = array( 'hide_versions', 'clean_head', 'strip_generators', 'block_files', 'block_author_enum', 'login_enabled', 'limit_login', 'generic_errors', 'disable_xmlrpc', 'security_headers', 'disable_file_edit', 'block_uploads_php', 'protect_sensitive', 'disable_indexes', 'twofa_enabled', 'twofa_force_admins', 'integrity_weekly', 'auto_update_self', 'definitions_daily' );
		foreach ( $toggles as $key ) {
			$clean[ $key ] = empty( $input[ $key ] ) ? 0 : 1;
		}

		$clean['max_attempts']    = isset( $input['max_attempts'] ) ? max( 2, min( 20, absint( $input['max_attempts'] ) ) ) : $defaults['max_attempts'];
		$clean['lockout_minutes'] = isset( $input['lockout_minutes'] ) ? max( 5, min( 1440, absint( $input['lockout_minutes'] ) ) ) : $defaults['lockout_minutes'];

		$sources            = array( 'remote_addr', 'x_forwarded_for', 'x_real_ip', 'cf_connecting_ip' );
		$clean['ip_source'] = ( isset( $input['ip_source'] ) && in_array( $input['ip_source'], $sources, true ) ) ? $input['ip_source'] : 'remote_addr';

		$modes              = array( 'open', 'users', 'private' );
		$clean['rest_mode'] = ( isset( $input['rest_mode'] ) && in_array( $input['rest_mode'], $modes, true ) ) ? $input['rest_mode'] : 'users';

		$allow = isset( $input['rest_allow'] ) ? preg_split( '/[\s,]+/', (string) $input['rest_allow'] ) : array();
		$allow = array_filter( array_map( 'sanitize_key', $allow ) );
		$clean['rest_allow'] = implode( "\n", array_unique( $allow ) );

		// Endereço de login: validar para não criar conflitos com páginas existentes.
		$slug = isset( $input['login_slug'] ) ? sanitize_title( $input['login_slug'] ) : '';
		if ( '' === $slug ) {
			$slug = $old['login_slug'];
		} elseif ( in_array( $slug, self::reserved_slugs(), true ) ) {
			add_settings_error( self::OPTION, 'slug_reserved', sprintf( 'O endereço "%s" é reservado ou demasiado óbvio. Mantive o anterior.', esc_html( $slug ) ) );
			$slug = $old['login_slug'];
		} elseif ( get_page_by_path( $slug ) ) {
			add_settings_error( self::OPTION, 'slug_taken', sprintf( 'Já existe uma página com o endereço "%s". Escolha outro.', esc_html( $slug ) ) );
			$slug = $old['login_slug'];
		}
		$clean['login_slug'] = $slug;

		if ( $clean['login_enabled'] && ( ! $old['login_enabled'] || $old['login_slug'] !== $slug ) ) {
			add_settings_error(
				self::OPTION,
				'slug_changed',
				sprintf( 'O seu novo endereço de login é <strong>%s</strong> — guarde-o nos favoritos antes de sair.', esc_url( home_url( '/' . $slug . '/' ) ) ),
				'warning'
			);
		}

		return Potamus_Login_Style::sanitize( $input, $clean );
	}

	public static function activate() {
		if ( false === get_option( self::OPTION ) ) {
			add_option( self::OPTION, self::defaults() );
		}
		self::flush_cache();
		Potamus_Htaccess::write();
		Potamus_Integrity::sync_schedule();
		if ( Potamus_Updates::configured() ) {
			Potamus_Updates::sync_schedule();
			Potamus_Updates::refresh_definitions();
		}
	}

	public static function deactivate() {
		Potamus_Htaccess::remove();
		Potamus_Integrity::unschedule();
		Potamus_Updates::unschedule();
	}
}
