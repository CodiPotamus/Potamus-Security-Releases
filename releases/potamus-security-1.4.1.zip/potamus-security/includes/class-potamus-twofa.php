<?php
/**
 * Autenticação de dois fatores (2FA) com uma app de autenticação
 * (Google Authenticator, Microsoft Authenticator, 1Password, Authy...).
 *
 * Funciona por utilizador: só pede o código a quem o ativou no seu perfil.
 * Não depende de serviços externos: os códigos são calculados no próprio site (TOTP, RFC 6238).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Potamus_TwoFA {

	const META_SECRET  = '_potamus_2fa_secret';
	const META_ON      = '_potamus_2fa_enabled';
	const META_PENDING = '_potamus_2fa_pending';
	const META_BACKUP  = '_potamus_2fa_backup';
	const META_LAST    = '_potamus_2fa_last';
	const MAX_TRIES    = 5;

	public static function init() {
		if ( ! Potamus_Settings::get( 'twofa_enabled' ) ) {
			return;
		}
		add_filter( 'authenticate', array( __CLASS__, 'intercept' ), 99, 1 );
		add_action( 'login_form_potamus_2fa', array( __CLASS__, 'handle' ) );
		add_filter( 'wp_login_errors', array( __CLASS__, 'login_notice' ) );

		if ( is_admin() ) {
			add_action( 'show_user_profile', array( __CLASS__, 'profile_section' ) );
			add_action( 'edit_user_profile', array( __CLASS__, 'profile_section' ) );
			add_action( 'user_profile_update_errors', array( __CLASS__, 'save_profile' ), 10, 3 );
			add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
			add_action( 'admin_notices', array( __CLASS__, 'force_notice' ) );
		}
		add_filter( 'login_redirect', array( __CLASS__, 'force_redirect' ), 99, 3 );
	}

	/* ---------- TOTP ---------- */

	public static function base32_encode( $bin ) {
		$alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
		$bits     = '';
		foreach ( str_split( $bin ) as $char ) {
			$bits .= str_pad( decbin( ord( $char ) ), 8, '0', STR_PAD_LEFT );
		}
		$out = '';
		foreach ( str_split( $bits, 5 ) as $chunk ) {
			$out .= $alphabet[ bindec( str_pad( $chunk, 5, '0' ) ) ];
		}
		return $out;
	}

	public static function base32_decode( $b32 ) {
		$alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
		$b32      = strtoupper( preg_replace( '/[^A-Za-z2-7]/', '', (string) $b32 ) );
		$bits     = '';
		foreach ( str_split( $b32 ) as $char ) {
			$bits .= str_pad( decbin( strpos( $alphabet, $char ) ), 5, '0', STR_PAD_LEFT );
		}
		$out = '';
		foreach ( str_split( $bits, 8 ) as $byte ) {
			if ( 8 === strlen( $byte ) ) {
				$out .= chr( bindec( $byte ) );
			}
		}
		return $out;
	}

	public static function code_at( $secret, $slice ) {
		$key  = self::base32_decode( $secret );
		$msg  = pack( 'N', 0 ) . pack( 'N', $slice );
		$hash = hash_hmac( 'sha1', $msg, $key, true );
		$off  = ord( $hash[19] ) & 0x0f;
		$num  = ( ( ord( $hash[ $off ] ) & 0x7f ) << 24 ) | ( ord( $hash[ $off + 1 ] ) << 16 ) | ( ord( $hash[ $off + 2 ] ) << 8 ) | ord( $hash[ $off + 3 ] );
		return str_pad( (string) ( $num % 1000000 ), 6, '0', STR_PAD_LEFT );
	}

	/** Aceita o código atual e o anterior/seguinte (relógios ligeiramente desacertados). Cada código só serve uma vez. */
	public static function verify_totp( $secret, $code, $user_id = 0 ) {
		$code = preg_replace( '/\D/', '', (string) $code );
		if ( 6 !== strlen( $code ) || ! $secret ) {
			return false;
		}
		$now  = (int) floor( time() / 30 );
		$last = $user_id ? (int) get_user_meta( $user_id, self::META_LAST, true ) : 0;
		for ( $i = -1; $i <= 1; $i++ ) {
			$slice = $now + $i;
			if ( $slice <= $last ) {
				continue;
			}
			if ( hash_equals( self::code_at( $secret, $slice ), $code ) ) {
				if ( $user_id ) {
					update_user_meta( $user_id, self::META_LAST, $slice );
				}
				return true;
			}
		}
		return false;
	}

	/* ---------- Estado do utilizador ---------- */

	public static function user_has( $user_id ) {
		return (bool) get_user_meta( $user_id, self::META_ON, true ) && (bool) get_user_meta( $user_id, self::META_SECRET, true );
	}

	private static function new_secret() {
		return self::base32_encode( random_bytes( 20 ) );
	}

	private static function generate_backup_codes( $user_id ) {
		$codes  = array();
		$hashes = array();
		for ( $i = 0; $i < 8; $i++ ) {
			$code     = strtolower( wp_generate_password( 4, false ) . '-' . wp_generate_password( 4, false ) );
			$codes[]  = $code;
			$hashes[] = wp_hash_password( $code );
		}
		update_user_meta( $user_id, self::META_BACKUP, $hashes );
		set_transient( 'psec_2fa_show_' . $user_id, $codes, 10 * MINUTE_IN_SECONDS );
		return $codes;
	}

	private static function use_backup_code( $user_id, $code ) {
		$code = strtolower( trim( (string) $code ) );
		if ( ! preg_match( '/^[a-z0-9]{4}-?[a-z0-9]{4}$/', $code ) ) {
			return false;
		}
		if ( false === strpos( $code, '-' ) ) {
			$code = substr( $code, 0, 4 ) . '-' . substr( $code, 4 );
		}
		$hashes = (array) get_user_meta( $user_id, self::META_BACKUP, true );
		foreach ( $hashes as $i => $hash ) {
			if ( $hash && wp_check_password( $code, $hash ) ) {
				unset( $hashes[ $i ] );
				update_user_meta( $user_id, self::META_BACKUP, array_values( $hashes ) );
				return true;
			}
		}
		return false;
	}

	public static function backup_count( $user_id ) {
		return count( array_filter( (array) get_user_meta( $user_id, self::META_BACKUP, true ) ) );
	}

	public static function disable_for( $user_id ) {
		foreach ( array( self::META_SECRET, self::META_ON, self::META_PENDING, self::META_BACKUP, self::META_LAST ) as $key ) {
			delete_user_meta( $user_id, $key );
		}
	}

	/* ---------- Login ---------- */

	/** Depois de a palavra-passe estar certa, troca o login por um segundo passo. */
	public static function intercept( $user ) {
		if ( ! $user instanceof WP_User || Potamus_Login::recovery_mode() ) {
			return $user;
		}
		if ( ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return $user;
		}
		if ( ! isset( $GLOBALS['pagenow'] ) || 'wp-login.php' !== $GLOBALS['pagenow'] || ! function_exists( 'login_header' ) ) {
			return $user;
		}
		if ( ! self::user_has( $user->ID ) ) {
			return $user;
		}

		$token = wp_generate_password( 40, false );
		set_transient(
			self::token_key( $token ),
			array(
				'uid'      => $user->ID,
				'remember' => ! empty( $_POST['rememberme'] ), // phpcs:ignore WordPress.Security.NonceVerification
				'redirect' => isset( $_REQUEST['redirect_to'] ) ? esc_url_raw( wp_unslash( $_REQUEST['redirect_to'] ) ) : '', // phpcs:ignore
				'tries'    => 0,
			),
			10 * MINUTE_IN_SECONDS
		);
		self::render_form( $token );
		exit;
	}

	private static function token_key( $token ) {
		return 'psec_2fa_' . substr( hash( 'sha256', (string) $token ), 0, 32 );
	}

	private static function render_form( $token, $error = '' ) {
		$errors = $error ? new WP_Error( 'potamus_2fa', $error ) : null;
		$interim = ! empty( $_REQUEST['interim-login'] ); // phpcs:ignore WordPress.Security.NonceVerification
		login_header( 'Verificação em dois passos', '<p class="message">Abra a sua app de autenticação e introduza o código de 6 dígitos.</p>', $errors );
		?>
		<form name="potamus2fa" id="loginform" action="<?php echo esc_url( site_url( 'wp-login.php?action=potamus_2fa', 'login_post' ) ); ?>" method="post" autocomplete="off">
			<p>
				<label for="psec_code">Código de autenticação</label>
				<input type="text" name="psec_code" id="psec_code" class="input" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9a-zA-Z\- ]*" size="20" autofocus required style="letter-spacing:.2em;font-size:22px;text-align:center">
			</p>
			<p style="color:#646970;font-size:12px;margin-bottom:16px">Sem acesso à app? Use um dos seus códigos de recuperação (ex.: <code>ab12-cd34</code>).</p>
			<input type="hidden" name="psec_token" value="<?php echo esc_attr( $token ); ?>">
			<?php if ( $interim ) : ?><input type="hidden" name="interim-login" value="1"><?php endif; ?>
			<p class="submit"><input type="submit" class="button button-primary button-large" value="Verificar"></p>
		</form>
		<?php
		login_footer( 'psec_code' );
		exit;
	}

	public static function handle() {
		$token = isset( $_POST['psec_token'] ) ? sanitize_text_field( wp_unslash( $_POST['psec_token'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$data  = $token ? get_transient( self::token_key( $token ) ) : false;

		if ( ! is_array( $data ) || empty( $data['uid'] ) ) {
			wp_safe_redirect( add_query_arg( 'psec2fa', 'expired', wp_login_url() ) );
			exit;
		}

		$user = get_user_by( 'id', (int) $data['uid'] );
		$code = isset( $_POST['psec_code'] ) ? sanitize_text_field( wp_unslash( $_POST['psec_code'] ) ) : ''; // phpcs:ignore

		$ok = $user && (
			self::verify_totp( get_user_meta( $user->ID, self::META_SECRET, true ), $code, $user->ID )
			|| self::use_backup_code( $user->ID, $code )
		);

		if ( ! $ok ) {
			$data['tries']++;
			if ( $data['tries'] >= self::MAX_TRIES || ! $user ) {
				delete_transient( self::token_key( $token ) );
				if ( $user ) {
					do_action( 'wp_login_failed', $user->user_login, new WP_Error( 'potamus_2fa', '2FA' ) );
				}
				wp_safe_redirect( add_query_arg( 'psec2fa', 'failed', wp_login_url() ) );
				exit;
			}
			set_transient( self::token_key( $token ), $data, 10 * MINUTE_IN_SECONDS );
			self::render_form( $token, '<strong>Erro:</strong> código inválido. Tente novamente.' );
		}

		delete_transient( self::token_key( $token ) );
		wp_set_auth_cookie( $user->ID, ! empty( $data['remember'] ), is_ssl() );
		do_action( 'wp_login', $user->user_login, $user );

		if ( ! empty( $_REQUEST['interim-login'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			// Sessão expirada dentro do painel: mostra o aviso de sucesso que o WordPress espera.
			global $interim_login;
			$interim_login = 'success'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
			login_header( '', '<p class="message">' . __( 'You have logged in successfully.' ) . '</p>' );
			echo '</div>';
			do_action( 'login_footer' );
			echo '</body></html>';
			exit;
		}

		$requested = $data['redirect'] ? $data['redirect'] : admin_url();
		$redirect  = apply_filters( 'login_redirect', $requested, $requested, $user );
		wp_safe_redirect( $redirect ? $redirect : admin_url() );
		exit;
	}

	public static function login_notice( $errors ) {
		$state = isset( $_GET['psec2fa'] ) ? sanitize_key( $_GET['psec2fa'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		if ( $errors instanceof WP_Error && 'expired' === $state ) {
			$errors->add( 'potamus_2fa_expired', 'A verificação expirou. Entre de novo.', 'message' );
		} elseif ( $errors instanceof WP_Error && 'failed' === $state ) {
			$errors->add( 'potamus_2fa_failed', '<strong>Erro:</strong> demasiados códigos errados. Entre de novo.' );
		}
		return $errors;
	}

	/* ---------- Obrigatório para administradores ---------- */

	private static function must_setup( $user ) {
		return Potamus_Settings::get( 'twofa_force_admins' ) && $user instanceof WP_User && user_can( $user, 'manage_options' ) && ! self::user_has( $user->ID );
	}

	public static function force_redirect( $redirect, $requested, $user ) {
		if ( self::must_setup( $user ) ) {
			return admin_url( 'profile.php#potamus-2fa' );
		}
		return $redirect;
	}

	public static function force_notice() {
		$screen = get_current_screen();
		if ( ! self::must_setup( wp_get_current_user() ) || ( $screen && 'profile' === $screen->id ) ) {
			return;
		}
		printf(
			'<div class="notice notice-error"><p><strong>Potamus Security:</strong> a verificação em dois passos é obrigatória para administradores. <a href="%s">Configure-a agora</a> (demora um minuto).</p></div>',
			esc_url( admin_url( 'profile.php#potamus-2fa' ) )
		);
	}

	/* ---------- Perfil ---------- */

	public static function assets( $hook ) {
		if ( ! in_array( $hook, array( 'profile.php', 'user-edit.php' ), true ) ) {
			return;
		}
		wp_enqueue_script( 'potamus-qrcode', POTAMUS_SECURITY_URL . 'assets/qrcode.js', array(), '2.0.4', true );
		wp_add_inline_script(
			'potamus-qrcode',
			'document.querySelectorAll("[data-psec-qr]").forEach(function(el){var q=qrcode(0,"M");q.addData(el.getAttribute("data-psec-qr"));q.make();el.innerHTML=q.createSvgTag({cellSize:4,margin:2,scalable:true});});'
		);
	}

	public static function profile_section( $user ) {
		$own     = get_current_user_id() === $user->ID;
		$enabled = self::user_has( $user->ID );
		$codes   = $own ? get_transient( 'psec_2fa_show_' . $user->ID ) : false;
		if ( $codes ) {
			delete_transient( 'psec_2fa_show_' . $user->ID );
		}
		?>
		<h2 id="potamus-2fa">Verificação em dois passos (Potamus Security)</h2>
		<table class="form-table" role="presentation"><tr><th>Estado</th><td>
		<?php if ( $enabled ) : ?>
			<p><span style="color:#1f9d63;font-weight:600">● Ativa</span> — ao entrar é pedido um código da app de autenticação.</p>
			<p class="description"><?php echo esc_html( sprintf( 'Códigos de recuperação disponíveis: %d de 8.', self::backup_count( $user->ID ) ) ); ?></p>

			<?php if ( $codes ) : ?>
				<div style="margin:14px 0;padding:14px 16px;background:#fff8e5;border:1px solid #f0c33c;border-radius:8px;max-width:520px">
					<strong>Guarde estes códigos de recuperação num sítio seguro.</strong>
					<p style="margin:6px 0 10px">Cada um serve uma vez, caso perca o telemóvel. Não os voltará a ver.</p>
					<div style="display:grid;grid-template-columns:repeat(2,max-content);gap:6px 28px;font:15px/1.4 monospace"><?php foreach ( $codes as $c ) : ?><span><?php echo esc_html( $c ); ?></span><?php endforeach; ?></div>
				</div>
			<?php endif; ?>

			<?php if ( $own ) : ?>
				<p><label><input type="checkbox" name="psec_2fa_regen" value="1"> Gerar novos códigos de recuperação (os antigos deixam de funcionar)</label></p>
			<?php endif; ?>
			<p><label><input type="checkbox" name="psec_2fa_disable" value="1"> <?php echo $own ? 'Desativar a verificação em dois passos' : 'Desativar a verificação em dois passos deste utilizador (ex.: perdeu o telemóvel)'; ?></label></p>

		<?php elseif ( $own ) :
			$secret = get_user_meta( $user->ID, self::META_PENDING, true );
			if ( ! $secret ) {
				$secret = self::new_secret();
				update_user_meta( $user->ID, self::META_PENDING, $secret );
			}
			$issuer = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
			$issuer = $issuer ? $issuer : wp_parse_url( home_url(), PHP_URL_HOST );
			$uri    = 'otpauth://totp/' . rawurlencode( $issuer . ':' . $user->user_login ) . '?secret=' . $secret . '&issuer=' . rawurlencode( $issuer ) . '&digits=6&period=30';
			?>
			<p>Desativada. Proteja a sua conta em três passos:</p>
			<ol>
				<li>Instale uma app de autenticação no telemóvel (Google Authenticator, Microsoft Authenticator, 1Password, Authy…).</li>
				<li>Na app, leia este código QR:
					<div data-psec-qr="<?php echo esc_attr( $uri ); ?>" style="width:180px;height:180px;margin:10px 0;background:#fff;border:1px solid #dcdcde;border-radius:8px"></div>
					<span class="description">Ou introduza a chave manualmente: <code style="user-select:all"><?php echo esc_html( trim( chunk_split( $secret, 4, ' ' ) ) ); ?></code></span>
				</li>
				<li>Escreva aqui o código de 6 dígitos que a app mostra e clique em <strong>Atualizar perfil</strong>:<br>
					<input type="text" name="psec_2fa_confirm" inputmode="numeric" autocomplete="one-time-code" maxlength="7" style="width:140px;margin-top:6px;font-size:18px;letter-spacing:.15em;text-align:center">
				</li>
			</ol>
		<?php else : ?>
			<p>Este utilizador ainda não ativou a verificação em dois passos. Só o próprio a pode configurar, no seu perfil.</p>
		<?php endif; ?>
		</td></tr></table>
		<?php
	}

	/** Corre ao guardar o perfil (o WordPress já verificou permissões e o nonce). */
	public static function save_profile( $errors, $update, $user ) {
		if ( ! $update || empty( $user->ID ) || ! current_user_can( 'edit_user', $user->ID ) ) {
			return;
		}
		$uid = (int) $user->ID;
		$own = get_current_user_id() === $uid;

		// phpcs:disable WordPress.Security.NonceVerification
		if ( ! empty( $_POST['psec_2fa_disable'] ) && self::user_has( $uid ) ) {
			self::disable_for( $uid );
			return;
		}

		if ( $own && ! empty( $_POST['psec_2fa_regen'] ) && self::user_has( $uid ) ) {
			self::generate_backup_codes( $uid );
		}

		$confirm = isset( $_POST['psec_2fa_confirm'] ) ? sanitize_text_field( wp_unslash( $_POST['psec_2fa_confirm'] ) ) : '';
		// phpcs:enable
		if ( $own && '' !== $confirm && ! self::user_has( $uid ) ) {
			$pending = get_user_meta( $uid, self::META_PENDING, true );
			if ( $pending && self::verify_totp( $pending, $confirm, $uid ) ) {
				update_user_meta( $uid, self::META_SECRET, $pending );
				update_user_meta( $uid, self::META_ON, 1 );
				delete_user_meta( $uid, self::META_PENDING );
				self::generate_backup_codes( $uid );
			} else {
				$errors->add( 'potamus_2fa', '<strong>Verificação em dois passos:</strong> o código não está certo. Confirme que a hora do telemóvel está automática e tente de novo.' );
			}
		}
	}
}
