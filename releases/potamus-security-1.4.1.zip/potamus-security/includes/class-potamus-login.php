<?php
/**
 * Proteção do login: endereço personalizado, limite de tentativas e mensagens de erro neutras.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Potamus_Login {

	private static $serve_login = false;

	public static function init() {
		$s = Potamus_Settings::all();

		if ( $s['login_enabled'] && $s['login_slug'] && ! self::recovery_mode() ) {
			add_action( 'plugins_loaded', array( __CLASS__, 'route' ), 1 );
			add_action( 'wp_loaded', array( __CLASS__, 'serve_login' ), 1 );
			add_action( 'init', array( __CLASS__, 'hide_admin' ), 1 );
			add_filter( 'site_url', array( __CLASS__, 'rewrite_url' ), 10, 1 );
			add_filter( 'network_site_url', array( __CLASS__, 'rewrite_url' ), 10, 1 );
			add_filter( 'wp_redirect', array( __CLASS__, 'rewrite_url' ), 10, 1 );
			add_filter( 'register_url', array( __CLASS__, 'rewrite_url' ), 10, 1 );
			// Impede que /login, /admin e /dashboard redirecionem para o login verdadeiro.
			add_action( 'init', array( __CLASS__, 'remove_admin_shortcuts' ) );
		}

		if ( $s['limit_login'] ) {
			add_filter( 'authenticate', array( __CLASS__, 'check_lock' ), 30, 2 );
			add_action( 'wp_login_failed', array( __CLASS__, 'register_failure' ) );
			add_action( 'wp_login', array( __CLASS__, 'clear_failures' ) );
		}

		if ( $s['generic_errors'] ) {
			add_filter( 'wp_login_errors', array( __CLASS__, 'generic_error' ) );
		}
	}

	/**
	 * Modo de recuperação: se ficar sem acesso, acrescente ao wp-config.php
	 * define( 'POTAMUS_SECURITY_RECOVERY', true );
	 */
	public static function recovery_mode() {
		return defined( 'POTAMUS_SECURITY_RECOVERY' ) && POTAMUS_SECURITY_RECOVERY;
	}

	public static function login_url() {
		return home_url( '/' . Potamus_Settings::get( 'login_slug' ) . '/', 'login' );
	}

	private static function request_path() {
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
		return untrailingslashit( strtolower( rawurldecode( $path ) ) );
	}

	/* ---------- Endereço de login personalizado ---------- */

	public static function route() {
		$path       = self::request_path();
		$login_path = untrailingslashit( strtolower( (string) wp_parse_url( self::login_url(), PHP_URL_PATH ) ) );
		$script     = isset( $_SERVER['SCRIPT_FILENAME'] ) ? basename( (string) $_SERVER['SCRIPT_FILENAME'] ) : '';

		if ( $path === $login_path ) {
			self::$serve_login     = true;
			$GLOBALS['pagenow']    = 'wp-login.php';
			if ( ! defined( 'DONOTCACHEPAGE' ) ) {
				define( 'DONOTCACHEPAGE', true );
			}
			return;
		}

		// Acesso direto ao wp-login.php verdadeiro: fingir que não existe.
		if ( in_array( $script, array( 'wp-login.php', 'wp-register.php' ), true ) || preg_match( '#/wp-(login|register)\.php$#', $path ) ) {
			Potamus_Hardening::not_found();
		}
	}

	public static function serve_login() {
		if ( ! self::$serve_login ) {
			return;
		}
		do_action( 'litespeed_control_set_nocache', 'potamus-security login' );
		// Estas variáveis têm de ser globais porque o wp-login.php as partilha com as suas funções.
		global $error, $interim_login, $action, $user_login;
		require_once ABSPATH . 'wp-login.php';
		exit;
	}

	/** Visitantes sem sessão que tentem abrir o /wp-admin veem uma página 404 em vez do login. */
	public static function hide_admin() {
		if ( ! is_admin() || is_user_logged_in() || wp_doing_ajax() || wp_doing_cron() ) {
			return;
		}
		$script = isset( $_SERVER['SCRIPT_FILENAME'] ) ? basename( (string) $_SERVER['SCRIPT_FILENAME'] ) : '';
		if ( 'admin-post.php' === $script ) {
			return;
		}
		Potamus_Hardening::not_found();
	}

	/** Todos os links do WordPress para o wp-login.php passam a apontar para o novo endereço. */
	public static function rewrite_url( $url ) {
		if ( ! is_string( $url ) || false === strpos( $url, 'wp-login.php' ) ) {
			return $url;
		}
		$parts = explode( '?', $url, 2 );
		if ( false === strpos( $parts[0], 'wp-login.php' ) ) {
			return $url;
		}
		$new = self::login_url();
		return isset( $parts[1] ) ? $new . '?' . $parts[1] : $new;
	}

	public static function remove_admin_shortcuts() {
		remove_action( 'template_redirect', 'wp_redirect_admin_locations', 1000 );
	}

	/* ---------- Limite de tentativas ---------- */

	public static function client_ip() {
		$source = Potamus_Settings::get( 'ip_source' );
		$map    = array(
			'x_forwarded_for'  => 'HTTP_X_FORWARDED_FOR',
			'x_real_ip'        => 'HTTP_X_REAL_IP',
			'cf_connecting_ip' => 'HTTP_CF_CONNECTING_IP',
		);
		$ip = '';
		if ( isset( $map[ $source ] ) && ! empty( $_SERVER[ $map[ $source ] ] ) ) {
			$list = explode( ',', (string) $_SERVER[ $map[ $source ] ] );
			$ip   = trim( $list[0] );
		}
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '';
		}
		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '0.0.0.0';
	}

	private static function key( $type ) {
		return 'psec_' . $type . '_' . substr( md5( self::client_ip() ), 0, 16 );
	}

	public static function check_lock( $user, $username ) {
		if ( empty( $username ) ) {
			return $user;
		}
		$until = (int) get_transient( self::key( 'lock' ) );
		if ( $until > time() ) {
			$minutes = max( 1, (int) ceil( ( $until - time() ) / 60 ) );
			remove_action( 'wp_login_failed', array( __CLASS__, 'register_failure' ) );
			return new WP_Error(
				'potamus_locked',
				sprintf( 'Demasiadas tentativas falhadas. Tente novamente dentro de %d minuto(s).', $minutes )
			);
		}
		return $user;
	}

	public static function register_failure() {
		$s     = Potamus_Settings::all();
		$key   = self::key( 'fail' );
		$count = (int) get_transient( $key ) + 1;

		if ( $count >= (int) $s['max_attempts'] ) {
			$seconds = (int) $s['lockout_minutes'] * MINUTE_IN_SECONDS;
			set_transient( self::key( 'lock' ), time() + $seconds, $seconds );
			delete_transient( $key );
			$total = (int) get_option( 'potamus_security_lockouts', 0 );
			update_option( 'potamus_security_lockouts', $total + 1, false );
			return;
		}
		set_transient( $key, $count, 15 * MINUTE_IN_SECONDS );
	}

	public static function clear_failures() {
		delete_transient( self::key( 'fail' ) );
	}

	/* ---------- Mensagens de erro ---------- */

	/** Não revelar se o utilizador existe: o mesmo aviso para nome errado ou palavra-passe errada. */
	public static function generic_error( $errors ) {
		if ( ! $errors instanceof WP_Error ) {
			return $errors;
		}
		$hide = array( 'invalid_username', 'invalid_email', 'incorrect_password' );
		if ( ! array_intersect( $errors->get_error_codes(), $hide ) ) {
			return $errors;
		}
		foreach ( $hide as $code ) {
			$errors->remove( $code );
		}
		$errors->add( 'potamus_invalid', '<strong>Erro:</strong> dados de acesso inválidos.' );
		return $errors;
	}
}
