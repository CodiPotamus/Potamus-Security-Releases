<?php
/**
 * Atualizações do plugin e definições de ameaças, publicadas num repositório público
 * do GitHub e ASSINADAS com a chave privada da CodiPotamus (Ed25519).
 *
 * - O plugin só instala uma versão nova se a assinatura bater certo com a chave pública
 *   embutida aqui. Um servidor comprometido não consegue distribuir código falso.
 * - As definições (padrões de código malicioso e plugins/temas vulneráveis) são vistas
 *   uma vez por dia. A comparação com os plugins instalados é feita no próprio site:
 *   nenhuma informação do site é enviada para fora.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Potamus_Updates {

	const MANIFEST_CACHE = 'potamus_security_manifest';
	const DEFS_OPTION    = 'potamus_security_definitions';
	const STATUS_OPTION  = 'potamus_security_updates_status';
	const CRON_HOOK      = 'potamus_security_definitions_cron';

	/* ---------- Configuração ---------- */

	/** Canal configurado = repositório e chave pública preenchidos. */
	public static function configured() {
		return self::repo() && self::public_key();
	}

	public static function repo() {
		$repo = defined( 'POTAMUS_UPDATE_REPO' ) ? trim( (string) POTAMUS_UPDATE_REPO ) : '';
		return preg_match( '#^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$#', $repo ) ? $repo : '';
	}

	public static function public_key() {
		$key = defined( 'POTAMUS_SIGNING_PUBLIC_KEY' ) ? base64_decode( (string) POTAMUS_SIGNING_PUBLIC_KEY, true ) : false; // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
		return ( false !== $key && 32 === strlen( $key ) ) ? $key : '';
	}

	/** Endereço base dos ficheiros públicos (pode ser substituído em testes com POTAMUS_UPDATE_BASE). */
	public static function base_url() {
		if ( defined( 'POTAMUS_UPDATE_BASE' ) && POTAMUS_UPDATE_BASE ) {
			return trailingslashit( POTAMUS_UPDATE_BASE );
		}
		return 'https://raw.githubusercontent.com/' . self::repo() . '/main/';
	}

	/* ---------- Assinaturas ---------- */

	private static function sodium() {
		if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) && file_exists( ABSPATH . WPINC . '/sodium_compat/autoload.php' ) ) {
			require_once ABSPATH . WPINC . '/sodium_compat/autoload.php';
		}
		return function_exists( 'sodium_crypto_sign_verify_detached' );
	}

	/** Verifica uma assinatura Ed25519 (base64) sobre a mensagem. */
	public static function verify( $message, $signature_b64 ) {
		$key = self::public_key();
		$sig = base64_decode( (string) $signature_b64, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
		if ( ! $key || false === $sig || 64 !== strlen( $sig ) || ! self::sodium() ) {
			return false;
		}
		try {
			return sodium_crypto_sign_verify_detached( $sig, (string) $message, $key );
		} catch ( Exception $e ) {
			return false;
		}
	}

	/* ---------- Arranque ---------- */

	public static function init() {
		if ( ! self::configured() ) {
			return;
		}
		// O cabeçalho "Update URI" do plugin aponta para github.com: o WordPress pergunta-nos a nós, e nunca ao WordPress.org.
		add_filter( 'update_plugins_github.com', array( __CLASS__, 'check_update' ), 10, 3 );
		add_filter( 'plugins_api', array( __CLASS__, 'plugin_details' ), 20, 3 );
		add_filter( 'upgrader_pre_download', array( __CLASS__, 'verified_download' ), 10, 4 );
		add_filter( 'auto_update_plugin', array( __CLASS__, 'auto_update' ), 20, 2 );

		add_action( self::CRON_HOOK, array( __CLASS__, 'refresh_definitions' ) );
		if ( is_admin() ) {
			add_action( 'admin_init', array( __CLASS__, 'sync_schedule' ) );
			add_action( 'admin_post_potamus_check_now', array( __CLASS__, 'check_now' ) );
		}
	}

	public static function sync_schedule() {
		$want = (bool) Potamus_Settings::get( 'definitions_daily' );
		$next = wp_next_scheduled( self::CRON_HOOK );
		if ( $want && ! $next ) {
			wp_schedule_event( time() + 10 * MINUTE_IN_SECONDS, 'daily', self::CRON_HOOK );
		} elseif ( ! $want && $next ) {
			wp_clear_scheduled_hook( self::CRON_HOOK );
		}
	}

	public static function unschedule() {
		wp_clear_scheduled_hook( self::CRON_HOOK );
	}

	private static function set_status( $key, $value ) {
		$status         = (array) get_option( self::STATUS_OPTION, array() );
		$status[ $key ] = $value;
		update_option( self::STATUS_OPTION, $status, false );
	}

	public static function status() {
		return (array) get_option( self::STATUS_OPTION, array() );
	}

	private static function fetch_json( $file ) {
		$response = wp_remote_get(
			self::base_url() . $file . '?t=' . floor( time() / 300 ),
			array( 'timeout' => 15 )
		);
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		if ( 404 === (int) wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'psec_not_published', 'Ainda não foi publicado.' );
		}
		if ( 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'psec_http', sprintf( 'O servidor respondeu com o código %d.', (int) wp_remote_retrieve_response_code( $response ) ) );
		}
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		return is_array( $data ) ? $data : new WP_Error( 'psec_json', 'O ficheiro recebido não é válido.' );
	}

	/* ---------- Atualizações do plugin ---------- */

	/** Mensagem assinada: inclui a versão, para que um pacote antigo não possa ser reapresentado como novo. */
	public static function update_message( $version, $sha384 ) {
		return 'potamus-security|update|' . $version . '|' . strtolower( $sha384 );
	}

	/** Lê o manifesto (update.json) e confirma a assinatura. Guardado em cache 6 horas. */
	public static function manifest( $force = false ) {
		$cached = get_site_transient( self::MANIFEST_CACHE );
		if ( ! $force && is_array( $cached ) ) {
			return $cached;
		}
		$m = self::fetch_json( 'update.json' );
		// Ainda não há nenhuma versão publicada: não é um erro, a instalada é a mais recente.
		if ( is_wp_error( $m ) && 'psec_not_published' === $m->get_error_code() ) {
			self::set_status( 'update_error', '' );
			self::set_status( 'update_checked', time() );
			self::set_status( 'update_latest', '' );
			return null;
		}
		if ( is_wp_error( $m ) ) {
			self::set_status( 'update_error', $m->get_error_message() );
			return null;
		}
		$valid = isset( $m['version'], $m['package'], $m['sha384'], $m['signature'] )
			&& preg_match( '/^\d+\.\d+(\.\d+)?$/', (string) $m['version'] )
			&& preg_match( '/^[a-f0-9]{96}$/i', (string) $m['sha384'] )
			&& ( 0 === strpos( (string) $m['package'], 'https://' ) || ( defined( 'POTAMUS_UPDATE_BASE' ) && POTAMUS_UPDATE_BASE && 0 === strpos( (string) $m['package'], (string) POTAMUS_UPDATE_BASE ) ) );
		if ( ! $valid ) {
			self::set_status( 'update_error', 'O manifesto de atualização está incompleto ou mal formado. A atualização foi ignorada.' );
			return null;
		}
		if ( ! self::verify( self::update_message( $m['version'], $m['sha384'] ), $m['signature'] ) ) {
			self::set_status( 'update_error', 'A assinatura do manifesto de atualização não é válida. A atualização foi ignorada.' );
			return null;
		}
		self::set_status( 'update_error', '' );
		self::set_status( 'update_checked', time() );
		self::set_status( 'update_latest', (string) $m['version'] );
		set_site_transient( self::MANIFEST_CACHE, $m, 6 * HOUR_IN_SECONDS );
		return $m;
	}

	/** Diz ao WordPress que há uma versão nova (filtro update_plugins_github.com). */
	public static function check_update( $update, $plugin_data, $plugin_file ) {
		if ( plugin_basename( POTAMUS_SECURITY_FILE ) !== $plugin_file ) {
			return $update;
		}
		$m = self::manifest();
		if ( ! $m || version_compare( $m['version'], POTAMUS_SECURITY_VERSION, '<=' ) ) {
			return $update;
		}
		return array(
			'id'           => 'https://github.com/' . self::repo(),
			'slug'         => 'potamus-security',
			'version'      => $m['version'],
			'url'          => 'https://github.com/' . self::repo(),
			'package'      => $m['package'],
			'tested'       => isset( $m['tested'] ) ? (string) $m['tested'] : '',
			'requires_php' => isset( $m['requires_php'] ) ? (string) $m['requires_php'] : '',
			'autoupdate'   => (bool) Potamus_Settings::get( 'auto_update_self' ),
		);
	}

	/** Janela "Ver detalhes" com o registo de alterações. */
	public static function plugin_details( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || 'potamus-security' !== $args->slug ) {
			return $result;
		}
		$m = self::manifest();
		if ( ! $m ) {
			return $result;
		}
		return (object) array(
			'name'          => 'Potamus Security',
			'slug'          => 'potamus-security',
			'version'       => $m['version'],
			'author'        => '<a href="https://codipotamus.site">CodiPotamus</a>',
			'homepage'      => 'https://codipotamus.site',
			'requires'      => isset( $m['requires'] ) ? $m['requires'] : '',
			'tested'        => isset( $m['tested'] ) ? $m['tested'] : '',
			'requires_php'  => isset( $m['requires_php'] ) ? $m['requires_php'] : '',
			'last_updated'  => isset( $m['released'] ) ? $m['released'] : '',
			'download_link' => $m['package'],
			'sections'      => array(
				'changelog' => wpautop( esc_html( isset( $m['changelog'] ) ? (string) $m['changelog'] : '' ) ),
			),
		);
	}

	/**
	 * Antes de instalar, descarrega o pacote e confirma a impressão digital e a assinatura.
	 * Se alguma coisa não bater certo, a instalação é cancelada.
	 */
	public static function verified_download( $reply, $package, $upgrader, $hook_extra = array() ) {
		$ours = ( isset( $hook_extra['plugin'] ) && plugin_basename( POTAMUS_SECURITY_FILE ) === $hook_extra['plugin'] );
		$m    = get_site_transient( self::MANIFEST_CACHE );
		if ( ! $ours && ! ( is_array( $m ) && isset( $m['package'] ) && $m['package'] === $package ) ) {
			return $reply;
		}
		$m = self::manifest( true );
		if ( ! $m || $m['package'] !== $package ) {
			return new WP_Error( 'psec_untrusted', 'Potamus Security: não foi possível confirmar a origem desta atualização. Instalação cancelada.' );
		}
		if ( version_compare( $m['version'], POTAMUS_SECURITY_VERSION, '<=' ) ) {
			return new WP_Error( 'psec_downgrade', 'Potamus Security: a versão oferecida não é mais recente do que a instalada. Instalação cancelada.' );
		}
		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$file = download_url( $package, 300 );
		if ( is_wp_error( $file ) ) {
			return $file;
		}
		$hash = hash_file( 'sha384', $file );
		if ( ! hash_equals( strtolower( $m['sha384'] ), (string) $hash ) || ! self::verify( self::update_message( $m['version'], $hash ), $m['signature'] ) ) {
			wp_delete_file( $file );
			self::set_status( 'update_error', 'Uma atualização descarregada não tinha uma assinatura válida e foi rejeitada.' );
			return new WP_Error( 'psec_bad_signature', 'Potamus Security: a assinatura do pacote não é válida. Instalação cancelada por segurança.' );
		}
		return $file;
	}

	public static function auto_update( $update, $item ) {
		if ( isset( $item->plugin ) && plugin_basename( POTAMUS_SECURITY_FILE ) === $item->plugin && Potamus_Settings::get( 'auto_update_self' ) ) {
			return true;
		}
		return $update;
	}

	/* ---------- Definições de ameaças ---------- */

	public static function definitions_message( $payload ) {
		return 'potamus-security|definitions|' . $payload;
	}

	/** Vai buscar definitions.json, confirma a assinatura e guarda. Nunca aceita uma versão mais antiga. */
	public static function refresh_definitions() {
		$wrap = self::fetch_json( 'definitions.json' );
		if ( is_wp_error( $wrap ) && 'psec_not_published' === $wrap->get_error_code() ) {
			self::set_status( 'defs_error', self::definitions() ? '' : 'Ainda não foram publicadas definições de ameaças.' );
			self::set_status( 'defs_checked', time() );
			return false;
		}
		if ( is_wp_error( $wrap ) ) {
			self::set_status( 'defs_error', $wrap->get_error_message() );
			return false;
		}
		if ( empty( $wrap['payload'] ) || empty( $wrap['signature'] ) || ! is_string( $wrap['payload'] ) || ! self::verify( self::definitions_message( $wrap['payload'] ), $wrap['signature'] ) ) {
			self::set_status( 'defs_error', 'As definições recebidas não têm uma assinatura válida e foram ignoradas.' );
			return false;
		}
		$data = json_decode( $wrap['payload'], true );
		if ( ! is_array( $data ) || 'potamus-definitions' !== ( isset( $data['type'] ) ? $data['type'] : '' ) || empty( $data['version'] ) ) {
			self::set_status( 'defs_error', 'As definições recebidas não têm o formato esperado.' );
			return false;
		}
		$current = self::definitions();
		if ( $current && version_compare( (string) $data['version'], (string) $current['version'], '<' ) ) {
			self::set_status( 'defs_error', 'Foi recebida uma versão mais antiga das definições; foi ignorada.' );
			return false;
		}

		$clean = array(
			'version'         => (string) $data['version'],
			'created'         => isset( $data['created'] ) ? (string) $data['created'] : '',
			'patterns'        => array(),
			'vulnerabilities' => array(),
		);
		foreach ( (array) ( isset( $data['patterns'] ) ? $data['patterns'] : array() ) as $p ) {
			if ( empty( $p['regex'] ) || empty( $p['label'] ) || ! is_string( $p['regex'] ) ) {
				continue;
			}
			if ( false === @preg_match( $p['regex'], '' ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors -- só valida a expressão.
				continue;
			}
			$clean['patterns'][] = array(
				'level' => in_array( isset( $p['level'] ) ? $p['level'] : '', array( 'high', 'medium', 'low' ), true ) ? $p['level'] : 'medium',
				'label' => sanitize_text_field( $p['label'] ),
				'regex' => $p['regex'],
			);
		}
		foreach ( (array) ( isset( $data['vulnerabilities'] ) ? $data['vulnerabilities'] : array() ) as $v ) {
			if ( empty( $v['slug'] ) || empty( $v['max_version'] ) ) {
				continue;
			}
			$clean['vulnerabilities'][] = array(
				'type'        => ( isset( $v['type'] ) && 'theme' === $v['type'] ) ? 'theme' : 'plugin',
				'slug'        => sanitize_key( $v['slug'] ),
				'min_version' => isset( $v['min_version'] ) ? sanitize_text_field( $v['min_version'] ) : '',
				'max_version' => sanitize_text_field( $v['max_version'] ),
				'fixed_in'    => isset( $v['fixed_in'] ) ? sanitize_text_field( $v['fixed_in'] ) : '',
				'severity'    => in_array( isset( $v['severity'] ) ? $v['severity'] : '', array( 'critical', 'high', 'medium', 'low' ), true ) ? $v['severity'] : 'medium',
				'title'       => isset( $v['title'] ) ? sanitize_text_field( $v['title'] ) : '',
				'cve'         => isset( $v['cve'] ) ? sanitize_text_field( $v['cve'] ) : '',
				'url'         => isset( $v['url'] ) ? esc_url_raw( $v['url'] ) : '',
			);
		}

		update_option( self::DEFS_OPTION, $clean, false );
		self::set_status( 'defs_error', '' );
		self::set_status( 'defs_checked', time() );
		return true;
	}

	public static function definitions() {
		$d = get_option( self::DEFS_OPTION );
		return is_array( $d ) && ! empty( $d['version'] ) ? $d : null;
	}

	/** Padrões extra para a inspeção de ficheiros (formato: [nível, descrição, expressão]). */
	public static function extra_patterns() {
		$d   = self::definitions();
		$out = array();
		if ( $d ) {
			foreach ( $d['patterns'] as $p ) {
				$out[] = array( $p['level'], $p['label'], $p['regex'] );
			}
		}
		return $out;
	}

	/** Plugins e temas instalados que constam da lista de vulnerabilidades. */
	public static function vulnerable_items() {
		$d = self::definitions();
		if ( ! $d || empty( $d['vulnerabilities'] ) ) {
			return array();
		}
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$installed = array();
		foreach ( get_plugins() as $file => $data ) {
			$slug = dirname( $file );
			$slug = '.' === $slug ? basename( $file, '.php' ) : $slug;
			$installed[ 'plugin:' . $slug ] = array( $data['Name'], $data['Version'] );
		}
		foreach ( wp_get_themes() as $slug => $theme ) {
			$installed[ 'theme:' . $slug ] = array( $theme->get( 'Name' ), $theme->get( 'Version' ) );
		}

		$found = array();
		foreach ( $d['vulnerabilities'] as $v ) {
			$key = $v['type'] . ':' . $v['slug'];
			if ( ! isset( $installed[ $key ] ) ) {
				continue;
			}
			list( $name, $version ) = $installed[ $key ];
			if ( ! $version || version_compare( $version, $v['max_version'], '>' ) ) {
				continue;
			}
			if ( $v['min_version'] && version_compare( $version, $v['min_version'], '<' ) ) {
				continue;
			}
			$found[] = $v + array( 'name' => $name, 'installed' => $version );
		}
		return $found;
	}

	/* ---------- Ação manual ---------- */

	public static function check_now() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Sem permissão.' );
		}
		check_admin_referer( 'potamus_check_now' );
		self::manifest( true );
		self::refresh_definitions();
		delete_site_transient( 'update_plugins' );
		wp_update_plugins();
		wp_safe_redirect( admin_url( 'admin.php?page=potamus-security&psec_tab=updates' ) );
		exit;
	}
}
