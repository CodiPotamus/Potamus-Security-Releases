<?php
/**
 * Página de definições. Só é carregada na administração, e os estilos/scripts
 * só entram na página do próprio plugin.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Potamus_Admin {

	const SLUG = 'potamus-security';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'wp_ajax_potamus_inspect', array( __CLASS__, 'ajax_inspect' ) );
		add_action( 'update_option_' . Potamus_Settings::OPTION, array( __CLASS__, 'after_save' ), 10, 0 );
		add_action( 'add_option_' . Potamus_Settings::OPTION, array( __CLASS__, 'after_save' ), 10, 0 );
		add_filter( 'plugin_action_links_' . plugin_basename( POTAMUS_SECURITY_FILE ), array( __CLASS__, 'action_links' ) );
	}

	public static function icon_svg( $color = 'black' ) {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="' . $color . '" fill-rule="evenodd" d="M4.2 2.4a1.4 1.4 0 1 1 0 2.8 1.4 1.4 0 0 1 0-2.8zm11.6 0a1.4 1.4 0 1 1 0 2.8 1.4 1.4 0 0 1 0-2.8zM10 3.5c3.3 0 5.5 2 5.5 4.6 0 .6-.1 1.1-.3 1.6 1.3.7 2.3 2 2.3 3.6 0 2.6-3.4 4.7-7.5 4.7s-7.5-2.1-7.5-4.7c0-1.6 1-2.9 2.3-3.6-.2-.5-.3-1-.3-1.6C4.5 5.5 6.7 3.5 10 3.5zM7.6 12.2a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm4.8 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2zM7.8 7a.8.8 0 1 0 0 1.6.8.8 0 0 0 0-1.6zm4.4 0a.8.8 0 1 0 0 1.6.8.8 0 0 0 0-1.6z"/></svg>';
	}

	public static function menu() {
		add_menu_page(
			'Potamus Security',
			'Potamus Security',
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render' ),
			'data:image/svg+xml;base64,' . base64_encode( self::icon_svg() ),
			81
		);
	}

	public static function register() {
		register_setting(
			'potamus_security_group',
			Potamus_Settings::OPTION,
			array( 'sanitize_callback' => array( 'Potamus_Settings', 'sanitize' ) )
		);
	}

	public static function after_save() {
		Potamus_Settings::flush_cache();
		Potamus_Htaccess::write();
		Potamus_Integrity::sync_schedule();
		if ( Potamus_Updates::configured() ) {
			Potamus_Updates::sync_schedule();
		}
		// Limpa a cache do LiteSpeed Cache (e de outros plugins compatíveis) para as mudanças aparecerem já.
		do_action( 'litespeed_purge_all' );
		if ( function_exists( 'wp_cache_flush' ) ) {
			wp_cache_flush();
		}
	}

	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ) . '">Definições</a>' );
		return $links;
	}

	public static function assets( $hook ) {
		if ( 'toplevel_page_' . self::SLUG !== $hook ) {
			return;
		}
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_media();
		wp_enqueue_style( 'potamus-admin', POTAMUS_SECURITY_URL . 'assets/admin.css', array( 'wp-color-picker' ), POTAMUS_SECURITY_VERSION );
		wp_enqueue_script( 'potamus-login-style', POTAMUS_SECURITY_URL . 'assets/login-style.js', array( 'jquery', 'wp-color-picker' ), POTAMUS_SECURITY_VERSION, true );
		wp_localize_script( 'potamus-login-style', 'PotamusLS', array( 'defaults' => Potamus_Login_Style::defaults() ) );
		wp_enqueue_script( 'potamus-admin', POTAMUS_SECURITY_URL . 'assets/admin.js', array(), POTAMUS_SECURITY_VERSION, true );
		wp_localize_script( 'potamus-admin', 'PotamusDefaults', Potamus_Settings::defaults() );
		wp_localize_script(
			'potamus-admin',
			'PotamusInspect',
			array(
				'url'   => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'psec_inspect' ),
			)
		);
	}

	/* ---------- Verificações do painel ---------- */

	public static function checks() {
		$s      = Potamus_Settings::all();
		$checks = array();

		$php                = PHP_VERSION;
		$checks['php']      = array(
			'ok'    => version_compare( $php, '8.3', '>=' ),
			'title' => 'Versão do PHP: ' . $php,
			'tip'   => version_compare( $php, '8.3', '>=' ) ? 'Versão com suporte de segurança.' : 'Peça ao alojamento para mudar para PHP 8.4 ou 8.5.',
		);

		$checks['https'] = array(
			'ok'    => 0 === strpos( home_url(), 'https://' ),
			'title' => 'Ligação segura (HTTPS)',
			'tip'   => 0 === strpos( home_url(), 'https://' ) ? 'O site usa HTTPS.' : 'Ative o SSL no alojamento e mude o endereço do site para https://.',
		);

		$core     = get_site_transient( 'update_core' );
		$core_old = false;
		if ( $core && ! empty( $core->updates ) ) {
			foreach ( $core->updates as $u ) {
				if ( isset( $u->response ) && 'upgrade' === $u->response ) {
					$core_old = true;
				}
			}
		}
		$checks['core'] = array(
			'ok'    => ! $core_old,
			'title' => 'WordPress atualizado',
			'tip'   => $core_old ? 'Há uma nova versão do WordPress. Atualize em Painel → Atualizações.' : 'Está na versão mais recente.',
		);

		$plugins = get_site_transient( 'update_plugins' );
		$pending = ( $plugins && ! empty( $plugins->response ) ) ? count( $plugins->response ) : 0;
		$checks['plugins'] = array(
			'ok'    => 0 === $pending,
			'title' => 'Plugins atualizados',
			'tip'   => $pending ? sprintf( '%d plugin(s) à espera de atualização.', $pending ) : 'Nenhum plugin desatualizado.',
		);

		$admin_user = username_exists( 'admin' );
		$checks['admin_user'] = array(
			'ok'    => ! $admin_user,
			'title' => 'Sem utilizador "admin"',
			'tip'   => $admin_user ? 'É o primeiro nome que os atacantes tentam. Crie outro administrador e apague este.' : 'Muito bem.',
		);

		$debug = defined( 'WP_DEBUG' ) && WP_DEBUG && ( ! defined( 'WP_DEBUG_DISPLAY' ) || WP_DEBUG_DISPLAY );
		$checks['debug'] = array(
			'ok'    => ! $debug,
			'title' => 'Erros escondidos dos visitantes',
			'tip'   => $debug ? 'O WP_DEBUG está a mostrar erros no site. Desative-o no wp-config.php.' : 'Os erros não são mostrados publicamente.',
		);

		$checks['login'] = array(
			'ok'    => (bool) $s['login_enabled'],
			'title' => 'Endereço de login personalizado',
			'tip'   => $s['login_enabled'] ? 'O wp-login.php está escondido.' : 'Ative no separador Login.',
		);

		$checks['limit'] = array(
			'ok'    => (bool) $s['limit_login'],
			'title' => 'Limite de tentativas de login',
			'tip'   => $s['limit_login'] ? sprintf( '%d tentativas, depois bloqueio de %d minutos.', $s['max_attempts'], $s['lockout_minutes'] ) : 'Ative no separador Login.',
		);

		$hidden = $s['hide_versions'] && $s['clean_head'] && $s['strip_generators'];
		$checks['hide'] = array(
			'ok'    => $hidden,
			'title' => 'Versões e assinaturas escondidas',
			'tip'   => $hidden ? 'O código do site não anuncia versões.' : 'Ative as opções do separador Ocultar WordPress.',
		);

		$checks['xmlrpc'] = array(
			'ok'    => (bool) $s['disable_xmlrpc'],
			'title' => 'XML-RPC desativado',
			'tip'   => $s['disable_xmlrpc'] ? 'Porta antiga fechada.' : 'Desative-o, a não ser que use o Jetpack ou a app móvel.',
		);

		$checks['file_edit'] = array(
			'ok'    => defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT,
			'title' => 'Editor de ficheiros desligado',
			'tip'   => 'Impede que alguém com acesso ao painel altere código do tema ou plugins.',
		);

		$status = Potamus_Htaccess::status();
		$labels = array(
			'ok'           => 'Regras aplicadas no servidor (.htaccess).',
			'not_writable' => 'Não consegui escrever no .htaccess. As proteções correm em PHP, um pouco menos eficientes.',
			'unsupported'  => 'O servidor não usa .htaccess (ex.: Nginx). As proteções correm em PHP.',
			'unknown'      => 'Guarde as definições para aplicar as regras.',
			'reverted'     => 'O servidor rejeitou alguma regra e o site deu erro, por isso repus o .htaccess anterior. As proteções correm em PHP.',
		);
		$checks['htaccess'] = array(
			'ok'    => 'ok' === $status,
			'title' => 'Proteção ao nível do servidor',
			'tip'   => isset( $labels[ $status ] ) ? $labels[ $status ] : $labels['unknown'],
		);

		// 2FA do utilizador atual.
		$me_2fa = Potamus_TwoFA::user_has( get_current_user_id() );
		$checks['twofa'] = array(
			'ok'    => $s['twofa_enabled'] && $me_2fa,
			'title' => 'Verificação em dois passos na sua conta',
			'tip'   => ! $s['twofa_enabled'] ? 'Ative-a no separador Login.' : ( $me_2fa ? 'A sua conta pede um código da app ao entrar.' : 'Ative-a no seu perfil (Utilizadores → Perfil).' ),
		);

		// Integridade.
		$integrity = Potamus_Integrity::last();
		if ( ! $integrity ) {
			$i_ok  = false;
			$i_tip = 'Ainda não foi feita nenhuma verificação. Abra o separador Integridade.';
		} elseif ( 'error' === $integrity['status'] ) {
			$i_ok  = false;
			$i_tip = 'A última verificação não conseguiu comparar os ficheiros. Tente de novo no separador Integridade.';
		} else {
			$i_ok  = 'ok' === $integrity['status'];
			$i_tip = $i_ok ? sprintf( 'Ficheiros iguais aos oficiais (verificado em %s).', wp_date( 'j M Y, H:i', $integrity['time'] ) ) : 'Foram encontradas diferenças. Veja o separador Integridade.';
		}
		$checks['integrity'] = array(
			'ok'    => $i_ok,
			'title' => 'Ficheiros do WordPress intactos',
			'tip'   => $i_tip,
		);

		// Registo de utilizadores e função por defeito.
		$open    = (bool) get_option( 'users_can_register' );
		$role    = (string) get_option( 'default_role', 'subscriber' );
		$role_ok = in_array( $role, array( 'subscriber', 'customer' ), true );
		$checks['registration'] = array(
			'ok'    => ! $open || $role_ok,
			'title' => 'Registo de novos utilizadores seguro',
			'tip'   => ! $open ? 'O registo público está fechado.' : ( $role_ok ? sprintf( 'O registo está aberto com a função "%s". Se não precisa dele, feche-o em Definições → Geral.', $role ) : sprintf( 'Perigo: quem se registar fica com a função "%s". Mude para Subscritor em Definições → Geral.', $role ) ),
		);

		// wp-config.php.
		$config = file_exists( ABSPATH . 'wp-config.php' ) ? ABSPATH . 'wp-config.php' : dirname( ABSPATH ) . '/wp-config.php';
		if ( file_exists( $config ) ) {
			$perm = fileperms( $config ) & 0777;
			$checks['wpconfig'] = array(
				'ok'    => ! ( $perm & 0002 ),
				'title' => 'Permissões do wp-config.php: ' . substr( sprintf( '%o', $perm ), -3 ),
				'tip'   => ( $perm & 0002 ) ? 'Qualquer utilizador do servidor pode alterá-lo. Mude as permissões para 640 ou 600 no Gestor de Ficheiros.' : ( ( $perm & 0004 ) ? 'Não pode ser alterado por terceiros. Para mais segurança pode usar 640 ou 600, se o alojamento o permitir.' : 'Permissões restritas.' ),
			);
		}

		// debug.log.
		$log = WP_CONTENT_DIR . '/debug.log';
		if ( defined( 'WP_DEBUG_LOG' ) && is_string( WP_DEBUG_LOG ) ) {
			$log = WP_DEBUG_LOG;
		}
		$log_exists    = file_exists( $log );
		$log_protected = $s['protect_sensitive'] && Potamus_Htaccess::active();
		$checks['debuglog'] = array(
			'ok'    => ! $log_exists || $log_protected,
			'title' => 'Registo de erros (debug.log) protegido',
			'tip'   => ! $log_exists ? 'Não existe nenhum debug.log.' : ( $log_protected ? 'Existe, mas está bloqueado ao público. Pode apagá-lo se já não precisar dele.' : 'O debug.log pode estar acessível ao público e revelar caminhos e erros. Ative "Proteger ficheiros sensíveis" ou apague-o.' ),
		);

		// Definições de ameaças e vulnerabilidades conhecidas.
		if ( Potamus_Updates::configured() ) {
			$defs    = Potamus_Updates::definitions();
			$st      = Potamus_Updates::status();
			$fresh   = $defs && ! empty( $st['defs_checked'] ) && ( time() - (int) $st['defs_checked'] ) < 3 * DAY_IN_SECONDS;
			$checks['definitions'] = array(
				'ok'    => $fresh,
				'title' => 'Definições de ameaças atualizadas',
				'tip'   => $defs ? sprintf( 'Versão %s, verificada %s.', $defs['version'], ! empty( $st['defs_checked'] ) ? 'há ' . human_time_diff( (int) $st['defs_checked'] ) : 'há algum tempo' ) . ( $fresh ? '' : ' Veja o separador Atualizações.' ) : 'Ainda não foram descarregadas. Abra o separador Atualizações.',
			);
			$vulns = Potamus_Updates::vulnerable_items();
			$checks['vulns'] = array(
				'ok'    => $defs ? empty( $vulns ) : null,
				'title' => 'Plugins e temas sem vulnerabilidades conhecidas',
				'tip'   => ! $defs ? 'Disponível depois de descarregar as definições.' : ( $vulns ? sprintf( '%d com falhas conhecidas: %s. Atualize-os quanto antes.', count( $vulns ), implode( ', ', array_unique( wp_list_pluck( $vulns, 'name' ) ) ) ) : 'Nenhum dos plugins e temas instalados consta da lista.' ),
			);
		}

		// Prefixo das tabelas: só informativo, mudar a meio da vida do site é arriscado.
		global $wpdb;
		$checks['prefix'] = array(
			'ok'    => null,
			'title' => 'Prefixo das tabelas: ' . $wpdb->prefix,
			'tip'   => 'wp_' === $wpdb->prefix ? 'É o prefixo por defeito. Não é um problema por si só e mudá-lo num site já feito é arriscado, por isso não conta para a pontuação.' : 'Prefixo personalizado.',
		);

		return $checks;
	}

	/* ---------- Componentes ---------- */

	private static function toggle( $key, $title, $desc, $recommended = true, $extra = '' ) {
		$s  = Potamus_Settings::all();
		$id = 'psec-' . $key;
		?>
		<div class="psec-row">
			<div class="psec-row__text">
				<label for="<?php echo esc_attr( $id ); ?>" class="psec-row__title">
					<?php echo esc_html( $title ); ?>
					<?php if ( $recommended ) : ?><span class="psec-badge">Recomendado</span><?php endif; ?>
				</label>
				<p class="psec-row__desc"><?php echo wp_kses_post( $desc ); ?></p>
				<?php echo $extra; // phpcs:ignore WordPress.Security.EscapeOutput -- HTML montado internamente. ?>
			</div>
			<label class="psec-switch">
				<input type="checkbox" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( Potamus_Settings::OPTION . '[' . $key . ']' ); ?>" value="1" data-key="<?php echo esc_attr( $key ); ?>" <?php checked( 1, (int) $s[ $key ] ); ?>>
				<span class="psec-switch__track" aria-hidden="true"></span>
			</label>
		</div>
		<?php
	}

	private static function name( $key ) {
		return esc_attr( Potamus_Settings::OPTION . '[' . $key . ']' );
	}

	/* ---------- Atualizações ---------- */

	private static function render_updates() {
		$configured = Potamus_Updates::configured();
		$st         = Potamus_Updates::status();
		$defs       = Potamus_Updates::definitions();
		$check_url  = wp_nonce_url( admin_url( 'admin-post.php?action=potamus_check_now' ), 'potamus_check_now' );
		$severity   = array( 'critical' => 'Crítica', 'high' => 'Alta', 'medium' => 'Média', 'low' => 'Baixa' );
		?>
		<div class="psec-card">
			<h2>Atualizações do Potamus Security</h2>
			<p class="psec-muted">As versões novas e as definições de ameaças são publicadas pela CodiPotamus e assinadas digitalmente. O plugin só aceita ficheiros com uma assinatura válida, por isso nem uma cópia adulterada nem um servidor invadido conseguem instalar código no seu site.</p>
			<?php if ( ! $configured ) : ?>
				<div class="psec-result psec-result--none"><strong>Canal de atualizações ainda não configurado.</strong> Esta cópia do plugin não tem repositório ou chave pública definidos, por isso não procura atualizações nem definições.</div>
			<?php else : ?>
				<ul class="psec-facts">
					<li><span>Versão instalada</span><?php echo esc_html( POTAMUS_SECURITY_VERSION ); ?></li>
					<?php $latest = ! empty( $st['update_latest'] ) && version_compare( $st['update_latest'], POTAMUS_SECURITY_VERSION, '>' ) ? $st['update_latest'] : POTAMUS_SECURITY_VERSION; ?>
					<li><span>Versão mais recente</span><?php echo esc_html( $latest ); ?></li>
					<li><span>Última verificação</span><?php echo esc_html( ! empty( $st['update_checked'] ) ? 'há ' . human_time_diff( (int) $st['update_checked'] ) : '—' ); ?></li>
					<li><span>Origem</span><a href="<?php echo esc_url( 'https://github.com/' . Potamus_Updates::repo() ); ?>" target="_blank" rel="noopener"><?php echo esc_html( Potamus_Updates::repo() ); ?></a></li>
				</ul>
				<?php if ( ! empty( $st['update_error'] ) ) : ?>
					<div class="psec-result psec-result--warn"><?php echo esc_html( $st['update_error'] ); ?></div>
				<?php elseif ( ! empty( $st['update_checked'] ) && version_compare( $latest, POTAMUS_SECURITY_VERSION, '<=' ) ) : ?>
					<div class="psec-result psec-result--ok"><strong>Está na versão mais recente.</strong> Ainda não há nenhuma versão nova publicada.</div>
				<?php endif; ?>
				<p class="psec-integrity-actions"><a class="button button-primary" href="<?php echo esc_url( $check_url ); ?>">Procurar agora</a><span class="psec-muted">Procura uma versão nova e atualiza as definições.</span></p>
			<?php endif; ?>
		</div>

		<div class="psec-card">
			<?php
			self::toggle( 'auto_update_self', 'Atualizar automaticamente', 'Instala as versões novas do Potamus Security assim que são publicadas, depois de confirmar a assinatura. Recomendado num plugin de segurança.' );
			self::toggle( 'definitions_daily', 'Atualizar as definições de ameaças todos os dias', 'Descarrega uma vez por dia a lista de padrões de código malicioso e de plugins e temas com falhas conhecidas. É um ficheiro pequeno e a comparação é feita no seu site: nada sobre o site é enviado para fora.' );
			?>
		</div>

		<?php if ( $configured ) : ?>
		<div class="psec-card">
			<h2>Definições de ameaças</h2>
			<?php if ( ! $defs ) : ?>
				<div class="psec-result psec-result--none"><strong>Ainda não foram descarregadas.</strong> Carregue em "Procurar agora".</div>
			<?php else : ?>
				<ul class="psec-facts">
					<li><span>Versão</span><?php echo esc_html( $defs['version'] ); ?></li>
					<li><span>Padrões de código malicioso</span><?php echo esc_html( count( $defs['patterns'] ) ); ?> extra</li>
					<li><span>Vulnerabilidades conhecidas</span><?php echo esc_html( count( $defs['vulnerabilities'] ) ); ?></li>
					<li><span>Última verificação</span><?php echo esc_html( ! empty( $st['defs_checked'] ) ? 'há ' . human_time_diff( (int) $st['defs_checked'] ) : '—' ); ?></li>
				</ul>
				<?php
				$vulns = Potamus_Updates::vulnerable_items();
				if ( $vulns ) :
					?>
					<div class="psec-result psec-result--bad"><strong>Atenção:</strong> há plugins ou temas instalados com falhas de segurança conhecidas. Atualize-os em Painel → Atualizações.</div>
					<ul class="psec-findings">
						<?php foreach ( $vulns as $v ) : ?>
							<li class="is-<?php echo esc_attr( in_array( $v['severity'], array( 'critical', 'high' ), true ) ? 'high' : 'medium' ); ?>">
								<strong><?php echo esc_html( $v['name'] . ' ' . $v['installed'] ); ?></strong>
								<span><?php echo esc_html( sprintf( 'Gravidade %s · %s%s', $severity[ $v['severity'] ], $v['title'] ? $v['title'] : 'falha conhecida', $v['fixed_in'] ? ' · corrigido na ' . $v['fixed_in'] : ' · ainda sem correção' ) ); ?><?php if ( $v['url'] ) : ?> · <a href="<?php echo esc_url( $v['url'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $v['cve'] ? $v['cve'] : 'detalhes' ); ?></a><?php endif; ?></span>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php else : ?>
					<div class="psec-result psec-result--ok"><strong>Nenhum plugin ou tema instalado consta da lista de vulnerabilidades conhecidas.</strong></div>
				<?php endif; ?>
			<?php endif; ?>
			<?php if ( ! empty( $st['defs_error'] ) ) : ?>
				<div class="psec-result psec-result--warn"><?php echo esc_html( $st['defs_error'] ); ?></div>
			<?php endif; ?>
		</div>
		<?php endif; ?>
		<?php
	}

	/* ---------- Aparência do login ---------- */

	private static function color_field( $key, $label ) {
		$s = Potamus_Settings::all();
		printf(
			'<div class="psec-color-field"><span class="psec-color-field__label">%1$s</span><input type="text" class="psec-color" aria-label="%1$s" name="%2$s" value="%3$s" data-key="%4$s" data-default-color="%5$s"></div>',
			esc_html( $label ),
			self::name( $key ), // phpcs:ignore WordPress.Security.EscapeOutput -- esc_attr em name().
			esc_attr( $s[ $key ] ),
			esc_attr( $key ),
			esc_attr( Potamus_Login_Style::defaults()[ $key ] )
		);
	}

	private static function media_field( $key, $label, $empty_text ) {
		$s   = Potamus_Settings::all();
		$id  = (int) $s[ $key ];
		$src = $id ? wp_get_attachment_image_src( $id, 'medium' ) : false;
		$url = $src ? $src[0] : '';
		?>
		<div class="psec-media" data-key="<?php echo esc_attr( $key ); ?>">
			<span class="psec-media__label"><?php echo esc_html( $label ); ?></span>
			<div class="psec-media__box">
				<div class="psec-media__thumb"><?php if ( $url ) : ?><img src="<?php echo esc_url( $url ); ?>" alt=""><?php else : ?><span><?php echo esc_html( $empty_text ); ?></span><?php endif; ?></div>
				<div class="psec-media__actions">
					<button type="button" class="button psec-media__pick">Escolher imagem</button>
					<button type="button" class="button-link psec-media__remove" <?php echo $url ? '' : 'hidden'; ?>>Remover</button>
				</div>
			</div>
			<input type="hidden" name="<?php echo self::name( $key ); // phpcs:ignore ?>" value="<?php echo esc_attr( $id ); ?>" data-url="<?php echo esc_attr( $url ); ?>">
		</div>
		<?php
	}

	private static function range_field( $key, $label, $min, $max, $unit = 'px' ) {
		$s = Potamus_Settings::all();
		printf(
			'<label class="psec-range"><span>%1$s <output>%2$d%5$s</output></span><input type="range" min="%3$d" max="%4$d" name="%6$s" value="%2$d" data-key="%7$s" data-unit="%5$s"></label>',
			esc_html( $label ),
			(int) $s[ $key ],
			(int) $min,
			(int) $max,
			esc_html( $unit ),
			self::name( $key ), // phpcs:ignore
			esc_attr( $key )
		);
	}

	private static function render_appearance() {
		$s = Potamus_Settings::all();
		?>
		<div class="psec-ls">
			<div class="psec-ls__settings">
				<div class="psec-card">
					<?php
					$view = '<p class="psec-help"><a href="' . esc_url( wp_login_url() ) . '" target="_blank" rel="noopener">Abrir a página de login num novo separador ↗</a> (guarde primeiro para ver as alterações)</p>';
					self::toggle( 'ls_enabled', 'Personalizar a página de login', 'Aplica o logótipo, o fundo, os cantos e as cores escolhidos abaixo. Também se aplica ao ecrã da verificação em dois passos. Ao desligar, volta o aspeto normal do WordPress.', false, $view );
					?>
				</div>

				<div class="psec-card">
					<h2>Logótipo</h2>
					<?php self::media_field( 'ls_logo_id', 'Imagem', 'Logótipo do WordPress' ); ?>
					<?php self::range_field( 'ls_logo_width', 'Largura', 40, 320 ); ?>
					<label class="psec-text-field"><span>Link do logótipo</span>
						<input type="url" class="regular-text" name="<?php echo self::name( 'ls_logo_link' ); // phpcs:ignore ?>" value="<?php echo esc_attr( $s['ls_logo_link'] ); ?>" placeholder="<?php echo esc_attr( home_url( '/' ) ); ?>">
						<small>Se ficar vazio, leva para a página inicial do site.</small>
					</label>
				</div>

				<div class="psec-card">
					<h2>Fundo</h2>
					<div class="psec-segmented" role="radiogroup">
						<?php foreach ( array( 'color' => 'Cor', 'gradient' => 'Degradê', 'image' => 'Imagem' ) as $val => $label ) : ?>
							<label><input type="radio" name="<?php echo self::name( 'ls_bg_type' ); // phpcs:ignore ?>" value="<?php echo esc_attr( $val ); ?>" <?php checked( $s['ls_bg_type'], $val ); ?>><span><?php echo esc_html( $label ); ?></span></label>
						<?php endforeach; ?>
					</div>
					<div class="psec-color-grid">
						<?php self::color_field( 'ls_bg_color', 'Cor de fundo' ); ?>
						<div class="psec-when" data-when="gradient"><?php self::color_field( 'ls_bg_color2', 'Segunda cor' ); ?></div>
					</div>
					<div class="psec-when" data-when="image">
						<?php self::media_field( 'ls_bg_image_id', 'Imagem de fundo', 'Sem imagem' ); ?>
						<?php self::range_field( 'ls_bg_overlay', 'Escurecer a imagem', 0, 80, '%' ); ?>
						<p class="psec-help">Escurecer ajuda a ler os links por baixo do formulário. A cor de fundo é usada enquanto a imagem carrega.</p>
					</div>
				</div>

				<div class="psec-card">
					<h2>Cantos arredondados</h2>
					<?php self::range_field( 'ls_radius_box', 'Caixa do formulário', 0, 40 ); ?>
					<?php self::range_field( 'ls_radius_fields', 'Campos e botão', 0, 30 ); ?>
				</div>

				<div class="psec-card">
					<h2>Cores</h2>
					<div class="psec-color-grid">
						<?php
						self::color_field( 'ls_form_bg', 'Fundo do formulário' );
						self::color_field( 'ls_text', 'Texto' );
						self::color_field( 'ls_input_bg', 'Fundo dos campos' );
						self::color_field( 'ls_input_border', 'Contorno dos campos' );
						self::color_field( 'ls_button_bg', 'Botão' );
						self::color_field( 'ls_button_text', 'Texto do botão' );
						self::color_field( 'ls_link', 'Links' );
						self::color_field( 'ls_accent', 'Destaque das mensagens' );
						?>
					</div>
					<p><button type="button" class="button-link psec-ls-reset">Repor o aspeto original do WordPress</button></p>
				</div>
			</div>

			<div class="psec-ls__preview">
				<div class="psec-ls__sticky">
					<span class="psec-ls__caption">Pré-visualização</span>
					<div class="psec-lp" id="psec-lp">
						<div class="psec-lp__inner">
							<a class="psec-lp__logo" tabindex="-1"><img alt="" hidden><svg viewBox="0 0 80 80" aria-hidden="true"><circle cx="40" cy="40" r="37" fill="none" stroke="currentColor" stroke-width="3"/><path fill="currentColor" d="M16 26h9l8 26 6-17-3-9h8l9 26 7-26h8L56 60h-6l-8-23-8 23h-6z"/></svg></a>
							<div class="psec-lp__form">
								<span class="psec-lp__label">Nome de utilizador ou endereço de email</span>
								<span class="psec-lp__input"></span>
								<span class="psec-lp__label">Senha</span>
								<span class="psec-lp__input"></span>
								<div class="psec-lp__row"><span class="psec-lp__check"></span><span class="psec-lp__label">Lembrar-me</span><span class="psec-lp__btn">Iniciar sessão</span></div>
							</div>
							<div class="psec-lp__msg">Mensagens e avisos</div>
							<div class="psec-lp__links"><span>Esqueceu-se da senha?</span><span>← Ir para <?php echo esc_html( get_bloginfo( 'name' ) ); ?></span></div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/* ---------- Integridade ---------- */

	private static function inspect_url( $file ) {
		return wp_nonce_url( admin_url( 'admin.php?page=' . self::SLUG . '&psec_tab=integrity&psec_inspect=' . rawurlencode( $file ) ), 'psec_inspect' );
	}

	/** Conteúdo da inspeção (usado na janela e na página de recurso sem JavaScript). */
	private static function inspection_body( $file ) {
		$i = Potamus_Integrity::inspect( $file );
		ob_start();
		if ( is_wp_error( $i ) ) {
			echo '<p>' . esc_html( $i->get_error_message() ) . '</p>';
			return ob_get_clean();
		}
		$verdicts = array(
			'clean'  => array( 'ok', 'Sem sinais de código malicioso', 'Não foi encontrado nenhum dos padrões habituais de código malicioso. Mesmo assim, se o ficheiro não é seu e não precisa dele, pode apagá-lo.' ),
			'medium' => array( 'warn', 'A rever', 'Tem instruções que o código legítimo também usa, mas que aparecem com frequência em código malicioso. Veja as linhas indicadas ou peça ajuda antes de decidir.' ),
			'high'   => array( 'bad', 'Suspeito', 'Tem padrões típicos de código malicioso. Não o abra no browser. Faça uma cópia de segurança, apague-o e mude as palavras-passe do WordPress e do alojamento.' ),
		);
		$v = $verdicts[ $i['verdict'] ];
		?>
		<p class="psec-muted">O ficheiro foi lido como texto, sem ser executado.</p>
		<div class="psec-result psec-result--<?php echo esc_attr( $v[0] ); ?>"><strong><?php echo esc_html( $v[1] ); ?>.</strong> <?php echo esc_html( $v[2] ); ?></div>
		<ul class="psec-facts">
			<li><span>Tamanho</span><?php echo esc_html( size_format( $i['size'], 1 ) ); ?></li>
			<li><span>Linhas</span><?php echo esc_html( $i['lines'] ); ?></li>
			<li><span>Última alteração</span><?php echo esc_html( wp_date( 'j M Y, H:i', $i['modified'] ) ); ?></li>
			<li><span>Permissões</span><?php echo esc_html( $i['perms'] ); ?></li>
			<li><span>Contém PHP</span><?php echo $i['is_php'] ? 'Sim' : 'Não'; ?></li>
		</ul>
		<?php if ( $i['findings'] ) : ?>
			<h3>O que foi encontrado</h3>
			<ul class="psec-findings">
				<?php foreach ( $i['findings'] as $f ) : ?>
					<li class="is-<?php echo esc_attr( $f['level'] ); ?>"><strong><?php echo esc_html( $f['label'] ); ?></strong> <span><?php echo esc_html( sprintf( '%d vez(es) · linha(s) %s', $f['count'], implode( ', ', $f['lines'] ) ) ); ?></span></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
		<details class="psec-files"><summary>Ver conteúdo<?php echo $i['truncated'] ? ' (primeiras 200 linhas)' : ''; ?></summary>
			<pre class="psec-code"><?php echo esc_html( $i['preview'] ); ?></pre>
		</details>
		<?php
		return ob_get_clean();
	}

	/** Pedido da janela (lightbox). */
	public static function ajax_inspect() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'html' => '<p>Sem permissão.</p>' ), 403 );
		}
		check_ajax_referer( 'psec_inspect' );
		$file = isset( $_GET['file'] ) ? sanitize_text_field( wp_unslash( $_GET['file'] ) ) : '';
		wp_send_json_success( array( 'html' => self::inspection_body( $file ) ) );
	}

	/** Recurso sem JavaScript: a inspeção aparece na própria página. */
	private static function render_inspection() {
		// phpcs:disable WordPress.Security.NonceVerification
		if ( empty( $_GET['psec_inspect'] ) ) {
			return;
		}
		$file = sanitize_text_field( wp_unslash( $_GET['psec_inspect'] ) );
		// phpcs:enable
		if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_key( $_GET['_wpnonce'] ), 'psec_inspect' ) ) {
			return;
		}
		$back = admin_url( 'admin.php?page=' . self::SLUG . '&psec_tab=integrity' );
		echo '<div class="psec-card psec-inspect"><h2>Inspeção: <code>' . esc_html( $file ) . '</code></h2>';
		echo self::inspection_body( $file ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado em inspection_body().
		echo '<p><a class="button" href="' . esc_url( $back ) . '">← Voltar à verificação</a></p></div>';
	}

	/** Janela (lightbox) onde a inspeção é mostrada. */
	private static function render_inspect_dialog() {
		?>
		<dialog class="psec-dialog" id="psec-dialog" aria-labelledby="psec-dialog-title">
			<div class="psec-dialog__head">
				<h2 id="psec-dialog-title">Inspeção: <code class="psec-dialog__file"></code></h2>
				<button type="button" class="psec-dialog__close" aria-label="Fechar">×</button>
			</div>
			<div class="psec-dialog__body"></div>
		</dialog>
		<?php
	}

	private static function render_integrity() {
		self::render_inspection();
		self::render_inspect_dialog();
		$r   = Potamus_Integrity::last();
		$run = wp_nonce_url( admin_url( 'admin-post.php?action=potamus_integrity' ), 'potamus_integrity' );
		$labels = array(
			'modified' => array( 'Ficheiros alterados', 'Diferentes do original. Se não os editou de propósito, podem ter sido modificados por um atacante.' ),
			'missing'  => array( 'Ficheiros em falta', 'Fazem parte do WordPress mas não estão no servidor. Reinstale o WordPress em Painel → Atualizações.' ),
			'extra'    => array( 'Ficheiros desconhecidos', 'Não fazem parte do WordPress e estão em pastas do núcleo (ou são .php na raiz). Alguns podem ser legítimos (verificações do Google, ferramentas do alojamento), mas convém confirmar.' ),
		);
		?>
		<div class="psec-card">
			<h2>Integridade do WordPress</h2>
			<p class="psec-muted">Compara cada ficheiro do núcleo do WordPress com a versão oficial do WordPress.org, para detetar código injetado ou ficheiros alterados. Não verifica temas nem plugins.</p>

			<?php if ( ! $r ) : ?>
				<div class="psec-result psec-result--none"><strong>Ainda não foi feita nenhuma verificação.</strong></div>
			<?php elseif ( 'error' === $r['status'] ) : ?>
				<div class="psec-result psec-result--warn"><strong>Não foi possível verificar.</strong> <?php echo esc_html( $r['message'] ); ?></div>
			<?php elseif ( 'ok' === $r['status'] ) : ?>
				<div class="psec-result psec-result--ok"><strong>Tudo em ordem.</strong> <?php echo esc_html( sprintf( '%d ficheiros do WordPress %s verificados, sem alterações suspeitas.', $r['checked'], $r['version'] ) ); ?></div>
			<?php else : ?>
				<div class="psec-result psec-result--warn"><strong>Foram encontradas diferenças.</strong> <?php echo esc_html( sprintf( 'WordPress %s · %d ficheiros verificados.', $r['version'], $r['checked'] ) ); ?></div>
				<?php foreach ( $labels as $key => $label ) : ?>
					<?php if ( ! empty( $r[ $key ] ) ) : ?>
						<details class="psec-files" <?php echo 'modified' === $key ? 'open' : ''; ?>>
							<summary><?php echo esc_html( sprintf( '%s (%d)', $label[0], count( $r[ $key ] ) ) ); ?></summary>
							<p class="psec-muted"><?php echo esc_html( $label[1] ); ?></p>
							<ul><?php foreach ( $r[ $key ] as $f ) : ?><li><code><?php echo esc_html( $f ); ?></code> <a class="psec-inspect-link" href="<?php echo esc_url( self::inspect_url( $f ) ); ?>" data-file="<?php echo esc_attr( $f ); ?>">Inspecionar</a></li><?php endforeach; ?></ul>
						</details>
					<?php endif; ?>
				<?php endforeach; ?>
			<?php endif; ?>

			<?php if ( $r && ! empty( $r['localized'] ) ) : ?>
				<?php $lang = ! empty( $r['locale'] ) ? Potamus_Integrity::language_label( $r['locale'] ) : ''; ?>
				<p class="psec-muted"><?php echo esc_html( sprintf( '%d ficheiro(s) traduzido(s) (%s) são diferentes da versão inglesa, como é normal no WordPress %s. Foram analisados à parte e não têm código suspeito.', count( $r['localized'] ), implode( ', ', $r['localized'] ), $lang ? 'em ' . $lang : 'traduzido' ) ); ?></p>
			<?php endif; ?>

			<p class="psec-integrity-actions">
				<a href="<?php echo esc_url( $run ); ?>" class="button button-primary psec-run">Verificar agora</a>
				<?php if ( $r ) : ?><span class="psec-muted"><?php echo esc_html( 'Última verificação: ' . wp_date( 'j M Y, H:i', $r['time'] ) ); ?></span><?php endif; ?>
			</p>
		</div>

		<div class="psec-card">
			<?php self::toggle( 'integrity_weekly', 'Verificação automática semanal', 'Repete a verificação uma vez por semana, em segundo plano. O resultado aparece no Painel. Demora poucos segundos e não afeta os visitantes.' ); ?>
		</div>
		<?php
	}

	/* ---------- Página ---------- */

	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s       = Potamus_Settings::all();
		$checks  = self::checks();
		$scored  = array_filter( $checks, function ( $c ) { return null !== $c['ok']; } );
		$passed  = count( array_filter( wp_list_pluck( $scored, 'ok' ) ) );
		$score   = (int) round( $passed / max( 1, count( $scored ) ) * 100 );
		$level   = $score >= 80 ? 'good' : ( $score >= 50 ? 'fair' : 'poor' );
		$mood    = array(
			'good' => 'O seu hipopótamo está tranquilo. O site está bem protegido.',
			'fair' => 'O hipopótamo está atento. Há alguns pontos a melhorar.',
			'poor' => 'O hipopótamo está preocupado. Vale a pena tratar dos pontos abaixo.',
		);
		$lockouts = (int) get_option( 'potamus_security_lockouts', 0 );
		$circ     = 2 * M_PI * 52;
		?>
		<div class="wrap psec">
			<header class="psec-header">
				<span class="psec-logo"><?php echo self::icon_svg( 'currentColor' ); // phpcs:ignore ?></span>
				<div>
					<h1>Potamus Security</h1>
					<p>Navegue com o Potamus nas águas turvas da segurança.<br>Com uma segurança simples mas eficaz do seu WordPress.</p>
				</div>
			</header>
			<hr class="wp-header-end">

			<?php settings_errors(); ?>

			<nav class="psec-tabs" role="tablist">
				<button type="button" class="psec-tab is-active" data-tab="dashboard" role="tab">Painel</button>
				<button type="button" class="psec-tab" data-tab="hide" role="tab">Ocultar WordPress</button>
				<button type="button" class="psec-tab" data-tab="login" role="tab">Login</button>
				<button type="button" class="psec-tab" data-tab="appearance" role="tab">Aparência do login</button>
				<button type="button" class="psec-tab" data-tab="protect" role="tab">Proteções</button>
				<button type="button" class="psec-tab" data-tab="integrity" role="tab">Integridade</button>
				<button type="button" class="psec-tab" data-tab="updates" role="tab">Atualizações</button>
			</nav>

			<section class="psec-panel is-active" data-panel="dashboard">
				<div class="psec-card psec-score psec-score--<?php echo esc_attr( $level ); ?>">
					<div class="psec-ring-wrap">
					<svg class="psec-ring" viewBox="0 0 120 120" aria-hidden="true">
						<circle cx="60" cy="60" r="52" class="psec-ring__bg"/>
						<circle cx="60" cy="60" r="52" class="psec-ring__fg" stroke-dasharray="<?php echo esc_attr( $circ ); ?>" stroke-dashoffset="<?php echo esc_attr( $circ * ( 1 - $score / 100 ) ); ?>"/>
					</svg>
					<div class="psec-score__num"><?php echo esc_html( $score ); ?><small>%</small></div>
					</div>
					<div class="psec-score__text">
						<h2>Nível de proteção</h2>
						<p><?php echo esc_html( $mood[ $level ] ); ?></p>
						<p class="psec-muted"><?php echo esc_html( sprintf( '%d de %d verificações em ordem · %d bloqueio(s) de login desde a instalação', $passed, count( $scored ), $lockouts ) ); ?></p>
					</div>
				</div>

				<?php if ( $s['login_enabled'] && ! Potamus_Login::recovery_mode() ) : ?>
					<div class="psec-card psec-loginbox">
						<div>
							<strong>O seu endereço de login</strong>
							<code id="psec-login-url"><?php echo esc_html( Potamus_Login::login_url() ); ?></code>
						</div>
						<button type="button" class="button" data-copy="#psec-login-url">Copiar</button>
					</div>
				<?php endif; ?>

				<?php if ( Potamus_Login::recovery_mode() ) : ?>
					<div class="notice notice-warning inline"><p>O modo de recuperação está ativo (<code>POTAMUS_SECURITY_RECOVERY</code> no wp-config.php): o endereço de login personalizado está desligado.</p></div>
				<?php endif; ?>

				<div class="psec-card">
					<h2>Verificações</h2>
					<ul class="psec-checks">
						<?php foreach ( $checks as $c ) : ?>
							<?php $state = null === $c['ok'] ? 'info' : ( $c['ok'] ? 'ok' : 'warn' ); ?>
							<li class="is-<?php echo esc_attr( $state ); ?>">
								<span class="psec-dot" aria-hidden="true"><?php echo 'ok' === $state ? '✓' : ( 'info' === $state ? 'i' : '!' ); ?></span>
								<div><strong><?php echo esc_html( $c['title'] ); ?></strong><span><?php echo esc_html( $c['tip'] ); ?></span></div>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			</section>

			<form method="post" action="options.php" class="psec-form">
				<?php settings_fields( 'potamus_security_group' ); ?>

				<section class="psec-panel" data-panel="hide">
					<div class="psec-card">
						<h2>Ocultar WordPress</h2>
						<p class="psec-muted">Tira do código do site as pistas que os robôs usam para saber que é WordPress e que versão tem.</p>
						<?php
						self::toggle( 'hide_versions', 'Esconder versões', 'Remove a versão do WordPress do código e troca o "?ver=" dos ficheiros CSS e JS por um código neutro. A cache do browser continua a funcionar.' );
						self::toggle( 'clean_head', 'Limpar cabeçalhos e código', 'Remove o cabeçalho <code>X-Powered-By</code> (que mostra a versão do PHP), as ligações para a <code>wp-json</code>, o shortlink e outras linhas desnecessárias.' );
						self::toggle( 'strip_generators', 'Remover assinaturas de plugins', 'Apaga as etiquetas "generator" que o Elementor e outros plugins acrescentam ao código.' );
						self::toggle( 'block_files', 'Bloquear ficheiros reveladores', 'O <code>readme.html</code> e o <code>license.txt</code> mostram a versão do WordPress. Passam a dar erro 404.' );
						self::toggle( 'block_author_enum', 'Esconder nomes de utilizador', 'Bloqueia os truques <code>?author=1</code>, a lista de utilizadores da API e o sitemap de autores, que revelam os nomes usados para entrar.' );
						?>
					</div>
				</section>

				<section class="psec-panel" data-panel="login">
					<div class="psec-card">
						<h2>Login</h2>
						<?php
						$slug_field  = '<div class="psec-inline">';
						$slug_field .= '<span class="psec-prefix">' . esc_html( trailingslashit( home_url() ) ) . '</span>';
						$slug_field .= '<input type="text" class="regular-text psec-slug" name="' . self::name( 'login_slug' ) . '" value="' . esc_attr( $s['login_slug'] ) . '" spellcheck="false">';
						$slug_field .= '</div>';
						$slug_field .= '<p class="psec-help">⚠️ Guarde o novo endereço nos favoritos. Se o perder, acrescente <code>define( \'POTAMUS_SECURITY_RECOVERY\', true );</code> ao <code>wp-config.php</code> (ou mude o nome da pasta do plugin pelo Gestor de Ficheiros) para voltar a entrar pelo wp-login.php.</p>';
						self::toggle( 'login_enabled', 'Endereço de login personalizado', 'O <code>wp-login.php</code> e o <code>/wp-admin</code> deixam de existir para quem não tem sessão iniciada. Só se entra pelo endereço que escolher.', true, $slug_field );

						$limit_fields  = '<div class="psec-inline">';
						$limit_fields .= '<label>Tentativas <input type="number" min="2" max="20" name="' . self::name( 'max_attempts' ) . '" value="' . esc_attr( $s['max_attempts'] ) . '"></label>';
						$limit_fields .= '<label>Bloqueio (minutos) <input type="number" min="5" max="1440" name="' . self::name( 'lockout_minutes' ) . '" value="' . esc_attr( $s['lockout_minutes'] ) . '"></label>';
						$limit_fields .= '</div>';
						self::toggle( 'limit_login', 'Limitar tentativas de login', 'Depois de várias palavras-passe erradas seguidas, o endereço IP fica bloqueado durante algum tempo. Trava ataques de força bruta.', true, $limit_fields );

						self::toggle( 'generic_errors', 'Mensagens de erro neutras', 'Em vez de "utilizador não existe" ou "palavra-passe errada", mostra sempre "dados de acesso inválidos". Assim não se descobre quais os utilizadores que existem.' );
						?>
					</div>

					<div class="psec-card">
						<h2>Verificação em dois passos (2FA)</h2>
						<p class="psec-muted">Mesmo que alguém descubra a palavra-passe, não entra sem o código que muda a cada 30 segundos na app do telemóvel.</p>
						<?php
						$me_link = '<p class="psec-help">' . ( Potamus_TwoFA::user_has( get_current_user_id() ) ? '✓ Já está ativa na sua conta.' : '→ <a href="' . esc_url( admin_url( 'profile.php#potamus-2fa' ) ) . '">Configurar na minha conta</a>' ) . '</p>';
						self::toggle( 'twofa_enabled', 'Permitir verificação em dois passos', 'Cada utilizador pode ativá-la no seu perfil, com Google Authenticator, Microsoft Authenticator, 1Password, etc. Só é pedida a quem a ativou. Inclui 8 códigos de recuperação.', true, $me_link );
						self::toggle( 'twofa_force_admins', 'Obrigatória para administradores', 'Os administradores sem 2FA são levados para o perfil depois de entrar e veem um aviso até a configurarem. Não bloqueia o acesso.', false );
						?>
					</div>

					<details class="psec-card psec-advanced">
						<summary>Avançado: origem do endereço IP</summary>
						<p class="psec-muted">Só mude isto se o site estiver atrás de um proxy ou CDN e os bloqueios estiverem a apanhar toda a gente. Endereço visto agora: <code><?php echo esc_html( Potamus_Login::client_ip() ); ?></code></p>
						<select name="<?php echo self::name( 'ip_source' ); // phpcs:ignore ?>">
							<?php
							$sources = array(
								'remote_addr'      => 'Ligação direta (REMOTE_ADDR) — recomendado',
								'x_forwarded_for'  => 'X-Forwarded-For',
								'x_real_ip'        => 'X-Real-IP',
								'cf_connecting_ip' => 'Cloudflare (CF-Connecting-IP)',
							);
							foreach ( $sources as $val => $label ) {
								$seen = '';
								$map  = array( 'remote_addr' => 'REMOTE_ADDR', 'x_forwarded_for' => 'HTTP_X_FORWARDED_FOR', 'x_real_ip' => 'HTTP_X_REAL_IP', 'cf_connecting_ip' => 'HTTP_CF_CONNECTING_IP' );
								if ( ! empty( $_SERVER[ $map[ $val ] ] ) ) {
									$seen = ' → ' . sanitize_text_field( wp_unslash( $_SERVER[ $map[ $val ] ] ) );
								}
								printf( '<option value="%s" %s>%s%s</option>', esc_attr( $val ), selected( $s['ip_source'], $val, false ), esc_html( $label ), esc_html( $seen ) );
							}
							?>
						</select>
					</details>
				</section>

				<section class="psec-panel" data-panel="protect">
					<div class="psec-card">
						<h2>Proteções</h2>
						<?php
						self::toggle( 'disable_xmlrpc', 'Desativar XML-RPC', 'Porta antiga muito usada em ataques. Só a deixe ligada se usar o Jetpack ou a app móvel do WordPress.' );

						$rest  = '<div class="psec-radios">';
						$modes = array(
							'users'   => array( 'Esconder só a lista de utilizadores', 'Recomendado. Não interfere com nenhum plugin.' ),
							'private' => array( 'Só para quem tem sessão iniciada', 'Mais fechado. Pode afetar formulários ou plugins que usam a API para visitantes.' ),
							'open'    => array( 'Aberta', 'Comportamento normal do WordPress.' ),
						);
						foreach ( $modes as $val => $m ) {
							$rest .= '<label class="psec-radio"><input type="radio" name="' . self::name( 'rest_mode' ) . '" value="' . esc_attr( $val ) . '" ' . checked( $s['rest_mode'], $val, false ) . '><span><strong>' . esc_html( $m[0] ) . '</strong>' . esc_html( $m[1] ) . '</span></label>';
						}
						$rest .= '<div class="psec-rest-allow"><label>Exceções (uma por linha, ex.: <code>contact-form-7</code>)</label><textarea rows="3" name="' . self::name( 'rest_allow' ) . '">' . esc_textarea( $s['rest_allow'] ) . '</textarea></div>';
						$rest .= '</div>';
						?>
						<div class="psec-row psec-row--block">
							<div class="psec-row__text">
								<span class="psec-row__title">API REST (wp-json)</span>
								<p class="psec-row__desc">A API REST é usada pelo editor, pelo Elementor e por alguns plugins. Quem tem sessão iniciada nunca é afetado.</p>
								<?php echo $rest; // phpcs:ignore ?>
							</div>
						</div>
						<?php
						self::toggle( 'security_headers', 'Cabeçalhos de segurança', 'Instrui os browsers a não deixar o site ser aberto dentro de outros sites (clickjacking) e a não adivinhar tipos de ficheiro.' );
						self::toggle( 'disable_file_edit', 'Desligar o editor de ficheiros', 'Remove o editor de temas e plugins do painel. Se alguém roubar uma sessão, não consegue meter código no site por aí.' );
						self::toggle( 'block_uploads_php', 'Bloquear PHP na pasta de uploads', 'A pasta de imagens nunca deve executar código. Se um atacante conseguir lá pôr um ficheiro .php, este não corre.' );
						self::toggle( 'protect_sensitive', 'Proteger ficheiros sensíveis', 'Bloqueia o acesso pela web ao <code>wp-config.php</code>, <code>.htaccess</code>, <code>debug.log</code>, <code>.env</code>, <code>.git</code> e a cópias de segurança esquecidas na raiz (<code>.sql</code>, <code>.zip</code>, <code>.bak</code>). Os ficheiros em uploads continuam a funcionar.' );
						self::toggle( 'disable_indexes', 'Desligar a listagem de pastas', 'Se uma pasta não tiver página inicial, o servidor deixa de mostrar a lista dos ficheiros que lá estão.' );
						?>
						<p class="psec-help">🛟 Ao guardar, o plugin testa o site. Se o servidor não aceitar alguma regra, repõe automaticamente o .htaccess anterior.</p>
					</div>
				</section>

				<section class="psec-panel" data-panel="appearance">
					<?php self::render_appearance(); ?>
				</section>

				<section class="psec-panel" data-panel="updates">
					<?php self::render_updates(); ?>
				</section>

				<section class="psec-panel" data-panel="integrity">
					<?php self::render_integrity(); ?>
				</section>

				<div class="psec-actions" hidden>
					<button type="submit" class="button button-primary button-hero">Guardar alterações</button>
					<button type="button" class="button button-hero psec-recommended">Aplicar recomendado</button>
					<span class="psec-muted">A cache do LiteSpeed é limpa automaticamente ao guardar.</span>
				</div>
			</form>
		</div>
		<?php
	}
}
