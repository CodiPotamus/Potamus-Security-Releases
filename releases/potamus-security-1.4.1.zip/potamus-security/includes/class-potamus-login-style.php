<?php
/**
 * Aparência da página de login: logótipo, fundo, cantos arredondados e cores.
 * Só corre na página de login, e só acrescenta um pequeno bloco de CSS.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Potamus_Login_Style {

	/** Valores por defeito: iguais ao aspeto normal do WordPress. */
	public static function defaults() {
		return array(
			'ls_enabled'       => 0,
			'ls_logo_id'       => 0,
			'ls_logo_width'    => 84,
			'ls_logo_link'     => '',
			'ls_bg_type'       => 'color',
			'ls_bg_color'      => '#f0f0f1',
			'ls_bg_color2'     => '#c3c4c7',
			'ls_bg_image_id'   => 0,
			'ls_bg_overlay'    => 30,
			'ls_radius_box'    => 0,
			'ls_radius_fields' => 4,
			'ls_form_bg'       => '#ffffff',
			'ls_text'          => '#3c434a',
			'ls_input_bg'      => '#ffffff',
			'ls_input_border'  => '#8c8f94',
			'ls_button_bg'     => '#2271b1',
			'ls_button_text'   => '#ffffff',
			'ls_link'          => '#50575e',
			'ls_accent'        => '#72aee6',
		);
	}

	public static function color_keys() {
		return array( 'ls_bg_color', 'ls_bg_color2', 'ls_form_bg', 'ls_text', 'ls_input_bg', 'ls_input_border', 'ls_button_bg', 'ls_button_text', 'ls_link', 'ls_accent' );
	}

	/** Validação dos campos de aparência (chamada a partir de Potamus_Settings::sanitize). */
	public static function sanitize( $input, $clean ) {
		$d = self::defaults();

		$clean['ls_enabled']       = empty( $input['ls_enabled'] ) ? 0 : 1;
		$clean['ls_logo_id']       = isset( $input['ls_logo_id'] ) ? absint( $input['ls_logo_id'] ) : 0;
		$clean['ls_bg_image_id']   = isset( $input['ls_bg_image_id'] ) ? absint( $input['ls_bg_image_id'] ) : 0;
		$clean['ls_logo_width']    = isset( $input['ls_logo_width'] ) ? max( 40, min( 320, absint( $input['ls_logo_width'] ) ) ) : $d['ls_logo_width'];
		$clean['ls_bg_overlay']    = isset( $input['ls_bg_overlay'] ) ? max( 0, min( 80, absint( $input['ls_bg_overlay'] ) ) ) : $d['ls_bg_overlay'];
		$clean['ls_radius_box']    = isset( $input['ls_radius_box'] ) ? max( 0, min( 40, absint( $input['ls_radius_box'] ) ) ) : $d['ls_radius_box'];
		$clean['ls_radius_fields'] = isset( $input['ls_radius_fields'] ) ? max( 0, min( 30, absint( $input['ls_radius_fields'] ) ) ) : $d['ls_radius_fields'];
		$clean['ls_bg_type']       = ( isset( $input['ls_bg_type'] ) && in_array( $input['ls_bg_type'], array( 'color', 'gradient', 'image' ), true ) ) ? $input['ls_bg_type'] : 'color';
		$clean['ls_logo_link']     = isset( $input['ls_logo_link'] ) ? esc_url_raw( trim( (string) $input['ls_logo_link'] ) ) : '';

		foreach ( self::color_keys() as $key ) {
			$color         = isset( $input[ $key ] ) ? sanitize_hex_color( $input[ $key ] ) : '';
			$clean[ $key ] = $color ? $color : $d[ $key ];
		}
		return $clean;
	}

	public static function init() {
		if ( ! Potamus_Settings::get( 'ls_enabled' ) ) {
			return;
		}
		// No login_head, depois das folhas de estilo do WordPress, para as substituir.
		add_action( 'login_head', array( __CLASS__, 'print_css' ), 99 );
		add_filter( 'login_headerurl', array( __CLASS__, 'logo_url' ) );
		add_filter( 'login_headertext', array( __CLASS__, 'logo_text' ) );
	}

	public static function logo_url() {
		$link = Potamus_Settings::get( 'ls_logo_link' );
		return $link ? $link : home_url( '/' );
	}

	public static function logo_text() {
		return get_bloginfo( 'name' );
	}

	/** Endereço e altura do logótipo, mantendo as proporções da imagem. */
	public static function logo( $s ) {
		if ( empty( $s['ls_logo_id'] ) ) {
			return null;
		}
		$src = wp_get_attachment_image_src( (int) $s['ls_logo_id'], 'full' );
		if ( ! $src ) {
			return null;
		}
		$width  = (int) $s['ls_logo_width'];
		$height = ( ! empty( $src[1] ) && ! empty( $src[2] ) ) ? (int) round( $width * $src[2] / $src[1] ) : $width;
		return array(
			'url'    => $src[0],
			'width'  => $width,
			'height' => max( 20, min( 400, $height ) ),
		);
	}

	public static function bg_image( $s ) {
		if ( empty( $s['ls_bg_image_id'] ) ) {
			return '';
		}
		$src = wp_get_attachment_image_src( (int) $s['ls_bg_image_id'], 'full' );
		return $src ? $src[0] : '';
	}

	public static function css( $s ) {
		$c = array();
		foreach ( self::color_keys() as $key ) {
			$c[ $key ] = sanitize_hex_color( $s[ $key ] );
		}
		$rb = (int) $s['ls_radius_box'];
		$rf = (int) $s['ls_radius_fields'];

		// Fundo.
		$bg = 'background:' . $c['ls_bg_color'] . ';';
		if ( 'gradient' === $s['ls_bg_type'] ) {
			$bg = 'background:' . $c['ls_bg_color'] . ' linear-gradient(135deg,' . $c['ls_bg_color'] . ' 0%,' . $c['ls_bg_color2'] . ' 100%) fixed;';
		}
		$overlay = '';
		$image   = 'image' === $s['ls_bg_type'] ? self::bg_image( $s ) : '';
		if ( $image ) {
			$bg      = 'background:' . $c['ls_bg_color'] . ' url("' . esc_url( $image ) . '") center/cover no-repeat fixed;';
			$opacity = round( (int) $s['ls_bg_overlay'] / 100, 2 );
			if ( $opacity > 0 ) {
				$overlay = 'body.login::before{content:"";position:fixed;inset:0;background:rgba(0,0,0,' . $opacity . ');z-index:0;pointer-events:none}'
					. '#login,.language-switcher{position:relative;z-index:1}';
			}
		}

		$css  = 'body.login{' . $bg . 'color:' . $c['ls_text'] . '}';
		$css .= $overlay;

		// Logótipo.
		$logo = self::logo( $s );
		if ( $logo ) {
			$css .= '.login h1 a{background-image:url("' . esc_url( $logo['url'] ) . '");background-size:contain;background-position:center;width:' . $logo['width'] . 'px;height:' . $logo['height'] . 'px;max-width:100%}';
		}

		// Caixa do formulário.
		$css .= '.login form{background:' . $c['ls_form_bg'] . ';border:1px solid ' . $c['ls_input_border'] . '33;border-radius:' . $rb . 'px;box-shadow:0 1px 3px rgba(0,0,0,.04),0 8px 24px rgba(0,0,0,.06)}';
		$css .= '.login label,.login form .forgetmenot label,.login form p{color:' . $c['ls_text'] . '}';

		// Campos.
		$css .= '.login form .input,.login input[type=text],.login input[type=password],.login input[type=email],.login form input[type=checkbox]{background:' . $c['ls_input_bg'] . ';border-color:' . $c['ls_input_border'] . ';color:' . $c['ls_text'] . '}';
		$css .= '.login form .input,.login input[type=text],.login input[type=password],.login input[type=email]{border-radius:' . $rf . 'px}';
		$css .= '.login form .input:focus,.login input[type=text]:focus,.login input[type=password]:focus,.login input[type=email]:focus,.login form input[type=checkbox]:focus{border-color:' . $c['ls_button_bg'] . ';box-shadow:0 0 0 1px ' . $c['ls_button_bg'] . '}';
		$css .= '.login form input[type=checkbox]:checked::before{filter:none}';
		$css .= '.login .button.wp-hide-pw .dashicons{color:' . $c['ls_button_bg'] . '}';

		// Botão.
		$css .= '.wp-core-ui.login .button-primary,.login .button-primary{background:' . $c['ls_button_bg'] . ';border-color:' . $c['ls_button_bg'] . ';color:' . $c['ls_button_text'] . ';border-radius:' . $rf . 'px;text-shadow:none;box-shadow:none}';
		$css .= '.wp-core-ui.login .button-primary:hover,.wp-core-ui.login .button-primary:focus,.login .button-primary:hover,.login .button-primary:focus{background:' . $c['ls_button_bg'] . ';border-color:' . $c['ls_button_bg'] . ';color:' . $c['ls_button_text'] . ';filter:brightness(.9)}';
		$css .= '.wp-core-ui.login .button-primary:focus{box-shadow:0 0 0 1px #fff,0 0 0 3px ' . $c['ls_button_bg'] . '}';

		// Links.
		$css .= '.login #nav a,.login #backtoblog a,.login .privacy-policy-page-link a,.login .language-switcher label{color:' . $c['ls_link'] . '}';
		$css .= '.login #nav a:hover,.login #backtoblog a:hover,.login .privacy-policy-page-link a:hover{color:' . $c['ls_button_bg'] . '}';

		// Mensagens e avisos.
		$css .= '.login .message,.login .notice,.login .success,.login #login_error{background:' . $c['ls_form_bg'] . ';color:' . $c['ls_text'] . ';border-left-color:' . $c['ls_accent'] . ';border-radius:' . min( $rb, 12 ) . 'px}';
		$css .= '.login #login_error,.login .notice-error{border-left-color:#d63638}';

		return $css;
	}

	public static function print_css() {
		echo '<style id="potamus-login-style">' . self::css( Potamus_Settings::all() ) . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- valores validados (cores hex, inteiros, URLs escapados).
	}
}
