<?php
/**
 * Regras no .htaccess (Apache / LiteSpeed). São aplicadas pelo servidor antes de o
 * WordPress arrancar, por isso não gastam PHP nem base de dados.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Potamus_Htaccess {

	const MARKER = 'Potamus Security';
	const STATUS = 'potamus_security_htaccess';

	private static function path() {
		if ( ! function_exists( 'get_home_path' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		return get_home_path() . '.htaccess';
	}

	public static function server_supports() {
		global $is_apache;
		$software = isset( $_SERVER['SERVER_SOFTWARE'] ) ? strtolower( (string) $_SERVER['SERVER_SOFTWARE'] ) : '';
		return $is_apache || false !== strpos( $software, 'litespeed' );
	}

	public static function rules() {
		$s     = Potamus_Settings::all();
		$lines = array();

		if ( $s['disable_indexes'] ) {
			$lines[] = 'Options -Indexes';
		}

		$rewrite = array();
		if ( $s['protect_sensitive'] ) {
			// Ficheiros escondidos (.env, .git, .htaccess...), exceto .well-known, usado na renovação do SSL.
			$rewrite[] = 'RewriteRule (^|/)\.(?!well-known(/|$)) - [R=404,L]';
			$rewrite[] = 'RewriteRule (^|/)wp-config\.php$ - [R=404,L,NC]';
			$rewrite[] = 'RewriteRule (^|/)(debug\.log|error_log|php_errorlog)$ - [R=404,L,NC]';
			$rewrite[] = 'RewriteRule \.(log|sql|bak|old|orig|swp|save|dist)$ - [R=404,L,NC]';
			// Cópias de segurança deixadas na raiz do site (os .zip dentro de uploads continuam acessíveis).
			$rewrite[] = 'RewriteRule ^[^/]+\.(zip|tar|gz|tgz|rar|7z|sql\.gz)$ - [R=404,L,NC]';
			$rewrite[] = 'RewriteRule ^(composer\.(json|lock)|package(-lock)?\.json|wp-cli\.ya?ml|phpunit\.xml(\.dist)?)$ - [R=404,L,NC]';
		}
		if ( $s['block_files'] ) {
			$rewrite[] = 'RewriteRule ^(readme\.html|license\.txt|wp-config-sample\.php|wp-admin/install\.php)$ - [R=404,L,NC]';
		}
		if ( $s['disable_xmlrpc'] ) {
			$rewrite[] = 'RewriteRule ^xmlrpc\.php$ - [R=404,L,NC]';
		}
		if ( $s['block_uploads_php'] ) {
			$rewrite[] = 'RewriteRule ^wp-content/uploads/.*\.(php[0-9]?|phtml|phar|pht)$ - [R=404,L,NC]';
		}
		if ( $rewrite ) {
			$lines[] = '<IfModule mod_rewrite.c>';
			$lines[] = 'RewriteEngine On';
			$lines   = array_merge( $lines, $rewrite );
			$lines[] = '</IfModule>';
		}

		$headers = array();
		if ( $s['clean_head'] ) {
			$headers[] = 'Header always unset X-Powered-By';
			$headers[] = 'Header unset X-Powered-By';
		}
		if ( $s['security_headers'] ) {
			$headers[] = 'Header always set X-Content-Type-Options "nosniff"';
			$headers[] = 'Header always set X-Frame-Options "SAMEORIGIN"';
			$headers[] = 'Header always set Referrer-Policy "strict-origin-when-cross-origin"';
			$headers[] = 'Header always set Permissions-Policy "camera=(), microphone=(), geolocation=(), interest-cohort=()"';
		}
		if ( $headers ) {
			$lines[] = '<IfModule mod_headers.c>';
			$lines   = array_merge( $lines, $headers );
			$lines[] = '</IfModule>';
		}

		return $lines;
	}

	/** Escreve as regras. Devolve true se ficaram aplicadas. */
	public static function write() {
		if ( ! self::server_supports() ) {
			update_option( self::STATUS, 'unsupported', false );
			return false;
		}
		if ( ! function_exists( 'insert_with_markers' ) ) {
			require_once ABSPATH . 'wp-admin/includes/misc.php';
		}
		$file = self::path();
		if ( ( file_exists( $file ) && ! wp_is_writable( $file ) ) || ( ! file_exists( $file ) && ! wp_is_writable( dirname( $file ) ) ) ) {
			update_option( self::STATUS, 'not_writable', false );
			return false;
		}
		$before = file_exists( $file ) ? (string) file_get_contents( $file ) : null; // phpcs:ignore
		$ok     = insert_with_markers( $file, self::MARKER, self::rules() );
		if ( ! $ok ) {
			update_option( self::STATUS, 'not_writable', false );
			return false;
		}

		// Autoteste: se o servidor não aceitar alguma regra e o site der erro, repõe o .htaccess anterior.
		if ( self::site_broken() ) {
			if ( null === $before ) {
				wp_delete_file( $file );
			} else {
				file_put_contents( $file, $before ); // phpcs:ignore
			}
			update_option( self::STATUS, 'reverted', false );
			return false;
		}

		update_option( self::STATUS, 'ok', false );
		return true;
	}

	/** Pede a página inicial ao próprio site. Só um erro 5xx conta como avaria; falhas de ligação são ignoradas. */
	private static function site_broken() {
		$response = wp_remote_get(
			add_query_arg( 'psec-check', wp_rand(), home_url( '/' ) ),
			array(
				'timeout'     => 10,
				'redirection' => 0,
				'sslverify'   => false,
				'headers'     => array( 'Cache-Control' => 'no-cache' ),
			)
		);
		if ( is_wp_error( $response ) ) {
			return false;
		}
		return (int) wp_remote_retrieve_response_code( $response ) >= 500;
	}

	public static function remove() {
		if ( ! function_exists( 'insert_with_markers' ) ) {
			require_once ABSPATH . 'wp-admin/includes/misc.php';
		}
		$file = self::path();
		if ( file_exists( $file ) && wp_is_writable( $file ) ) {
			insert_with_markers( $file, self::MARKER, array() );
		}
		delete_option( self::STATUS );
	}

	public static function status() {
		return get_option( self::STATUS, 'unknown' );
	}

	/** Quando o .htaccess está a funcionar, o PHP não precisa de repetir os cabeçalhos. */
	public static function active() {
		return 'ok' === self::status();
	}
}
