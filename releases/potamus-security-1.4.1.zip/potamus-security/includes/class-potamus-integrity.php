<?php
/**
 * Verificação de integridade: compara os ficheiros do núcleo do WordPress com as
 * impressões digitais oficiais do WordPress.org. Corre só a pedido ou uma vez por semana.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Potamus_Integrity {

	const OPTION = 'potamus_security_integrity';
	const HOOK   = 'potamus_security_integrity_cron';
	const LIMIT  = 100;

	public static function init() {
		add_action( self::HOOK, array( __CLASS__, 'run' ) );
		if ( is_admin() ) {
			add_action( 'admin_post_potamus_integrity', array( __CLASS__, 'run_manual' ) );
			add_action( 'admin_init', array( __CLASS__, 'sync_schedule' ) );
		}
	}

	public static function sync_schedule() {
		$want = (bool) Potamus_Settings::get( 'integrity_weekly' );
		$next = wp_next_scheduled( self::HOOK );
		if ( $want && ! $next ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'weekly', self::HOOK );
		} elseif ( ! $want && $next ) {
			wp_clear_scheduled_hook( self::HOOK );
		}
	}

	public static function unschedule() {
		wp_clear_scheduled_hook( self::HOOK );
	}

	public static function last() {
		$r = get_option( self::OPTION );
		return is_array( $r ) ? $r : null;
	}

	private static function fetch_checksums( $version, $locale ) {
		// Usa a mesma função que o WordPress usa nas atualizações (com tentativa por http se o https falhar).
		if ( ! function_exists( 'get_core_checksums' ) ) {
			require_once ABSPATH . 'wp-admin/includes/update.php';
		}
		$sums = get_core_checksums( $version, $locale );
		return ( is_array( $sums ) && $sums ) ? $sums : null;
	}

	public static function run() {
		// Lê a versão sem executar o ficheiro (se tiver sido adulterado, não queremos correr o seu código).
		$wp_version = isset( $GLOBALS['wp_version'] ) ? (string) $GLOBALS['wp_version'] : '';
		$raw        = (string) file_get_contents( ABSPATH . WPINC . '/version.php' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( preg_match( '/\$wp_version\s*=\s*[\'"]([^\'"]+)[\'"]/', $raw, $m ) ) {
			$wp_version = $m[1];
		}

		// Pacotes traduzidos identificam-se no version.php ($wp_local_package); senão usa o idioma do site.
		$locale = get_locale();
		if ( preg_match( '/\$wp_local_package\s*=\s*[\'"]([A-Za-z_]+)[\'"]/', $raw, $m ) ) {
			$locale = $m[1];
		}
		$sums_locale = $locale;
		$sums        = self::fetch_checksums( $wp_version, $locale );
		if ( null === $sums && 'en_US' !== $locale ) {
			$sums        = self::fetch_checksums( $wp_version, 'en_US' );
			$sums_locale = 'en_US';
		}
		// Num site noutra língua, os ficheiros podem ser os ingleses (WordPress instalado em inglês e
		// traduzido depois) ou os do pacote traduzido. Aceita-se qualquer uma das duas listas oficiais.
		$alt = null;
		if ( null !== $sums && 'en_US' !== $locale && 'en_US' !== $sums_locale ) {
			$alt = self::fetch_checksums( $wp_version, 'en_US' );
		}
		// Se nenhuma lista bater certo, estes ficheiros que as traduções mudam são analisados ao conteúdo.
		$translated = 'en_US' !== $locale ? self::translated_files() : array();

		$result = array(
			'time'     => time(),
			'version'  => $wp_version,
			'status'   => 'ok',
			'message'  => '',
			'modified' => array(),
			'missing'  => array(),
			'extra'    => array(),
			'localized' => array(),
			'locale'    => $locale,
			'checked'  => 0,
		);

		if ( null === $sums ) {
			$result['status']  = 'error';
			$result['message'] = sprintf( 'Não foi possível obter as impressões digitais oficiais do WordPress %s. Pode ser uma versão de desenvolvimento ou uma falha temporária de ligação.', $wp_version );
			update_option( self::OPTION, $result, false );
			return $result;
		}

		$root = trailingslashit( ABSPATH );
		foreach ( $sums as $file => $md5 ) {
			// Temas e plugins incluídos no WordPress podem ser apagados ou atualizados à parte.
			if ( 0 === strpos( $file, 'wp-content/' ) ) {
				continue;
			}
			$path = $root . $file;
			if ( ! file_exists( $path ) ) {
				// Na raiz é normal apagar o readme.html, license.txt, etc.
				if ( 0 === strpos( $file, 'wp-admin/' ) || 0 === strpos( $file, WPINC . '/' ) ) {
					$result['missing'][] = $file;
				}
				continue;
			}
			$result['checked']++;
			$hash = md5_file( $path );
			if ( $hash !== $md5 && ! ( $alt && isset( $alt[ $file ] ) && $hash === $alt[ $file ] ) ) {
				// Ficheiro traduzido: em vez de o comparar com o inglês, confirma que não contém código perigoso.
				if ( isset( $translated[ $file ] ) && self::looks_clean( $path, $translated[ $file ] ) ) {
					$result['localized'][] = $file;
				} else {
					$result['modified'][] = $file;
				}
			}
		}

		// Ficheiros a mais dentro das pastas do núcleo: é onde costumam esconder-se backdoors.
		foreach ( array( 'wp-admin', WPINC ) as $dir ) {
			$base = $root . $dir;
			if ( ! is_dir( $base ) ) {
				continue;
			}
			$iterator = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $base, FilesystemIterator::SKIP_DOTS ) );
			foreach ( $iterator as $file ) {
				if ( ! $file->isFile() ) {
					continue;
				}
				$rel = ltrim( str_replace( '\\', '/', substr( $file->getPathname(), strlen( $root ) ) ), '/' );
				if ( ! isset( $sums[ $rel ] ) && ! isset( $alt[ $rel ] ) && preg_match( '/\.(php|phtml|phar|js|ico|html?)$/i', $rel ) ) {
					$result['extra'][] = $rel;
				}
				if ( count( $result['extra'] ) >= self::LIMIT ) {
					break 2;
				}
			}
		}

		// Ficheiros PHP desconhecidos na raiz do site (o wp-config.php é esperado).
		foreach ( (array) glob( $root . '*.php' ) as $path ) {
			$rel = basename( $path );
			if ( 'wp-config.php' !== $rel && ! isset( $sums[ $rel ] ) && ! isset( $alt[ $rel ] ) ) {
				$result['extra'][] = $rel;
			}
		}

		foreach ( array( 'modified', 'missing', 'extra' ) as $key ) {
			$result[ $key ] = array_slice( array_values( array_unique( $result[ $key ] ) ), 0, self::LIMIT );
		}
		if ( $result['modified'] || $result['missing'] || $result['extra'] ) {
			$result['status'] = 'issues';
		}

		update_option( self::OPTION, $result, false );
		return $result;
	}

	/** Ficheiros que as versões traduzidas do WordPress alteram, e o tipo de verificação a aplicar. */
	private static function translated_files() {
		return array(
			WPINC . '/version.php'  => 'version',
			'wp-config-sample.php' => 'sample',
			'readme.html'          => 'html',
		);
	}

	/**
	 * Verificação de conteúdo para ficheiros traduzidos:
	 *  - version.php só pode ter atribuições de variáveis (sem chamadas a funções);
	 *  - wp-config-sample.php só pode usar as funções que o original usa;
	 *  - readme.html não pode ter scripts, iframes nem PHP.
	 */
	private static function looks_clean( $path, $type ) {
		$content = (string) file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( '' === $content ) {
			return false;
		}
		if ( 'html' === $type ) {
			return ! preg_match( '#<\s*(script|iframe|object|embed)\b|<\?php|javascript:#i', $content );
		}
		if ( ! function_exists( 'token_get_all' ) ) {
			return false;
		}
		$allowed_calls = 'sample' === $type ? array( 'define', 'defined', 'dirname', 'require_once' ) : array();
		$forbidden     = array( T_EVAL, T_INCLUDE, T_INCLUDE_ONCE, T_REQUIRE, T_INLINE_HTML );
		$name_tokens   = array( T_STRING, T_VARIABLE );
		foreach ( array( 'T_NAME_QUALIFIED', 'T_NAME_FULLY_QUALIFIED', 'T_NAME_RELATIVE' ) as $const ) {
			if ( defined( $const ) ) {
				$name_tokens[] = constant( $const );
			}
		}
		$tokens        = token_get_all( $content );
		$count         = count( $tokens );
		for ( $i = 0; $i < $count; $i++ ) {
			$t = $tokens[ $i ];
			if ( ! is_array( $t ) ) {
				if ( '`' === $t ) {
					return false;
				}
				continue;
			}
			if ( in_array( $t[0], $forbidden, true ) ) {
				return false;
			}
			if ( T_REQUIRE_ONCE === $t[0] && ! in_array( 'require_once', $allowed_calls, true ) ) {
				return false;
			}
			// Nome seguido de "(" é uma chamada de função.
			if ( in_array( $t[0], $name_tokens, true ) ) {
				for ( $j = $i + 1; $j < $count && is_array( $tokens[ $j ] ) && in_array( $tokens[ $j ][0], array( T_WHITESPACE, T_COMMENT ), true ); $j++ );
				if ( $j < $count && '(' === $tokens[ $j ] ) {
					if ( T_VARIABLE === $t[0] || ! in_array( strtolower( ltrim( $t[1], '\\' ) ), $allowed_calls, true ) ) {
						return false;
					}
				}
			}
		}
		return true;
	}

	/** Nome legível da língua (ex.: "espanhol (Espanha)"), com o código entre parênteses. */
	public static function language_label( $locale ) {
		$locale = (string) $locale;
		if ( '' === $locale ) {
			return '';
		}
		if ( class_exists( 'Locale' ) ) {
			$name = Locale::getDisplayName( $locale, 'pt_PT' );
			if ( $name && strtolower( $name ) !== strtolower( $locale ) ) {
				return $name . ' (' . $locale . ')';
			}
		}
		return $locale;
	}

	/**
	 * Inspeciona um ficheiro da última verificação: lê-o como texto (nunca o executa)
	 * e procura padrões típicos de código malicioso. Só aceita ficheiros que constem do resultado.
	 */
	public static function inspect( $rel ) {
		$r = self::last();
		$rel = ltrim( str_replace( '\\', '/', (string) $rel ), '/' );
		$allowed = $r ? array_merge( (array) $r['modified'], (array) $r['extra'], isset( $r['localized'] ) ? (array) $r['localized'] : array() ) : array();
		if ( '' === $rel || ! in_array( $rel, $allowed, true ) ) {
			return new WP_Error( 'psec_not_listed', 'Este ficheiro não está na lista da última verificação.' );
		}
		$root = realpath( ABSPATH );
		$path = realpath( ABSPATH . $rel );
		if ( ! $root || ! $path || 0 !== strpos( $path, $root ) || ! is_file( $path ) ) {
			return new WP_Error( 'psec_missing', 'O ficheiro já não existe ou não pode ser lido.' );
		}

		$size    = (int) filesize( $path );
		$content = (string) file_get_contents( $path, false, null, 0, 512 * 1024 ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		$patterns = array(
			array( 'high', 'Executa código a partir de texto (eval)', '/\beval\s*\(/i' ),
			array( 'high', 'Executa código através de assert()', '/\bassert\s*\(\s*\$/i' ),
			array( 'high', 'Descomprime ou baralha texto escondido (gzinflate, str_rot13…)', '/\b(gzinflate|gzuncompress|gzdecode|str_rot13|convert_uudecode)\s*\(/i' ),
			array( 'high', 'Executa comandos no servidor (system, exec, shell_exec…)', '/\b(system|shell_exec|passthru|exec|popen|proc_open|pcntl_exec)\s*\(/i' ),
			array( 'high', 'Cria funções a partir de texto (create_function)', '/\bcreate_function\s*\(/i' ),
			array( 'high', 'preg_replace com o modificador /e (executa código)', '/preg_replace\s*\(\s*[\'"](.).*\1[a-z]*e[a-z]*[\'"]/i' ),
			array( 'high', 'Bloco longo de texto codificado (típico de código escondido)', '/[A-Za-z0-9+\/=]{400,}/' ),
			array( 'medium', 'Descodifica texto em base64', '/\bbase64_decode\s*\(/i' ),
			array( 'medium', 'Chama funções através de variáveis', '/\$[A-Za-z_][A-Za-z0-9_]*\s*\(/' ),
			array( 'medium', 'Texto escondido com códigos hexadecimais', '/(\\\\x[0-9a-f]{2}){8,}/i' ),
			array( 'medium', 'Escreve ou move ficheiros no servidor', '/\b(file_put_contents|fwrite|move_uploaded_file)\s*\(/i' ),
			array( 'medium', 'Usa dados enviados pelo visitante ($_GET, $_POST, $_COOKIE…)', '/\$_(GET|POST|REQUEST|COOKIE|FILES)\b/' ),
			array( 'low', 'Liga-se a outros endereços na internet', '/\b(curl_exec|fsockopen)\s*\(|file_get_contents\s*\(\s*[\'"]https?:/i' ),
			array( 'low', 'Inclui outros ficheiros', '/\b(include|require)(_once)?\b/i' ),
		);
		// Padrões novos recebidos nas definições de ameaças assinadas.
		if ( class_exists( 'Potamus_Updates' ) ) {
			$known = wp_list_pluck( $patterns, 2 );
			foreach ( Potamus_Updates::extra_patterns() as $extra ) {
				if ( ! in_array( $extra[2], $known, true ) ) {
					$patterns[] = $extra;
				}
			}
		}
		$findings = array();
		foreach ( $patterns as $pat ) {
			if ( preg_match_all( $pat[2], $content, $m, PREG_OFFSET_CAPTURE ) ) {
				$lines = array();
				foreach ( array_slice( $m[0], 0, 5 ) as $hit ) {
					$lines[] = substr_count( substr( $content, 0, $hit[1] ), "\n" ) + 1;
				}
				$findings[] = array(
					'level' => $pat[0],
					'label' => $pat[1],
					'count' => count( $m[0] ),
					'lines' => array_values( array_unique( $lines ) ),
				);
			}
		}

		$levels  = wp_list_pluck( $findings, 'level' );
		$verdict = in_array( 'high', $levels, true ) ? 'high' : ( in_array( 'medium', $levels, true ) ? 'medium' : 'clean' );

		$preview = explode( "\n", $content );
		return array(
			'file'      => $rel,
			'size'      => $size,
			'modified'  => (int) filemtime( $path ),
			'perms'     => substr( sprintf( '%o', fileperms( $path ) ), -3 ),
			'lines'     => count( $preview ),
			'is_php'    => (bool) preg_match( '/<\?(php|=)?/i', $content ),
			'findings'  => $findings,
			'verdict'   => $verdict,
			'preview'   => implode( "\n", array_slice( $preview, 0, 200 ) ),
			'truncated' => count( $preview ) > 200 || $size > 512 * 1024,
		);
	}

	public static function run_manual() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Sem permissão.' );
		}
		check_admin_referer( 'potamus_integrity' );
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 120 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
		self::run();
		wp_safe_redirect( admin_url( 'admin.php?page=potamus-security&psec_tab=integrity' ) );
		exit;
	}
}
