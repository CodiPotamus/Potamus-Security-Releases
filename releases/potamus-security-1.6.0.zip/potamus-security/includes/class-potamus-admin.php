<?php
/**
 * Página de definições. Só é carregada na administração, e os estilos/scripts
 * só entram na página do próprio plugin.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Potamus_Admin {

	const SLUG = 'potamus-security';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'wp_ajax_potamus_inspect', array( __CLASS__, 'ajax_inspect' ) );
		add_action( 'update_option_' . Potamus_Settings::OPTION, array( __CLASS__, 'after_save' ), 10, 0 );
		add_action( 'add_option_' . Potamus_Settings::OPTION, array( __CLASS__, 'after_save' ), 10, 0 );
		add_filter( 'plugin_action_links_' . plugin_basename( POTAMUS_SECURITY_FILE ), array( __CLASS__, 'action_links' ) );
	}

	public static function icon_svg( $color = 'black' ) {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="' . $color . '" fill-rule="evenodd" d="M4.2 2.4a1.4 1.4 0 1 1 0 2.8 1.4 1.4 0 0 1 0-2.8zm11.6 0a1.4 1.4 0 1 1 0 2.8 1.4 1.4 0 0 1 0-2.8zM10 3.5c3.3 0 5.5 2 5.5 4.6 0 .6-.1 1.1-.3 1.6 1.3.7 2.3 2 2.3 3.6 0 2.6-3.4 4.7-7.5 4.7s-7.5-2.1-7.5-4.7c0-1.6 1-2.9 2.3-3.6-.2-.5-.3-1-.3-1.6C4.5 5.5 6.7 3.5 10 3.5zM7.6 12.2a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm4.8 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2zM7.8 7a.8.8 0 1 0 0 1.6.8.8 0 0 0 0-1.6zm4.4 0a.8.8 0 1 0 0 1.6.8.8 0 0 0 0-1.6z"/></svg>';
	}

	public static function menu() {
		add_menu_page(
			'Potamus Security',
			'Potamus Security',
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render' ),
			'data:image/svg+xml;base64,' . base64_encode( self::icon_svg() ),
			81
		);
	}

	public static function register() {
		register_setting(
			'potamus_security_group',
			Potamus_Settings::OPTION,
			array( 'sanitize_callback' => array( 'Potamus_Settings', 'sanitize' ) )
		);
	}

	public static function after_save() {
		Potamus_Settings::flush_cache();
		Potamus_Htaccess::write();
		Potamus_Integrity::sync_schedule();
		if ( Potamus_Definitions::configured() ) {
			Potamus_Definitions::sync_schedule();
		}
		// Limpa a cache do LiteSpeed Cache (e de outros plugins compatíveis) para as mudanças aparecerem já.
		do_action( 'litespeed_purge_all' );
		if ( function_exists( 'wp_cache_flush' ) ) {
			wp_cache_flush();
		}
	}

	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ) . '">' . esc_html__( 'Settings', 'potamus-security' ) . '</a>' );
		return $links;
	}

	public static function assets( $hook ) {
		if ( 'toplevel_page_' . self::SLUG !== $hook ) {
			return;
		}
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_media();
		wp_enqueue_style( 'potamus-admin', POTAMUS_SECURITY_URL . 'assets/admin.css', array( 'wp-color-picker' ), POTAMUS_SECURITY_VERSION );
		wp_enqueue_script( 'potamus-login-style', POTAMUS_SECURITY_URL . 'assets/login-style.js', array( 'jquery', 'wp-color-picker' ), POTAMUS_SECURITY_VERSION, true );
		wp_localize_script(
			'potamus-login-style',
			'PotamusLS',
			array(
				'defaults' => Potamus_Login_Style::defaults(),
				'i18n'     => array(
					'wpLogo'     => __( 'WordPress logo', 'potamus-security' ),
					'noImage'    => __( 'No image', 'potamus-security' ),
					'chooseLogo' => __( 'Choose logo', 'potamus-security' ),
					'chooseBg'   => __( 'Choose background image', 'potamus-security' ),
					'useImage'   => __( 'Use this image', 'potamus-security' ),
					'resetDone'  => __( 'Restored — remember to save', 'potamus-security' ),
				),
			)
		);
		wp_enqueue_script( 'potamus-admin', POTAMUS_SECURITY_URL . 'assets/admin.js', array(), POTAMUS_SECURITY_VERSION, true );
		wp_localize_script( 'potamus-admin', 'PotamusDefaults', Potamus_Settings::defaults() );
		wp_localize_script(
			'potamus-admin',
			'PotamusInspect',
			array(
				'url'   => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'psec_inspect' ),
			)
		);
		wp_localize_script(
			'potamus-admin',
			'PotamusI18n',
			array(
				'applied'     => __( 'Applied — remember to save', 'potamus-security' ),
				/* translators: %s: new login address. */
				'loginAlert'  => __( "After saving, you will only be able to log in through the new address:\n\n%s\n\nBookmark it.", 'potamus-security' ),
				'checking'    => __( 'Checking… (this may take a few seconds)', 'potamus-security' ),
				'reading'     => __( 'Reading the file…', 'potamus-security' ),
				'inspectFail' => __( 'Could not inspect the file.', 'potamus-security' ),
				'copied'      => __( 'Copied ✓', 'potamus-security' ),
			)
		);
	}

	/* ---------- Verificações do painel ---------- */

	public static function checks() {
		$s      = Potamus_Settings::all();
		$checks = array();

		$php                = PHP_VERSION;
		$checks['php']      = array(
			'ok'    => version_compare( $php, '8.3', '>=' ),
			'title' => sprintf( __( 'PHP version: %s', 'potamus-security' ), $php ),
			'tip'   => version_compare( $php, '8.3', '>=' ) ? __( 'Version with security support.', 'potamus-security' ) : __( 'Ask your host to switch to PHP 8.4 or 8.5.', 'potamus-security' ),
		);

		$checks['https'] = array(
			'ok'    => 0 === strpos( home_url(), 'https://' ),
			'title' => __( 'Secure connection (HTTPS)', 'potamus-security' ),
			'tip'   => 0 === strpos( home_url(), 'https://' ) ? __( 'The site uses HTTPS.', 'potamus-security' ) : __( 'Turn on SSL at your host and change the site address to https://.', 'potamus-security' ),
		);

		$core     = get_site_transient( 'update_core' );
		$core_old = false;
		if ( $core && ! empty( $core->updates ) ) {
			foreach ( $core->updates as $u ) {
				if ( isset( $u->response ) && 'upgrade' === $u->response ) {
					$core_old = true;
				}
			}
		}
		$checks['core'] = array(
			'ok'    => ! $core_old,
			'title' => __( 'WordPress up to date', 'potamus-security' ),
			'tip'   => $core_old ? __( 'A new version of WordPress is available. Update it in Dashboard → Updates.', 'potamus-security' ) : __( 'You are on the latest version.', 'potamus-security' ),
		);

		$plugins = get_site_transient( 'update_plugins' );
		$pending = ( $plugins && ! empty( $plugins->response ) ) ? count( $plugins->response ) : 0;
		$checks['plugins'] = array(
			'ok'    => 0 === $pending,
			'title' => __( 'Plugins up to date', 'potamus-security' ),
			'tip'   => $pending ? sprintf( __( '%d plugin(s) waiting to be updated.', 'potamus-security' ), $pending ) : __( 'No outdated plugins.', 'potamus-security' ),
		);

		$admin_user = username_exists( 'admin' );
		$checks['admin_user'] = array(
			'ok'    => ! $admin_user,
			'title' => __( 'No "admin" user', 'potamus-security' ),
			'tip'   => $admin_user ? __( 'It is the first name attackers try. Create another administrator and delete this one.', 'potamus-security' ) : __( 'Well done.', 'potamus-security' ),
		);

		$debug = defined( 'WP_DEBUG' ) && WP_DEBUG && ( ! defined( 'WP_DEBUG_DISPLAY' ) || WP_DEBUG_DISPLAY );
		$checks['debug'] = array(
			'ok'    => ! $debug,
			'title' => __( 'Errors hidden from visitors', 'potamus-security' ),
			'tip'   => $debug ? __( 'WP_DEBUG is showing errors on the site. Turn it off in wp-config.php.', 'potamus-security' ) : __( 'Errors are not shown publicly.', 'potamus-security' ),
		);

		$checks['login'] = array(
			'ok'    => (bool) $s['login_enabled'],
			'title' => __( 'Custom login address', 'potamus-security' ),
			'tip'   => $s['login_enabled'] ? __( 'wp-login.php is hidden.', 'potamus-security' ) : __( 'Turn it on in the Login tab.', 'potamus-security' ),
		);

		$checks['limit'] = array(
			'ok'    => (bool) $s['limit_login'],
			'title' => __( 'Login attempt limit', 'potamus-security' ),
			'tip'   => $s['limit_login'] ? sprintf( __( '%1$d attempts, then a %2$d-minute lockout.', 'potamus-security' ), $s['max_attempts'], $s['lockout_minutes'] ) : __( 'Turn it on in the Login tab.', 'potamus-security' ),
		);

		$hidden = $s['hide_versions'] && $s['clean_head'] && $s['strip_generators'];
		$checks['hide'] = array(
			'ok'    => $hidden,
			'title' => __( 'Versions and signatures hidden', 'potamus-security' ),
			'tip'   => $hidden ? __( 'The site\'s code does not reveal versions.', 'potamus-security' ) : __( 'Turn on the options in the Hide WordPress tab.', 'potamus-security' ),
		);

		$checks['xmlrpc'] = array(
			'ok'    => (bool) $s['disable_xmlrpc'],
			'title' => __( 'XML-RPC disabled', 'potamus-security' ),
			'tip'   => $s['disable_xmlrpc'] ? __( 'Old door closed.', 'potamus-security' ) : __( 'Turn it off unless you use Jetpack or the mobile app.', 'potamus-security' ),
		);

		$checks['file_edit'] = array(
			'ok'    => defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT,
			'title' => __( 'File editor turned off', 'potamus-security' ),
			'tip'   => __( 'Stops anyone with dashboard access from changing theme or plugin code.', 'potamus-security' ),
		);

		$status = Potamus_Htaccess::status();
		$labels = array(
			'ok'           => __( 'Rules applied on the server (.htaccess).', 'potamus-security' ),
			'not_writable' => __( 'Could not write to .htaccess. The protections run in PHP, slightly less efficiently.', 'potamus-security' ),
			'unsupported'  => __( 'The server does not use .htaccess (e.g. Nginx). The protections run in PHP.', 'potamus-security' ),
			'unknown'      => __( 'Save the settings to apply the rules.', 'potamus-security' ),
			'reverted'     => __( 'The server rejected a rule and the site returned an error, so the previous .htaccess was restored. The protections run in PHP.', 'potamus-security' ),
		);
		$checks['htaccess'] = array(
			'ok'    => 'ok' === $status,
			'title' => __( 'Server-level protection', 'potamus-security' ),
			'tip'   => isset( $labels[ $status ] ) ? $labels[ $status ] : $labels['unknown'],
		);

		// 2FA do utilizador atual.
		$me_2fa = Potamus_TwoFA::user_has( get_current_user_id() );
		$checks['twofa'] = array(
			'ok'    => $s['twofa_enabled'] && $me_2fa,
			'title' => __( 'Two-step verification on your account', 'potamus-security' ),
			'tip'   => ! $s['twofa_enabled'] ? __( 'Turn it on in the Login tab.', 'potamus-security' ) : ( $me_2fa ? __( 'Your account asks for an app code at login.', 'potamus-security' ) : __( 'Turn it on in your profile (Users → Profile).', 'potamus-security' ) ),
		);

		// Integridade.
		$integrity = Potamus_Integrity::last();
		if ( ! $integrity ) {
			$i_ok  = false;
			$i_tip = __( 'No check has been run yet. Open the Integrity & Threats tab.', 'potamus-security' );
		} elseif ( 'error' === $integrity['status'] ) {
			$i_ok  = false;
			$i_tip = __( 'The last check could not compare the files. Try again in the Integrity & Threats tab.', 'potamus-security' );
		} else {
			$i_ok  = 'ok' === $integrity['status'];
			$i_tip = $i_ok ? sprintf( __( 'Files match the official ones (checked on %s).', 'potamus-security' ), wp_date( 'j M Y, H:i', $integrity['time'] ) ) : __( 'Differences were found. See the Integrity & Threats tab.', 'potamus-security' );
		}
		$checks['integrity'] = array(
			'ok'    => $i_ok,
			'title' => __( 'WordPress files intact', 'potamus-security' ),
			'tip'   => $i_tip,
		);

		// Registo de utilizadores e função por defeito.
		$open    = (bool) get_option( 'users_can_register' );
		$role    = (string) get_option( 'default_role', 'subscriber' );
		$role_ok = in_array( $role, array( 'subscriber', 'customer' ), true );
		$checks['registration'] = array(
			'ok'    => ! $open || $role_ok,
			'title' => __( 'New user registration is safe', 'potamus-security' ),
			'tip'   => ! $open ? __( 'Public registration is closed.', 'potamus-security' ) : ( $role_ok ? sprintf( __( 'Registration is open with the "%s" role. If you do not need it, close it in Settings → General.', 'potamus-security' ), $role ) : sprintf( __( 'Danger: anyone who registers gets the "%s" role. Change it to Subscriber in Settings → General.', 'potamus-security' ), $role ) ),
		);

		// wp-config.php.
		$config = file_exists( ABSPATH . 'wp-config.php' ) ? ABSPATH . 'wp-config.php' : dirname( ABSPATH ) . '/wp-config.php';
		if ( file_exists( $config ) ) {
			$perm = fileperms( $config ) & 0777;
			$checks['wpconfig'] = array(
				'ok'    => ! ( $perm & 0002 ),
				'title' => sprintf( __( 'wp-config.php permissions: %s', 'potamus-security' ), substr( sprintf( '%o', $perm ), -3 ) ),
				'tip'   => ( $perm & 0002 ) ? __( 'Any user on the server can change it. Change the permissions to 640 or 600 in the File Manager.', 'potamus-security' ) : ( ( $perm & 0004 ) ? __( 'It cannot be changed by others. For extra safety you can use 640 or 600, if your host allows it.', 'potamus-security' ) : __( 'Restricted permissions.', 'potamus-security' ) ),
			);
		}

		// debug.log.
		$log = WP_CONTENT_DIR . '/debug.log';
		if ( defined( 'WP_DEBUG_LOG' ) && is_string( WP_DEBUG_LOG ) ) {
			$log = WP_DEBUG_LOG;
		}
		$log_exists    = file_exists( $log );
		$log_protected = $s['protect_sensitive'] && Potamus_Htaccess::active();
		$checks['debuglog'] = array(
			'ok'    => ! $log_exists || $log_protected,
			'title' => __( 'Error log (debug.log) protected', 'potamus-security' ),
			'tip'   => ! $log_exists ? __( 'There is no debug.log.', 'potamus-security' ) : ( $log_protected ? __( 'It exists but is blocked from the public. You can delete it if you no longer need it.', 'potamus-security' ) : __( 'debug.log may be publicly accessible and reveal paths and errors. Turn on "Protect sensitive files" or delete it.', 'potamus-security' ) ),
		);

		// Definições de ameaças e vulnerabilidades conhecidas.
		if ( Potamus_Definitions::configured() ) {
			$defs    = Potamus_Definitions::definitions();
			$st      = Potamus_Definitions::status();
			$fresh   = $defs && ! empty( $st['checked'] ) && ( time() - (int) $st['checked'] ) < 3 * DAY_IN_SECONDS;
			$checks['definitions'] = array(
				'ok'    => $fresh,
				'title' => __( 'Threat Radar up to date', 'potamus-security' ),
				'tip'   => $defs ? sprintf( __( 'Version %1$s, checked %2$s.', 'potamus-security' ), $defs['version'], ! empty( $st['checked'] ) ? self::ago( (int) $st['checked'] ) : __( 'a while ago', 'potamus-security' ) ) . ( $fresh ? '' : ' ' . __( 'See the Integrity & Threats tab.', 'potamus-security' ) ) : __( 'Not downloaded yet. Open the Integrity & Threats tab.', 'potamus-security' ),
			);
			$vulns = Potamus_Definitions::vulnerable_items();
			$checks['vulns'] = array(
				'ok'    => $defs ? empty( $vulns ) : null,
				'title' => __( 'Plugins and themes free of known vulnerabilities', 'potamus-security' ),
				'tip'   => ! $defs ? __( 'Available after updating the Threat Radar.', 'potamus-security' ) : ( $vulns ? sprintf( __( '%1$d with known flaws: %2$s. Update them as soon as possible.', 'potamus-security' ), count( $vulns ), implode( ', ', array_unique( wp_list_pluck( $vulns, 'name' ) ) ) ) : __( 'None of the installed plugins and themes are on the list.', 'potamus-security' ) ),
			);
		}

		// Prefixo das tabelas: só informativo, mudar a meio da vida do site é arriscado.
		global $wpdb;
		$checks['prefix'] = array(
			'ok'    => null,
			'title' => sprintf( __( 'Table prefix: %s', 'potamus-security' ), $wpdb->prefix ),
			'tip'   => 'wp_' === $wpdb->prefix ? __( 'It is the default prefix. It is not a problem in itself and changing it on an existing site is risky, so it does not count towards the score.', 'potamus-security' ) : __( 'Custom prefix.', 'potamus-security' ),
		);

		return $checks;
	}

	/** "há 5 minutos" / "5 minutes ago". */
	private static function ago( $time ) {
		/* translators: %s: human-readable time difference, e.g. "5 minutes". */
		return sprintf( __( '%s ago', 'potamus-security' ), human_time_diff( (int) $time ) );
	}

	/** Uma linha de descrição de uma vulnerabilidade (gravidade, título e versão corrigida). */
	private static function vuln_line( $v, $severity ) {
		$sev  = isset( $severity[ $v['severity'] ] ) ? $severity[ $v['severity'] ] : $v['severity'];
		/* translators: 1: severity, 2: vulnerability title. */
		$line = sprintf( __( 'Severity %1$s · %2$s', 'potamus-security' ), $sev, $v['title'] ? $v['title'] : __( 'known flaw', 'potamus-security' ) );
		if ( $v['fixed_in'] ) {
			/* translators: %s: version number. */
			$line .= sprintf( __( ' · fixed in version %s', 'potamus-security' ), $v['fixed_in'] );
		} elseif ( $v['max_version'] ) {
			/* translators: %s: version number. */
			$line .= sprintf( __( ' · affects up to version %s, no fix listed', 'potamus-security' ), $v['max_version'] );
		}
		return $line;
	}

	/* ---------- Componentes ---------- */

	private static function toggle( $key, $title, $desc, $recommended = true, $extra = '' ) {
		$s  = Potamus_Settings::all();
		$id = 'psec-' . $key;
		?>
		<div class="psec-row">
			<div class="psec-row__text">
				<label for="<?php echo esc_attr( $id ); ?>" class="psec-row__title">
					<?php echo esc_html( $title ); ?>
					<?php if ( $recommended ) : ?><span class="psec-badge"><?php esc_html_e( 'Recommended', 'potamus-security' ); ?></span><?php endif; ?>
				</label>
				<p class="psec-row__desc"><?php echo wp_kses_post( $desc ); ?></p>
				<?php echo $extra; // phpcs:ignore WordPress.Security.EscapeOutput -- HTML montado internamente. ?>
			</div>
			<label class="psec-switch">
				<input type="checkbox" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( Potamus_Settings::OPTION . '[' . $key . ']' ); ?>" value="1" data-key="<?php echo esc_attr( $key ); ?>" <?php checked( 1, (int) $s[ $key ] ); ?>>
				<span class="psec-switch__track" aria-hidden="true"></span>
			</label>
		</div>
		<?php
	}

	private static function name( $key ) {
		return esc_attr( Potamus_Settings::OPTION . '[' . $key . ']' );
	}

	/* ---------- Atualizações ---------- */

	private static function render_updates() {
		$configured = Potamus_Updates::configured();
		$st         = Potamus_Updates::status();
		$check_url  = wp_nonce_url( admin_url( 'admin-post.php?action=potamus_check_now' ), 'potamus_check_now' );
		?>
		<div class="psec-card">
			<h2><?php esc_html_e( 'Potamus Security updates', 'potamus-security' ); ?></h2>
			<p class="psec-muted"><?php esc_html_e( 'New versions are published by CodiPotamus and digitally signed. The plugin only accepts files with a valid signature, so neither a tampered copy nor a hacked server can install code on your site.', 'potamus-security' ); ?></p>
			<?php if ( ! $configured ) : ?>
				<div class="psec-result psec-result--none"><strong><?php esc_html_e( 'Update channel not configured yet.', 'potamus-security' ); ?></strong> <?php esc_html_e( 'This copy of the plugin has no repository or public key set, so it does not check for updates.', 'potamus-security' ); ?></div>
			<?php else : ?>
				<ul class="psec-facts">
					<li><span><?php esc_html_e( 'Installed version', 'potamus-security' ); ?></span><?php echo esc_html( POTAMUS_SECURITY_VERSION ); ?></li>
					<?php $latest = ! empty( $st['update_latest'] ) && version_compare( $st['update_latest'], POTAMUS_SECURITY_VERSION, '>' ) ? $st['update_latest'] : POTAMUS_SECURITY_VERSION; ?>
					<li><span><?php esc_html_e( 'Latest version', 'potamus-security' ); ?></span><?php echo esc_html( $latest ); ?></li>
					<li><span><?php esc_html_e( 'Last check', 'potamus-security' ); ?></span><?php echo esc_html( ! empty( $st['update_checked'] ) ? self::ago( (int) $st['update_checked'] ) : '—' ); ?></li>
					<li><span><?php esc_html_e( 'Source', 'potamus-security' ); ?></span><a href="<?php echo esc_url( 'https://github.com/' . Potamus_Updates::repo() ); ?>" target="_blank" rel="noopener"><?php echo esc_html( Potamus_Updates::repo() ); ?></a></li>
				</ul>
				<?php if ( ! empty( $st['update_error'] ) ) : ?>
					<div class="psec-result psec-result--warn"><?php echo esc_html( $st['update_error'] ); ?></div>
				<?php elseif ( ! empty( $st['update_checked'] ) && version_compare( $latest, POTAMUS_SECURITY_VERSION, '<=' ) ) : ?>
					<div class="psec-result psec-result--ok"><strong><?php esc_html_e( 'You are on the latest version.', 'potamus-security' ); ?></strong> <?php esc_html_e( 'No new version has been published yet.', 'potamus-security' ); ?></div>
				<?php endif; ?>
				<p class="psec-integrity-actions"><a class="button button-primary" href="<?php echo esc_url( $check_url ); ?>"><?php esc_html_e( 'Check for updates', 'potamus-security' ); ?></a><span class="psec-muted"><?php esc_html_e( 'Checks for a new version of the plugin. The Threat Radar is in the Integrity & Threats tab.', 'potamus-security' ); ?></span></p>
			<?php endif; ?>
		</div>

		<div class="psec-card">
			<?php
			self::toggle( 'auto_update_self', __( 'Update automatically', 'potamus-security' ), __( 'Installs new versions of Potamus Security as soon as they are published, after checking the signature. Recommended for a security plugin.', 'potamus-security' ) );
			?>
		</div>

		<?php
	}

	/* ---------- Aparência do login ---------- */

	private static function color_field( $key, $label ) {
		$s = Potamus_Settings::all();
		printf(
			'<div class="psec-color-field"><span class="psec-color-field__label">%1$s</span><input type="text" class="psec-color" aria-label="%1$s" name="%2$s" value="%3$s" data-key="%4$s" data-default-color="%5$s"></div>',
			esc_html( $label ),
			self::name( $key ), // phpcs:ignore WordPress.Security.EscapeOutput -- esc_attr em name().
			esc_attr( $s[ $key ] ),
			esc_attr( $key ),
			esc_attr( Potamus_Login_Style::defaults()[ $key ] )
		);
	}

	private static function media_field( $key, $label, $empty_text ) {
		$s   = Potamus_Settings::all();
		$id  = (int) $s[ $key ];
		$src = $id ? wp_get_attachment_image_src( $id, 'medium' ) : false;
		$url = $src ? $src[0] : '';
		?>
		<div class="psec-media" data-key="<?php echo esc_attr( $key ); ?>">
			<span class="psec-media__label"><?php echo esc_html( $label ); ?></span>
			<div class="psec-media__box">
				<div class="psec-media__thumb"><?php if ( $url ) : ?><img src="<?php echo esc_url( $url ); ?>" alt=""><?php else : ?><span><?php echo esc_html( $empty_text ); ?></span><?php endif; ?></div>
				<div class="psec-media__actions">
					<button type="button" class="button psec-media__pick"><?php esc_html_e( 'Choose image', 'potamus-security' ); ?></button>
					<button type="button" class="button-link psec-media__remove" <?php echo $url ? '' : 'hidden'; ?>><?php esc_html_e( 'Remove', 'potamus-security' ); ?></button>
				</div>
			</div>
			<input type="hidden" name="<?php echo self::name( $key ); // phpcs:ignore ?>" value="<?php echo esc_attr( $id ); ?>" data-url="<?php echo esc_attr( $url ); ?>">
		</div>
		<?php
	}

	private static function range_field( $key, $label, $min, $max, $unit = 'px' ) {
		$s = Potamus_Settings::all();
		printf(
			'<label class="psec-range"><span>%1$s <output>%2$d%5$s</output></span><input type="range" min="%3$d" max="%4$d" name="%6$s" value="%2$d" data-key="%7$s" data-unit="%5$s"></label>',
			esc_html( $label ),
			(int) $s[ $key ],
			(int) $min,
			(int) $max,
			esc_html( $unit ),
			self::name( $key ), // phpcs:ignore
			esc_attr( $key )
		);
	}

	private static function render_appearance() {
		$s = Potamus_Settings::all();
		?>
		<div class="psec-ls">
			<div class="psec-ls__settings">
				<div class="psec-card">
					<?php
					$view = '<p class="psec-help"><a href="' . esc_url( wp_login_url() ) . '" target="_blank" rel="noopener">' . esc_html__( 'Open the login page in a new tab ↗', 'potamus-security' ) . '</a> ' . esc_html__( '(save first to see the changes)', 'potamus-security' ) . '</p>';
					self::toggle( 'ls_enabled', __( 'Customize the login page', 'potamus-security' ), __( 'Applies the logo, background, corners and colors chosen below. It also applies to the two-step verification screen. Turning it off brings back the normal WordPress look.', 'potamus-security' ), false, $view );
					?>
				</div>

				<div class="psec-card">
					<h2><?php esc_html_e( 'Logo', 'potamus-security' ); ?></h2>
					<?php self::media_field( 'ls_logo_id', __( 'Image', 'potamus-security' ), __( 'WordPress logo', 'potamus-security' ) ); ?>
					<?php self::range_field( 'ls_logo_width', __( 'Width', 'potamus-security' ), 40, 320 ); ?>
					<label class="psec-text-field"><span><?php esc_html_e( 'Logo link', 'potamus-security' ); ?></span>
						<input type="url" class="regular-text" name="<?php echo self::name( 'ls_logo_link' ); // phpcs:ignore ?>" value="<?php echo esc_attr( $s['ls_logo_link'] ); ?>" placeholder="<?php echo esc_attr( home_url( '/' ) ); ?>">
						<small><?php esc_html_e( 'If left empty, it links to the site\'s home page.', 'potamus-security' ); ?></small>
					</label>
				</div>

				<div class="psec-card">
					<h2><?php esc_html_e( 'Background', 'potamus-security' ); ?></h2>
					<div class="psec-segmented" role="radiogroup">
						<?php foreach ( array( 'color' => __( 'Color', 'potamus-security' ), 'gradient' => __( 'Gradient', 'potamus-security' ), 'image' => __( 'Image', 'potamus-security' ) ) as $val => $label ) : ?>
							<label><input type="radio" name="<?php echo self::name( 'ls_bg_type' ); // phpcs:ignore ?>" value="<?php echo esc_attr( $val ); ?>" <?php checked( $s['ls_bg_type'], $val ); ?>><span><?php echo esc_html( $label ); ?></span></label>
						<?php endforeach; ?>
					</div>
					<div class="psec-color-grid">
						<?php self::color_field( 'ls_bg_color', __( 'Background color', 'potamus-security' ) ); ?>
						<div class="psec-when" data-when="gradient"><?php self::color_field( 'ls_bg_color2', __( 'Second color', 'potamus-security' ) ); ?></div>
					</div>
					<div class="psec-when" data-when="image">
						<?php self::media_field( 'ls_bg_image_id', __( 'Background image', 'potamus-security' ), __( 'No image', 'potamus-security' ) ); ?>
						<?php self::range_field( 'ls_bg_overlay', __( 'Darken the image', 'potamus-security' ), 0, 80, '%' ); ?>
						<p class="psec-help"><?php esc_html_e( 'Darkening helps the links below the form stay readable. The background color is used while the image loads.', 'potamus-security' ); ?></p>
					</div>
				</div>

				<div class="psec-card">
					<h2><?php esc_html_e( 'Rounded corners', 'potamus-security' ); ?></h2>
					<?php self::range_field( 'ls_radius_box', __( 'Form box', 'potamus-security' ), 0, 40 ); ?>
					<?php self::range_field( 'ls_radius_fields', __( 'Fields and button', 'potamus-security' ), 0, 30 ); ?>
				</div>

				<div class="psec-card">
					<h2><?php esc_html_e( 'Colors', 'potamus-security' ); ?></h2>
					<div class="psec-color-grid">
						<?php
						self::color_field( 'ls_form_bg', __( 'Form background', 'potamus-security' ) );
						self::color_field( 'ls_text', __( 'Text', 'potamus-security' ) );
						self::color_field( 'ls_input_bg', __( 'Field background', 'potamus-security' ) );
						self::color_field( 'ls_input_border', __( 'Field border', 'potamus-security' ) );
						self::color_field( 'ls_button_bg', __( 'Button', 'potamus-security' ) );
						self::color_field( 'ls_button_text', __( 'Button text', 'potamus-security' ) );
						self::color_field( 'ls_link', __( 'Links', 'potamus-security' ) );
						self::color_field( 'ls_accent', __( 'Message accent', 'potamus-security' ) );
						?>
					</div>
					<p><button type="button" class="button-link psec-ls-reset"><?php esc_html_e( 'Restore the original WordPress look', 'potamus-security' ); ?></button></p>
				</div>
			</div>

			<div class="psec-ls__preview">
				<div class="psec-ls__sticky">
					<span class="psec-ls__caption"><?php esc_html_e( 'Preview', 'potamus-security' ); ?></span>
					<div class="psec-lp" id="psec-lp">
						<div class="psec-lp__inner">
							<a class="psec-lp__logo" tabindex="-1"><img alt="" hidden><svg viewBox="0 0 80 80" aria-hidden="true"><circle cx="40" cy="40" r="37" fill="none" stroke="currentColor" stroke-width="3"/><path fill="currentColor" d="M16 26h9l8 26 6-17-3-9h8l9 26 7-26h8L56 60h-6l-8-23-8 23h-6z"/></svg></a>
							<div class="psec-lp__form">
								<span class="psec-lp__label"><?php esc_html_e( 'Username or Email Address', 'potamus-security' ); ?></span>
								<span class="psec-lp__input"></span>
								<span class="psec-lp__label"><?php esc_html_e( 'Password', 'potamus-security' ); ?></span>
								<span class="psec-lp__input"></span>
								<div class="psec-lp__row"><span class="psec-lp__check"></span><span class="psec-lp__label"><?php esc_html_e( 'Remember Me', 'potamus-security' ); ?></span><span class="psec-lp__btn"><?php esc_html_e( 'Log In', 'potamus-security' ); ?></span></div>
							</div>
							<div class="psec-lp__msg"><?php esc_html_e( 'Messages and notices', 'potamus-security' ); ?></div>
							<div class="psec-lp__links"><span><?php esc_html_e( 'Lost your password?', 'potamus-security' ); ?></span><span><?php /* translators: %s: site name. */ echo esc_html( sprintf( __( '&larr; Go to %s', 'potamus-security' ), get_bloginfo( 'name' ) ) ); ?></span></div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	private static function render_definitions() {
		if ( ! Potamus_Definitions::configured() ) {
			return;
		}
		$st       = Potamus_Definitions::status();
		$defs     = Potamus_Definitions::definitions();
		$now_url  = wp_nonce_url( admin_url( 'admin-post.php?action=potamus_defs_now' ), 'potamus_defs_now' );
		$severity = array(
			'critical' => __( 'Critical', 'potamus-security' ),
			'high'     => __( 'High', 'potamus-security' ),
			'medium'   => __( 'Medium', 'potamus-security' ),
			'low'      => __( 'Low', 'potamus-security' ),
		);
		?>
		<div class="psec-card">
			<h2><?php esc_html_e( 'Threat Radar', 'potamus-security' ); ?></h2>
			<p class="psec-muted"><?php esc_html_e( 'A list published by CodiPotamus and digitally signed, with malicious code patterns (also used when inspecting files) and plugins and themes with known security flaws. The comparison happens on your site: nothing about the site is sent out.', 'potamus-security' ); ?></p>
			<?php if ( ! $defs ) : ?>
				<div class="psec-result psec-result--none"><strong><?php esc_html_e( 'Not downloaded yet.', 'potamus-security' ); ?></strong> <?php esc_html_e( 'Click "Update the radar now".', 'potamus-security' ); ?></div>
			<?php else : ?>
				<ul class="psec-facts">
					<li><span><?php esc_html_e( 'Version', 'potamus-security' ); ?></span><?php echo esc_html( $defs['version'] ); ?></li>
					<li><span><?php esc_html_e( 'Malicious code patterns', 'potamus-security' ); ?></span><?php /* translators: %d: number of extra patterns. */ echo esc_html( sprintf( __( '%d extra', 'potamus-security' ), count( $defs['patterns'] ) ) ); ?></li>
					<li><span><?php esc_html_e( 'Known vulnerabilities', 'potamus-security' ); ?></span><?php echo esc_html( count( $defs['vulnerabilities'] ) ); ?></li>
					<li><span><?php esc_html_e( 'Last check', 'potamus-security' ); ?></span><?php echo esc_html( ! empty( $st['checked'] ) ? self::ago( (int) $st['checked'] ) : '—' ); ?></li>
				</ul>
				<?php
				$vulns = Potamus_Definitions::vulnerable_items();
				if ( $vulns ) :
					?>
					<div class="psec-result psec-result--bad"><strong><?php esc_html_e( 'Warning:', 'potamus-security' ); ?></strong> <?php esc_html_e( 'some installed plugins or themes have known security flaws. Update them in Dashboard → Updates.', 'potamus-security' ); ?></div>
					<ul class="psec-findings">
						<?php foreach ( $vulns as $v ) : ?>
							<li class="is-<?php echo esc_attr( in_array( $v['severity'], array( 'critical', 'high' ), true ) ? 'high' : 'medium' ); ?>">
								<strong><?php echo esc_html( $v['name'] . ' ' . $v['installed'] ); ?></strong>
								<?php if ( ! empty( $v['exploited'] ) ) : ?><span class="psec-badge psec-badge--bad"><?php esc_html_e( 'Actively exploited', 'potamus-security' ); ?></span><?php endif; ?>
								<span><?php echo esc_html( self::vuln_line( $v, $severity ) ); ?><?php if ( $v['url'] ) : ?> · <a href="<?php echo esc_url( $v['url'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $v['cve'] ? $v['cve'] : __( 'details', 'potamus-security' ) ); ?></a><?php endif; ?></span>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php else : ?>
					<div class="psec-result psec-result--ok"><strong><?php esc_html_e( 'No installed plugin or theme is on the list of known vulnerabilities.', 'potamus-security' ); ?></strong></div>
				<?php endif; ?>
			<?php endif; ?>
			<?php if ( ! empty( $st['error'] ) ) : ?>
				<div class="psec-result psec-result--warn"><?php echo esc_html( $st['error'] ); ?></div>
			<?php endif; ?>
			<?php if ( $defs && ! empty( $defs['sources'] ) ) : ?>
				<p class="psec-help psec-sources"><?php esc_html_e( 'Public sources:', 'potamus-security' ); ?>
					<?php
					$links = array();
					foreach ( $defs['sources'] as $src ) {
						$label   = $src['name'] . ( $src['license'] ? ' (' . $src['license'] . ')' : '' );
						$links[] = $src['url'] ? '<a href="' . esc_url( $src['url'] ) . '" target="_blank" rel="noopener">' . esc_html( $label ) . '</a>' : esc_html( $label );
					}
					echo implode( ' · ', $links ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado acima.
					foreach ( $defs['sources'] as $src ) {
						if ( $src['notice'] ) {
							echo '<br>' . esc_html( $src['notice'] );
						}
					}
					?>
				</p>
			<?php endif; ?>
		</div>
		<div class="psec-card">
			<?php self::toggle( 'definitions_daily', __( 'Update the radar every day', 'potamus-security' ), __( 'Downloads the latest version of the threat list once a day. It is a small file, only accepted with a valid signature, and sends no information about the site.', 'potamus-security' ) ); ?>
			<p class="psec-integrity-actions"><a class="button" href="<?php echo esc_url( $now_url ); ?>"><?php esc_html_e( 'Update the radar now', 'potamus-security' ); ?></a></p>
		</div>
		<?php
	}

	/* ---------- Integridade ---------- */

	private static function inspect_url( $file ) {
		return wp_nonce_url( admin_url( 'admin.php?page=' . self::SLUG . '&psec_tab=integrity&psec_inspect=' . rawurlencode( $file ) ), 'psec_inspect' );
	}

	/** Conteúdo da inspeção (usado na janela e na página de recurso sem JavaScript). */
	private static function inspection_body( $file ) {
		$i = Potamus_Integrity::inspect( $file );
		ob_start();
		if ( is_wp_error( $i ) ) {
			echo '<p>' . esc_html( $i->get_error_message() ) . '</p>';
			return ob_get_clean();
		}
		$verdicts = array(
			'clean'  => array( 'ok', __( 'No signs of malicious code', 'potamus-security' ), __( 'None of the usual malicious code patterns were found. Even so, if the file is not yours and you do not need it, you can delete it.', 'potamus-security' ) ),
			'medium' => array( 'warn', __( 'Needs review', 'potamus-security' ), __( 'It has instructions that legitimate code also uses, but which often appear in malicious code. Check the lines shown or ask for help before deciding.', 'potamus-security' ) ),
			'high'   => array( 'bad', __( 'Suspicious', 'potamus-security' ), __( 'It has typical malicious code patterns. Do not open it in the browser. Make a backup, delete it and change your WordPress and hosting passwords.', 'potamus-security' ) ),
		);
		$v = $verdicts[ $i['verdict'] ];
		?>
		<p class="psec-muted"><?php esc_html_e( 'The file was read as text, without being executed.', 'potamus-security' ); ?></p>
		<div class="psec-result psec-result--<?php echo esc_attr( $v[0] ); ?>"><strong><?php echo esc_html( $v[1] ); ?>.</strong> <?php echo esc_html( $v[2] ); ?></div>
		<ul class="psec-facts">
			<li><span><?php esc_html_e( 'Size', 'potamus-security' ); ?></span><?php echo esc_html( size_format( $i['size'], 1 ) ); ?></li>
			<li><span><?php esc_html_e( 'Lines', 'potamus-security' ); ?></span><?php echo esc_html( $i['lines'] ); ?></li>
			<li><span><?php esc_html_e( 'Last modified', 'potamus-security' ); ?></span><?php echo esc_html( wp_date( get_option( 'date_format' ) . ', ' . get_option( 'time_format' ), $i['modified'] ) ); ?></li>
			<li><span><?php esc_html_e( 'Permissions', 'potamus-security' ); ?></span><?php echo esc_html( $i['perms'] ); ?></li>
			<li><span><?php esc_html_e( 'Contains PHP', 'potamus-security' ); ?></span><?php echo esc_html( $i['is_php'] ? __( 'Yes', 'potamus-security' ) : __( 'No', 'potamus-security' ) ); ?></li>
		</ul>
		<?php if ( $i['findings'] ) : ?>
			<h3><?php esc_html_e( 'What was found', 'potamus-security' ); ?></h3>
			<ul class="psec-findings">
				<?php foreach ( $i['findings'] as $f ) : ?>
					<li class="is-<?php echo esc_attr( $f['level'] ); ?>"><strong><?php echo esc_html( $f['label'] ); ?></strong> <span><?php echo esc_html( sprintf(
							/* translators: 1: number of occurrences, 2: list of line numbers. */
							_n( '%1$d time · line(s) %2$s', '%1$d times · line(s) %2$s', (int) $f['count'], 'potamus-security' ),
							$f['count'],
							implode( ', ', $f['lines'] )
						) ); ?></span></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
		<details class="psec-files"><summary><?php esc_html_e( 'Show content', 'potamus-security' ); ?><?php echo $i['truncated'] ? ' ' . esc_html__( '(first 200 lines)', 'potamus-security' ) : ''; ?></summary>
			<pre class="psec-code"><?php echo esc_html( $i['preview'] ); ?></pre>
		</details>
		<?php
		return ob_get_clean();
	}

	/** Pedido da janela (lightbox). */
	public static function ajax_inspect() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'html' => '<p>' . esc_html__( 'Not allowed.', 'potamus-security' ) . '</p>' ), 403 );
		}
		check_ajax_referer( 'psec_inspect' );
		$file = isset( $_GET['file'] ) ? sanitize_text_field( wp_unslash( $_GET['file'] ) ) : '';
		wp_send_json_success( array( 'html' => self::inspection_body( $file ) ) );
	}

	/** Recurso sem JavaScript: a inspeção aparece na própria página. */
	private static function render_inspection() {
		// phpcs:disable WordPress.Security.NonceVerification
		if ( empty( $_GET['psec_inspect'] ) ) {
			return;
		}
		$file = sanitize_text_field( wp_unslash( $_GET['psec_inspect'] ) );
		// phpcs:enable
		if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_key( $_GET['_wpnonce'] ), 'psec_inspect' ) ) {
			return;
		}
		$back = admin_url( 'admin.php?page=' . self::SLUG . '&psec_tab=integrity' );
		echo '<div class="psec-card psec-inspect"><h2>' . esc_html__( 'Inspection:', 'potamus-security' ) . ' <code>' . esc_html( $file ) . '</code></h2>';
		echo self::inspection_body( $file ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado em inspection_body().
		echo '<p><a class="button" href="' . esc_url( $back ) . '">' . esc_html__( '← Back to the check', 'potamus-security' ) . '</a></p></div>';
	}

	/** Janela (lightbox) onde a inspeção é mostrada. */
	private static function render_inspect_dialog() {
		?>
		<dialog class="psec-dialog" id="psec-dialog" aria-labelledby="psec-dialog-title">
			<div class="psec-dialog__head">
				<h2 id="psec-dialog-title"><?php esc_html_e( 'Inspection:', 'potamus-security' ); ?> <code class="psec-dialog__file"></code></h2>
				<button type="button" class="psec-dialog__close" aria-label="<?php esc_attr_e( 'Close', 'potamus-security' ); ?>">×</button>
			</div>
			<div class="psec-dialog__body"></div>
		</dialog>
		<?php
	}

	private static function render_integrity() {
		self::render_inspection();
		self::render_inspect_dialog();
		$r   = Potamus_Integrity::last();
		$run = wp_nonce_url( admin_url( 'admin-post.php?action=potamus_integrity' ), 'potamus_integrity' );
		$labels = array(
			'modified' => array( __( 'Modified files', 'potamus-security' ), __( 'Different from the original. If you did not edit them on purpose, they may have been changed by an attacker.', 'potamus-security' ) ),
			'missing'  => array( __( 'Missing files', 'potamus-security' ), __( 'They are part of WordPress but are not on the server. Reinstall WordPress in Dashboard → Updates.', 'potamus-security' ) ),
			'extra'    => array( __( 'Unknown files', 'potamus-security' ), __( 'They are not part of WordPress and are in core folders (or are .php files in the root). Some may be legitimate (Google verifications, hosting tools), but it is worth checking.', 'potamus-security' ) ),
		);
		?>
		<div class="psec-card">
			<h2><?php esc_html_e( 'WordPress integrity', 'potamus-security' ); ?></h2>
			<p class="psec-muted"><?php esc_html_e( 'Compares every WordPress core file with the official version from WordPress.org, to detect injected code or modified files. It does not check themes or plugins.', 'potamus-security' ); ?></p>

			<?php if ( ! $r ) : ?>
				<div class="psec-result psec-result--none"><strong><?php esc_html_e( 'No check has been run yet.', 'potamus-security' ); ?></strong></div>
			<?php elseif ( 'error' === $r['status'] ) : ?>
				<div class="psec-result psec-result--warn"><strong><?php esc_html_e( 'Could not run the check.', 'potamus-security' ); ?></strong> <?php /* translators: %s: WordPress version. */ echo esc_html( sprintf( __( 'Could not get the official checksums for WordPress %s. It may be a development version or a temporary connection problem.', 'potamus-security' ), $r['version'] ) ); ?></div>
			<?php elseif ( 'ok' === $r['status'] ) : ?>
				<div class="psec-result psec-result--ok"><strong><?php esc_html_e( 'All good.', 'potamus-security' ); ?></strong> <?php echo esc_html( sprintf( /* translators: 1: number of files, 2: WordPress version. */ __( '%1$d WordPress %2$s files checked, no suspicious changes.', 'potamus-security' ), $r['checked'], $r['version'] ) ); ?></div>
			<?php else : ?>
				<div class="psec-result psec-result--warn"><strong><?php esc_html_e( 'Differences were found.', 'potamus-security' ); ?></strong> <?php echo esc_html( sprintf( /* translators: 1: WordPress version, 2: number of files. */ __( 'WordPress %1$s · %2$d files checked.', 'potamus-security' ), $r['version'], $r['checked'] ) ); ?></div>
				<?php foreach ( $labels as $key => $label ) : ?>
					<?php if ( ! empty( $r[ $key ] ) ) : ?>
						<details class="psec-files" <?php echo 'modified' === $key ? 'open' : ''; ?>>
							<summary><?php echo esc_html( sprintf( '%s (%d)', $label[0], count( $r[ $key ] ) ) ); ?></summary>
							<p class="psec-muted"><?php echo esc_html( $label[1] ); ?></p>
							<ul><?php foreach ( $r[ $key ] as $f ) : ?><li><code><?php echo esc_html( $f ); ?></code> <a class="psec-inspect-link" href="<?php echo esc_url( self::inspect_url( $f ) ); ?>" data-file="<?php echo esc_attr( $f ); ?>"><?php esc_html_e( 'Inspect', 'potamus-security' ); ?></a></li><?php endforeach; ?></ul>
						</details>
					<?php endif; ?>
				<?php endforeach; ?>
			<?php endif; ?>

			<?php if ( $r && ! empty( $r['localized'] ) ) : ?>
				<?php $lang = ! empty( $r['locale'] ) ? Potamus_Integrity::language_label( $r['locale'] ) : ''; ?>
				<p class="psec-muted"><?php echo esc_html( sprintf(
					/* translators: 1: number of files, 2: list of files, 3: language name. */
					$lang ? __( '%1$d translated file(s) (%2$s) differ from the English version, as is normal for WordPress in %3$s. They were analysed separately and contain no suspicious code.', 'potamus-security' ) : __( '%1$d translated file(s) (%2$s) differ from the English version, as is normal for translated WordPress. They were analysed separately and contain no suspicious code.', 'potamus-security' ),
					count( $r['localized'] ),
					implode( ', ', $r['localized'] ),
					$lang
				) ); ?></p>
			<?php endif; ?>

			<p class="psec-integrity-actions">
				<a href="<?php echo esc_url( $run ); ?>" class="button button-primary psec-run"><?php esc_html_e( 'Check now', 'potamus-security' ); ?></a>
				<?php if ( $r ) : ?><span class="psec-muted"><?php echo esc_html( sprintf( /* translators: %s: date and time. */ __( 'Last check: %s', 'potamus-security' ), wp_date( get_option( 'date_format' ) . ', ' . get_option( 'time_format' ), $r['time'] ) ) ); ?></span><?php endif; ?>
			</p>
		</div>

		<div class="psec-card">
			<?php self::toggle( 'integrity_weekly', __( 'Automatic weekly check', 'potamus-security' ), __( 'Repeats the check once a week, in the background. The result appears on the Dashboard. It takes a few seconds and does not affect visitors.', 'potamus-security' ) ); ?>
		</div>
		<?php
		self::render_definitions();
	}

	/* ---------- Página ---------- */

	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s       = Potamus_Settings::all();
		$checks  = self::checks();
		$scored  = array_filter( $checks, function ( $c ) { return null !== $c['ok']; } );
		$passed  = count( array_filter( wp_list_pluck( $scored, 'ok' ) ) );
		$score   = (int) round( $passed / max( 1, count( $scored ) ) * 100 );
		$level   = $score >= 80 ? 'good' : ( $score >= 50 ? 'fair' : 'poor' );
		$mood    = array(
			'good' => __( 'Your hippo is relaxed. The site is well protected.', 'potamus-security' ),
			'fair' => __( 'The hippo is alert. There are a few things to improve.', 'potamus-security' ),
			'poor' => __( 'The hippo is worried. The points below are worth dealing with.', 'potamus-security' ),
		);
		$lockouts = (int) get_option( 'potamus_security_lockouts', 0 );
		$circ     = 2 * M_PI * 52;
		?>
		<div class="wrap psec">
			<header class="psec-header">
				<span class="psec-logo"><?php echo self::icon_svg( 'currentColor' ); // phpcs:ignore ?></span>
				<div>
					<h1>Potamus Security</h1>
					<p><?php esc_html_e( 'Sail the murky waters of security with Potamus.', 'potamus-security' ); ?><br><?php esc_html_e( 'Simple but effective security for your WordPress.', 'potamus-security' ); ?></p>
				</div>
			</header>
			<hr class="wp-header-end">

			<?php settings_errors(); ?>

			<nav class="psec-tabs" role="tablist">
				<button type="button" class="psec-tab is-active" data-tab="dashboard" role="tab"><?php esc_html_e( 'Dashboard', 'potamus-security' ); ?></button>
				<button type="button" class="psec-tab" data-tab="hide" role="tab"><?php esc_html_e( 'Hide WordPress', 'potamus-security' ); ?></button>
				<button type="button" class="psec-tab" data-tab="login" role="tab"><?php esc_html_e( 'Login', 'potamus-security' ); ?></button>
				<button type="button" class="psec-tab" data-tab="appearance" role="tab"><?php esc_html_e( 'Login appearance', 'potamus-security' ); ?></button>
				<button type="button" class="psec-tab" data-tab="protect" role="tab"><?php esc_html_e( 'Protections', 'potamus-security' ); ?></button>
				<button type="button" class="psec-tab" data-tab="integrity" role="tab"><?php esc_html_e( 'Integrity & Threats', 'potamus-security' ); ?></button>
				<?php if ( class_exists( 'Potamus_Updates' ) ) : ?>
				<button type="button" class="psec-tab" data-tab="updates" role="tab"><?php esc_html_e( 'Updates', 'potamus-security' ); ?></button>
				<?php endif; ?>
			</nav>

			<section class="psec-panel is-active" data-panel="dashboard">
				<div class="psec-card psec-score psec-score--<?php echo esc_attr( $level ); ?>">
					<div class="psec-ring-wrap">
					<svg class="psec-ring" viewBox="0 0 120 120" aria-hidden="true">
						<circle cx="60" cy="60" r="52" class="psec-ring__bg"/>
						<circle cx="60" cy="60" r="52" class="psec-ring__fg" stroke-dasharray="<?php echo esc_attr( $circ ); ?>" stroke-dashoffset="<?php echo esc_attr( $circ * ( 1 - $score / 100 ) ); ?>"/>
					</svg>
					<div class="psec-score__num"><?php echo esc_html( $score ); ?><small>%</small></div>
					</div>
					<div class="psec-score__text">
						<h2><?php esc_html_e( 'Protection level', 'potamus-security' ); ?></h2>
						<p><?php echo esc_html( $mood[ $level ] ); ?></p>
						<p class="psec-muted"><?php echo esc_html( sprintf( /* translators: 1: checks passed, 2: total checks, 3: number of login lockouts. */ __( '%1$d of %2$d checks passed · %3$d login lockout(s) since installation', 'potamus-security' ), $passed, count( $scored ), $lockouts ) ); ?></p>
					</div>
				</div>

				<?php if ( $s['login_enabled'] && ! Potamus_Login::recovery_mode() ) : ?>
					<div class="psec-card psec-loginbox">
						<div>
							<strong><?php esc_html_e( 'Your login address', 'potamus-security' ); ?></strong>
							<code id="psec-login-url"><?php echo esc_html( Potamus_Login::login_url() ); ?></code>
						</div>
						<button type="button" class="button" data-copy="#psec-login-url"><?php esc_html_e( 'Copy', 'potamus-security' ); ?></button>
					</div>
				<?php endif; ?>

				<?php if ( Potamus_Login::recovery_mode() ) : ?>
					<div class="notice notice-warning inline"><p><?php echo wp_kses( __( 'Recovery mode is on (<code>POTAMUS_SECURITY_RECOVERY</code> in wp-config.php): the custom login address is turned off.', 'potamus-security' ), array( 'code' => array() ) ); ?></p></div>
				<?php endif; ?>

				<div class="psec-card">
					<h2><?php esc_html_e( 'Checks', 'potamus-security' ); ?></h2>
					<ul class="psec-checks">
						<?php foreach ( $checks as $c ) : ?>
							<?php $state = null === $c['ok'] ? 'info' : ( $c['ok'] ? 'ok' : 'warn' ); ?>
							<li class="is-<?php echo esc_attr( $state ); ?>">
								<span class="psec-dot" aria-hidden="true"><?php echo 'ok' === $state ? '✓' : ( 'info' === $state ? 'i' : '!' ); ?></span>
								<div><strong><?php echo esc_html( $c['title'] ); ?></strong><span><?php echo esc_html( $c['tip'] ); ?></span></div>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			</section>

			<form method="post" action="options.php" class="psec-form">
				<?php settings_fields( 'potamus_security_group' ); ?>

				<section class="psec-panel" data-panel="hide">
					<div class="psec-card">
						<h2><?php esc_html_e( 'Hide WordPress', 'potamus-security' ); ?></h2>
						<p class="psec-muted"><?php esc_html_e( 'Removes from the site\'s code the clues that bots use to find out it is WordPress and which version it runs.', 'potamus-security' ); ?></p>
						<?php
						self::toggle( 'hide_versions', __( 'Hide versions', 'potamus-security' ), __( 'Removes the WordPress version from the code and replaces the "?ver=" of CSS and JS files with a neutral code. Browser caching keeps working.', 'potamus-security' ) );
						self::toggle( 'clean_head', __( 'Clean headers and code', 'potamus-security' ), __( 'Removes the <code>X-Powered-By</code> header (which shows the PHP version), the links to <code>wp-json</code>, the shortlink and other unnecessary lines.', 'potamus-security' ) );
						self::toggle( 'strip_generators', __( 'Remove plugin signatures', 'potamus-security' ), __( 'Deletes the "generator" tags that Elementor and other plugins add to the code.', 'potamus-security' ) );
						self::toggle( 'block_files', __( 'Block revealing files', 'potamus-security' ), __( '<code>readme.html</code> and <code>license.txt</code> show the WordPress version. They will return a 404 error.', 'potamus-security' ) );
						self::toggle( 'block_author_enum', __( 'Hide usernames', 'potamus-security' ), __( 'Blocks the <code>?author=1</code> trick, the API user list and the author sitemap, which reveal the names used to log in.', 'potamus-security' ) );
						?>
					</div>
				</section>

				<section class="psec-panel" data-panel="login">
					<div class="psec-card">
						<h2><?php esc_html_e( 'Login', 'potamus-security' ); ?></h2>
						<?php
						$slug_field  = '<div class="psec-inline">';
						$slug_field .= '<span class="psec-prefix">' . esc_html( trailingslashit( home_url() ) ) . '</span>';
						$slug_field .= '<input type="text" class="regular-text psec-slug" name="' . self::name( 'login_slug' ) . '" value="' . esc_attr( $s['login_slug'] ) . '" spellcheck="false">';
						$slug_field .= '</div>';
						$slug_field .= '<p class="psec-help">' . __( '⚠️ Bookmark the new address. If you lose it, add <code>define( \'POTAMUS_SECURITY_RECOVERY\', true );</code> to <code>wp-config.php</code> (or rename the plugin folder in the File Manager) to log in through wp-login.php again.', 'potamus-security' ) . '</p>';
						self::toggle( 'login_enabled', __( 'Custom login address', 'potamus-security' ), __( '<code>wp-login.php</code> and <code>/wp-admin</code> no longer exist for anyone who is not logged in. You can only log in through the address you choose.', 'potamus-security' ), true, $slug_field );

						$limit_fields  = '<div class="psec-inline">';
						$limit_fields .= '<label>' . esc_html__( 'Attempts', 'potamus-security' ) . ' <input type="number" min="2" max="20" name="' . self::name( 'max_attempts' ) . '" value="' . esc_attr( $s['max_attempts'] ) . '"></label>';
						$limit_fields .= '<label>' . esc_html__( 'Lockout (minutes)', 'potamus-security' ) . ' <input type="number" min="5" max="1440" name="' . self::name( 'lockout_minutes' ) . '" value="' . esc_attr( $s['lockout_minutes'] ) . '"></label>';
						$limit_fields .= '</div>';
						self::toggle( 'limit_login', __( 'Limit login attempts', 'potamus-security' ), __( 'After several wrong passwords in a row, the IP address is blocked for a while. Stops brute-force attacks.', 'potamus-security' ), true, $limit_fields );

						self::toggle( 'generic_errors', __( 'Neutral error messages', 'potamus-security' ), __( 'Instead of "user does not exist" or "wrong password", it always shows "invalid login details". That way nobody can find out which users exist.', 'potamus-security' ) );
						?>
					</div>

					<div class="psec-card">
						<h2><?php esc_html_e( 'Two-step verification (2FA)', 'potamus-security' ); ?></h2>
						<p class="psec-muted"><?php esc_html_e( 'Even if someone finds out the password, they cannot get in without the code that changes every 30 seconds in the phone app.', 'potamus-security' ); ?></p>
						<?php
						$me_link = '<p class="psec-help">' . ( Potamus_TwoFA::user_has( get_current_user_id() ) ? esc_html__( '✓ It is already on for your account.', 'potamus-security' ) : '→ <a href="' . esc_url( admin_url( 'profile.php#potamus-2fa' ) ) . '">' . esc_html__( 'Set it up on my account', 'potamus-security' ) . '</a>' ) . '</p>';
						self::toggle( 'twofa_enabled', __( 'Allow two-step verification', 'potamus-security' ), __( 'Each user can turn it on in their profile, with Google Authenticator, Microsoft Authenticator, 1Password, etc. It is only asked of those who turned it on. Includes 8 recovery codes.', 'potamus-security' ), true, $me_link );
						self::toggle( 'twofa_force_admins', __( 'Required for administrators', 'potamus-security' ), __( 'Administrators without 2FA are taken to their profile after logging in and see a notice until they set it up. It does not block access.', 'potamus-security' ), false );
						?>
					</div>

					<details class="psec-card psec-advanced">
						<summary><?php esc_html_e( 'Advanced: IP address source', 'potamus-security' ); ?></summary>
						<p class="psec-muted"><?php esc_html_e( 'Only change this if the site is behind a proxy or CDN and the lockouts are catching everyone. Address seen now:', 'potamus-security' ); ?> <code><?php echo esc_html( Potamus_Login::client_ip() ); ?></code></p>
						<select name="<?php echo self::name( 'ip_source' ); // phpcs:ignore ?>">
							<?php
							$sources = array(
								'remote_addr'      => __( 'Direct connection (REMOTE_ADDR) — recommended', 'potamus-security' ),
								'x_forwarded_for'  => 'X-Forwarded-For',
								'x_real_ip'        => 'X-Real-IP',
								'cf_connecting_ip' => 'Cloudflare (CF-Connecting-IP)',
							);
							foreach ( $sources as $val => $label ) {
								$seen = '';
								$map  = array( 'remote_addr' => 'REMOTE_ADDR', 'x_forwarded_for' => 'HTTP_X_FORWARDED_FOR', 'x_real_ip' => 'HTTP_X_REAL_IP', 'cf_connecting_ip' => 'HTTP_CF_CONNECTING_IP' );
								if ( ! empty( $_SERVER[ $map[ $val ] ] ) ) {
									$seen = ' → ' . sanitize_text_field( wp_unslash( $_SERVER[ $map[ $val ] ] ) );
								}
								printf( '<option value="%s" %s>%s%s</option>', esc_attr( $val ), selected( $s['ip_source'], $val, false ), esc_html( $label ), esc_html( $seen ) );
							}
							?>
						</select>
					</details>
				</section>

				<section class="psec-panel" data-panel="protect">
					<div class="psec-card">
						<h2><?php esc_html_e( 'Protections', 'potamus-security' ); ?></h2>
						<?php
						self::toggle( 'disable_xmlrpc', __( 'Disable XML-RPC', 'potamus-security' ), __( 'An old door widely used in attacks. Only leave it on if you use Jetpack or the WordPress mobile app.', 'potamus-security' ) );

						$rest  = '<div class="psec-radios">';
						$modes = array(
							'users'   => array( __( 'Hide only the user list', 'potamus-security' ), __( 'Recommended. Does not interfere with any plugin.', 'potamus-security' ) ),
							'private' => array( __( 'Logged-in users only', 'potamus-security' ), __( 'Stricter. May affect forms or plugins that use the API for visitors.', 'potamus-security' ) ),
							'open'    => array( __( 'Open', 'potamus-security' ), __( 'Normal WordPress behavior.', 'potamus-security' ) ),
						);
						foreach ( $modes as $val => $m ) {
							$rest .= '<label class="psec-radio"><input type="radio" name="' . self::name( 'rest_mode' ) . '" value="' . esc_attr( $val ) . '" ' . checked( $s['rest_mode'], $val, false ) . '><span><strong>' . esc_html( $m[0] ) . '</strong>' . esc_html( $m[1] ) . '</span></label>';
						}
						$rest .= '<div class="psec-rest-allow"><label>' . wp_kses( __( 'Exceptions (one per line, e.g. <code>contact-form-7</code>)', 'potamus-security' ), array( 'code' => array() ) ) . '</label><textarea rows="3" name="' . self::name( 'rest_allow' ) . '">' . esc_textarea( $s['rest_allow'] ) . '</textarea></div>';
						$rest .= '</div>';
						?>
						<div class="psec-row psec-row--block">
							<div class="psec-row__text">
								<span class="psec-row__title"><?php esc_html_e( 'REST API (wp-json)', 'potamus-security' ); ?></span>
								<p class="psec-row__desc"><?php esc_html_e( 'The REST API is used by the editor, by Elementor and by some plugins. Logged-in users are never affected.', 'potamus-security' ); ?></p>
								<?php echo $rest; // phpcs:ignore ?>
							</div>
						</div>
						<?php
						self::toggle( 'security_headers', __( 'Security headers', 'potamus-security' ), __( 'Tells browsers not to let the site be opened inside other sites (clickjacking) and not to guess file types.', 'potamus-security' ) );
						self::toggle( 'disable_file_edit', __( 'Turn off the file editor', 'potamus-security' ), __( 'Removes the theme and plugin editor from the dashboard. If someone steals a session, they cannot inject code into the site that way.', 'potamus-security' ) );
						self::toggle( 'block_uploads_php', __( 'Block PHP in the uploads folder', 'potamus-security' ), __( 'The images folder should never run code. If an attacker manages to put a .php file there, it will not run.', 'potamus-security' ) );
						self::toggle( 'protect_sensitive', __( 'Protect sensitive files', 'potamus-security' ), __( 'Blocks web access to <code>wp-config.php</code>, <code>.htaccess</code>, <code>debug.log</code>, <code>.env</code>, <code>.git</code> and to backups forgotten in the root (<code>.sql</code>, <code>.zip</code>, <code>.bak</code>). Files in uploads keep working.', 'potamus-security' ) );
						self::toggle( 'disable_indexes', __( 'Turn off directory listing', 'potamus-security' ), __( 'If a folder has no index page, the server stops showing the list of files in it.', 'potamus-security' ) );
						?>
						<p class="psec-help"><?php esc_html_e( '🛟 When you save, the plugin tests the site. If the server does not accept a rule, it automatically restores the previous .htaccess.', 'potamus-security' ); ?></p>
					</div>
				</section>

				<section class="psec-panel" data-panel="appearance">
					<?php self::render_appearance(); ?>
				</section>

				<?php if ( class_exists( 'Potamus_Updates' ) ) : ?>
				<section class="psec-panel" data-panel="updates">
					<?php self::render_updates(); ?>
				</section>
				<?php endif; ?>

				<section class="psec-panel" data-panel="integrity">
					<?php self::render_integrity(); ?>
				</section>

				<div class="psec-actions" hidden>
					<button type="submit" class="button button-primary button-hero"><?php esc_html_e( 'Save changes', 'potamus-security' ); ?></button>
					<button type="button" class="button button-hero psec-recommended"><?php esc_html_e( 'Apply recommended', 'potamus-security' ); ?></button>
					<span class="psec-muted"><?php esc_html_e( 'The LiteSpeed cache is cleared automatically when you save.', 'potamus-security' ); ?></span>
				</div>
			</form>
		</div>
		<?php
	}
}
