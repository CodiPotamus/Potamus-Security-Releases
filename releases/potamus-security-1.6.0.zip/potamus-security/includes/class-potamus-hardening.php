<?php
/**
 * Ocultar WordPress e fechar portas desnecessárias.
 * Cada funcionalidade só se liga se estiver ativa.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Potamus_Hardening {

	public static function init() {
		$s = Potamus_Settings::all();

		if ( $s['disable_file_edit'] && ! defined( 'DISALLOW_FILE_EDIT' ) ) {
			define( 'DISALLOW_FILE_EDIT', true );
		}

		if ( $s['hide_versions'] ) {
			remove_action( 'wp_head', 'wp_generator' );
			add_filter( 'the_generator', '__return_empty_string' );
			add_filter( 'style_loader_src', array( __CLASS__, 'mask_version' ), 9999 );
			add_filter( 'script_loader_src', array( __CLASS__, 'mask_version' ), 9999 );
		}

		if ( $s['clean_head'] ) {
			add_action( 'init', array( __CLASS__, 'clean_head' ) );
			add_filter( 'wp_headers', array( __CLASS__, 'filter_headers' ) );
			add_action( 'send_headers', array( __CLASS__, 'remove_powered_by' ) );
		}

		if ( $s['strip_generators'] ) {
			add_action( 'template_redirect', array( __CLASS__, 'start_buffer' ), 0 );
		}

		if ( $s['block_files'] && ! Potamus_Htaccess::active() ) {
			add_action( 'init', array( __CLASS__, 'block_files_php' ), 0 );
		}

		if ( $s['block_author_enum'] ) {
			add_action( 'init', array( __CLASS__, 'block_author_query' ), 0 );
			add_filter( 'wp_sitemaps_add_provider', array( __CLASS__, 'remove_users_sitemap' ), 10, 2 );
			add_filter( 'oembed_response_data', array( __CLASS__, 'clean_oembed' ) );
		}

		if ( $s['disable_xmlrpc'] ) {
			add_filter( 'xmlrpc_enabled', '__return_false' );
			add_filter( 'pings_open', '__return_false', 9999 );
			add_action( 'plugins_loaded', array( __CLASS__, 'block_xmlrpc' ), 0 );
		}

		if ( 'open' !== $s['rest_mode'] || $s['block_author_enum'] ) {
			add_filter( 'rest_authentication_errors', array( __CLASS__, 'rest_guard' ), 101 );
		}

		if ( $s['security_headers'] && ! Potamus_Htaccess::active() ) {
			add_action( 'send_headers', array( __CLASS__, 'security_headers' ) );
		}
	}

	/** Troca "?ver=6.x" por um código curto: o browser continua a renovar a cache, mas a versão fica escondida. */
	public static function mask_version( $src ) {
		if ( ! $src || false === strpos( $src, 'ver=' ) ) {
			return $src;
		}
		$query = wp_parse_url( $src, PHP_URL_QUERY );
		if ( ! $query ) {
			return $src;
		}
		parse_str( $query, $args );
		if ( empty( $args['ver'] ) ) {
			return $src;
		}
		return add_query_arg( 'ver', substr( md5( $args['ver'] . wp_salt( 'nonce' ) ), 0, 8 ), $src );
	}

	public static function clean_head() {
		remove_action( 'wp_head', 'rsd_link' );
		remove_action( 'wp_head', 'wlwmanifest_link' );
		remove_action( 'wp_head', 'wp_shortlink_wp_head' );
		remove_action( 'wp_head', 'rest_output_link_wp_head' );
		remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
		remove_action( 'template_redirect', 'wp_shortlink_header', 11 );
		remove_action( 'template_redirect', 'rest_output_link_header', 11 );
	}

	public static function filter_headers( $headers ) {
		unset( $headers['X-Pingback'], $headers['X-Powered-By'] );
		return $headers;
	}

	public static function remove_powered_by() {
		if ( function_exists( 'header_remove' ) ) {
			header_remove( 'X-Powered-By' );
		}
	}

	public static function start_buffer() {
		if ( is_feed() || is_robots() || wp_doing_ajax() ) {
			return;
		}
		ob_start( array( __CLASS__, 'strip_generators' ) );
	}

	/** Remove as tags "generator" que o WordPress, o Elementor e outros plugins acrescentam. */
	public static function strip_generators( $html ) {
		if ( ! is_string( $html ) || false === stripos( $html, 'generator' ) ) {
			return $html;
		}
		return preg_replace( '#<meta[^>]+name=["\']generator["\'][^>]*>\s*#i', '', $html );
	}

	private static function request_path() {
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
		$base = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		if ( $base && 0 === strpos( $path, $base ) ) {
			$path = substr( $path, strlen( $base ) );
		}
		return ltrim( strtolower( $path ), '/' );
	}

	/** Alternativa em PHP quando o .htaccess não pode ser usado (os ficheiros estáticos não passam por aqui). */
	public static function block_files_php() {
		if ( in_array( self::request_path(), array( 'readme.html', 'license.txt', 'wp-config-sample.php' ), true ) ) {
			self::not_found();
		}
	}

	public static function block_author_query() {
		if ( is_admin() || ! isset( $_GET['author'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		self::not_found();
	}

	public static function remove_users_sitemap( $provider, $name ) {
		return 'users' === $name ? false : $provider;
	}

	public static function clean_oembed( $data ) {
		unset( $data['author_name'], $data['author_url'] );
		return $data;
	}

	public static function block_xmlrpc() {
		if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
			status_header( 404 );
			nocache_headers();
			exit;
		}
	}

	/**
	 * API REST:
	 *  - "users": esconde a lista de utilizadores a visitantes (recomendado, não parte nada).
	 *  - "private": só utilizadores com sessão iniciada, exceto os plugins da lista de exceções.
	 */
	public static function rest_guard( $result ) {
		// Nota: o WordPress devolve "true" aqui para visitantes sem nonce; só um erro já existente tem prioridade.
		if ( is_wp_error( $result ) || is_user_logged_in() ) {
			return $result;
		}
		$s     = Potamus_Settings::all();
		$route = '';
		if ( isset( $GLOBALS['wp']->query_vars['rest_route'] ) ) {
			$route = (string) $GLOBALS['wp']->query_vars['rest_route'];
		}
		$route = '/' . ltrim( strtolower( $route ), '/' );

		$deny = new WP_Error( 'rest_forbidden', __( 'Unauthorized access.', 'potamus-security' ), array( 'status' => 401 ) );

		if ( ( 'users' === $s['rest_mode'] || $s['block_author_enum'] ) && 0 === strpos( $route, '/wp/v2/users' ) ) {
			return $deny;
		}

		if ( 'private' === $s['rest_mode'] && '/' !== $route ) {
			$allowed = array_filter( explode( "\n", (string) $s['rest_allow'] ) );
			foreach ( $allowed as $ns ) {
				if ( 0 === strpos( $route, '/' . trim( $ns ) ) ) {
					return $result;
				}
			}
			return $deny;
		}

		if ( 'private' === $s['rest_mode'] && '/' === $route ) {
			return $deny;
		}

		return $result;
	}

	public static function security_headers() {
		if ( headers_sent() ) {
			return;
		}
		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
		header( 'Permissions-Policy: camera=(), microphone=(), geolocation=(), interest-cohort=()' );
	}

	/** Envia o visitante para a página 404 normal do tema. */
	public static function not_found() {
		nocache_headers();
		wp_safe_redirect( home_url( '/404/' ), 302 );
		exit;
	}
}
