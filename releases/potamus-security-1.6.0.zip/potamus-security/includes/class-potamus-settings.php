<?php
/**
 * Definições: valores por defeito, leitura e validação.
 * Tudo fica numa única opção, carregada uma vez por pedido.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Potamus_Settings {

	const OPTION = 'potamus_security';

	private static $cache = null;

	/** Valores recomendados. O URL de login começa desligado para ninguém ficar trancado de fora. */
	public static function defaults() {
		return array(
			// Ocultar WordPress.
			'hide_versions'      => 1,
			'clean_head'         => 1,
			'strip_generators'   => 1,
			'block_files'        => 1,
			'block_author_enum'  => 1,
			// Acesso e login.
			'login_enabled'      => 0,
			'login_slug'         => 'entrar',
			'limit_login'        => 1,
			'max_attempts'       => 5,
			'lockout_minutes'    => 30,
			'generic_errors'     => 1,
			'twofa_enabled'      => 1,
			'twofa_force_admins' => 0,
			'ip_source'          => 'remote_addr',
			// Proteções.
			'disable_xmlrpc'     => 1,
			'rest_mode'          => 'users',
			'rest_allow'         => "contact-form-7",
			'security_headers'   => 1,
			'disable_file_edit'  => 1,
			'block_uploads_php'  => 1,
			'protect_sensitive'  => 1,
			'disable_indexes'    => 1,
			// Integridade.
			'integrity_weekly'   => 1,
			// Atualizações.
			'auto_update_self'   => 1,
			'definitions_daily'  => 1,
		) + Potamus_Login_Style::defaults();
	}

	public static function all() {
		if ( null === self::$cache ) {
			$saved       = get_option( self::OPTION, array() );
			self::$cache = wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
		}
		return self::$cache;
	}

	public static function get( $key ) {
		$all = self::all();
		return isset( $all[ $key ] ) ? $all[ $key ] : null;
	}

	public static function flush_cache() {
		self::$cache = null;
	}

	/** Palavras que não podem ser usadas como endereço de login. */
	public static function reserved_slugs() {
		return array( 'wp-admin', 'wp-login', 'wp-login.php', 'login', 'admin', 'dashboard', 'wp-content', 'wp-includes', 'wp-json', 'feed', 'comments', 'xmlrpc', 'xmlrpc.php', 'wp-cron', 'sitemap', 'search', 'page', 'author', 'category', 'tag', '404' );
	}

	public static function sanitize( $input ) {
		$old      = self::all();
		$defaults = self::defaults();
		$input    = is_array( $input ) ? $input : array();
		$clean    = array();

		$toggles = array( 'hide_versions', 'clean_head', 'strip_generators', 'block_files', 'block_author_enum', 'login_enabled', 'limit_login', 'generic_errors', 'disable_xmlrpc', 'security_headers', 'disable_file_edit', 'block_uploads_php', 'protect_sensitive', 'disable_indexes', 'twofa_enabled', 'twofa_force_admins', 'integrity_weekly', 'auto_update_self', 'definitions_daily' );
		foreach ( $toggles as $key ) {
			$clean[ $key ] = empty( $input[ $key ] ) ? 0 : 1;
		}

		$clean['max_attempts']    = isset( $input['max_attempts'] ) ? max( 2, min( 20, absint( $input['max_attempts'] ) ) ) : $defaults['max_attempts'];
		$clean['lockout_minutes'] = isset( $input['lockout_minutes'] ) ? max( 5, min( 1440, absint( $input['lockout_minutes'] ) ) ) : $defaults['lockout_minutes'];

		$sources            = array( 'remote_addr', 'x_forwarded_for', 'x_real_ip', 'cf_connecting_ip' );
		$clean['ip_source'] = ( isset( $input['ip_source'] ) && in_array( $input['ip_source'], $sources, true ) ) ? $input['ip_source'] : 'remote_addr';

		$modes              = array( 'open', 'users', 'private' );
		$clean['rest_mode'] = ( isset( $input['rest_mode'] ) && in_array( $input['rest_mode'], $modes, true ) ) ? $input['rest_mode'] : 'users';

		$allow = isset( $input['rest_allow'] ) ? preg_split( '/[\s,]+/', (string) $input['rest_allow'] ) : array();
		$allow = array_filter( array_map( 'sanitize_key', $allow ) );
		$clean['rest_allow'] = implode( "\n", array_unique( $allow ) );

		// Endereço de login: validar para não criar conflitos com páginas existentes.
		$slug = isset( $input['login_slug'] ) ? sanitize_title( $input['login_slug'] ) : '';
		if ( '' === $slug ) {
			$slug = $old['login_slug'];
		} elseif ( in_array( $slug, self::reserved_slugs(), true ) ) {
			add_settings_error( self::OPTION, 'slug_reserved', sprintf( __( 'The address "%s" is reserved or too obvious. The previous one was kept.', 'potamus-security' ), esc_html( $slug ) ) );
			$slug = $old['login_slug'];
		} elseif ( get_page_by_path( $slug ) ) {
			add_settings_error( self::OPTION, 'slug_taken', sprintf( /* translators: %s: page address. */ __( 'A page with the address "%s" already exists. Please choose another one.', 'potamus-security' ), esc_html( $slug ) ) );
			$slug = $old['login_slug'];
		}
		$clean['login_slug'] = $slug;

		if ( $clean['login_enabled'] && ( ! $old['login_enabled'] || $old['login_slug'] !== $slug ) ) {
			add_settings_error(
				self::OPTION,
				'slug_changed',
				sprintf( /* translators: %s: login address. */ __( 'Your new login address is <strong>%s</strong> — bookmark it before you log out.', 'potamus-security' ), esc_url( home_url( '/' . $slug . '/' ) ) ),
				'warning'
			);
		}

		return Potamus_Login_Style::sanitize( $input, $clean );
	}

	public static function activate() {
		if ( false === get_option( self::OPTION ) ) {
			add_option( self::OPTION, self::defaults() );
		}
		self::flush_cache();
		Potamus_Htaccess::write();
		Potamus_Integrity::sync_schedule();
		if ( Potamus_Definitions::configured() ) {
			Potamus_Definitions::sync_schedule();
			Potamus_Definitions::refresh();
		}
	}

	/**
	 * Edição offline instalada por cima da online: remove os dados das atualizações do
	 * plugin (as definições de ameaças mantêm-se). Corre uma só vez (fica marcada numa opção).
	 */
	public static function offline_cleanup() {
		if ( get_option( 'potamus_security_offline_clean_v2' ) ) {
			return;
		}
		delete_option( 'potamus_security_updates_status' );
		delete_option( 'potamus_security_offline_clean' );
		delete_site_transient( 'potamus_security_manifest' );
		delete_site_transient( 'update_plugins' );
		update_option( 'potamus_security_offline_clean_v2', 1 );
	}

	/**
	 * Edição offline: retira este plugin da lista que o WordPress envia ao WordPress.org
	 * quando procura atualizações. Assim nunca é oferecida uma "atualização" de outro
	 * plugin com o mesmo nome, e o WordPress.org nem sabe que este plugin existe.
	 */
	public static function offline_hide_from_wporg( $args, $url ) {
		if ( false === strpos( $url, 'api.wordpress.org/plugins/update-check/' ) || empty( $args['body']['plugins'] ) ) {
			return $args;
		}
		$data = json_decode( $args['body']['plugins'], true );
		if ( ! is_array( $data ) ) {
			return $args;
		}
		$me = plugin_basename( POTAMUS_SECURITY_FILE );
		unset( $data['plugins'][ $me ] );
		if ( isset( $data['active'] ) && is_array( $data['active'] ) ) {
			$data['active'] = array_values( array_diff( $data['active'], array( $me ) ) );
		}
		$args['body']['plugins'] = wp_json_encode( $data );
		return $args;
	}

	public static function deactivate() {
		Potamus_Htaccess::remove();
		Potamus_Integrity::unschedule();
		wp_clear_scheduled_hook( 'potamus_security_definitions_cron' );
	}
}
