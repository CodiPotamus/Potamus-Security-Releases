<?php
/**
 * Definições de ameaças: padrões de código malicioso e plugins/temas com vulnerabilidades
 * conhecidas, publicados pela CodiPotamus no repositório público e ASSINADOS (Ed25519).
 *
 * Existe nas duas edições do plugin (online e offline). Uma vez por dia descarrega um
 * ficheiro pequeno; a comparação com os plugins instalados é feita no próprio site e
 * nenhuma informação do site é enviada para fora.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Potamus_Definitions {

	const DEFS_OPTION   = 'potamus_security_definitions';
	const STATUS_OPTION = 'potamus_security_definitions_status';
	const CRON_HOOK     = 'potamus_security_definitions_cron';

	/* ---------- Canal (repositório + chave pública) ---------- */

	public static function configured() {
		return self::repo() && self::public_key();
	}

	public static function repo() {
		$repo = defined( 'POTAMUS_UPDATE_REPO' ) ? trim( (string) POTAMUS_UPDATE_REPO ) : '';
		return preg_match( '#^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$#', $repo ) ? $repo : '';
	}

	public static function public_key() {
		$key = defined( 'POTAMUS_SIGNING_PUBLIC_KEY' ) ? base64_decode( (string) POTAMUS_SIGNING_PUBLIC_KEY, true ) : false; // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
		return ( false !== $key && 32 === strlen( $key ) ) ? $key : '';
	}

	/** Endereço base dos ficheiros públicos (pode ser substituído em testes com POTAMUS_UPDATE_BASE). */
	public static function base_url() {
		if ( defined( 'POTAMUS_UPDATE_BASE' ) && POTAMUS_UPDATE_BASE ) {
			return trailingslashit( POTAMUS_UPDATE_BASE );
		}
		return 'https://raw.githubusercontent.com/' . self::repo() . '/main/';
	}

	/** Chave pública só para a lista de ameaças (assinada automaticamente no GitHub). Nunca vale para código. */
	public static function definitions_key() {
		$key = defined( 'POTAMUS_DEFINITIONS_PUBLIC_KEY' ) ? base64_decode( (string) POTAMUS_DEFINITIONS_PUBLIC_KEY, true ) : false; // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
		return ( false !== $key && 32 === strlen( $key ) ) ? $key : '';
	}

	private static function sodium() {
		if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) && file_exists( ABSPATH . WPINC . '/sodium_compat/autoload.php' ) ) {
			require_once ABSPATH . WPINC . '/sodium_compat/autoload.php';
		}
		return function_exists( 'sodium_crypto_sign_verify_detached' );
	}

	/**
	 * Verifica uma assinatura Ed25519 (base64) com a chave de CÓDIGO.
	 * É a única aceite para atualizações do plugin.
	 */
	public static function verify( $message, $signature_b64, $key = null ) {
		$key = null === $key ? self::public_key() : $key;
		$sig = base64_decode( (string) $signature_b64, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
		if ( ! $key || false === $sig || 64 !== strlen( $sig ) || ! self::sodium() ) {
			return false;
		}
		try {
			return sodium_crypto_sign_verify_detached( $sig, (string) $message, $key );
		} catch ( Exception $e ) {
			return false;
		}
	}

	/** Descarrega um ficheiro JSON do repositório público. 404 = "ainda não publicado". */
	public static function fetch_json( $file ) {
		$response = wp_remote_get(
			self::base_url() . $file . '?t=' . floor( time() / 300 ),
			array( 'timeout' => 15 )
		);
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 404 === $code ) {
			return new WP_Error( 'psec_not_published', __( 'Not published yet.', 'potamus-security' ) );
		}
		if ( 200 !== $code ) {
			return new WP_Error( 'psec_http', sprintf( __( 'The server responded with code %d.', 'potamus-security' ), $code ) );
		}
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		return is_array( $data ) ? $data : new WP_Error( 'psec_json', __( 'The file received is not valid.', 'potamus-security' ) );
	}

	/* ---------- Arranque ---------- */

	public static function init() {
		if ( ! self::configured() ) {
			return;
		}
		add_action( self::CRON_HOOK, array( __CLASS__, 'refresh' ) );
		if ( is_admin() ) {
			add_action( 'admin_init', array( __CLASS__, 'sync_schedule' ) );
			add_action( 'admin_post_potamus_defs_now', array( __CLASS__, 'refresh_now' ) );
		}
	}

	public static function sync_schedule() {
		$want = (bool) Potamus_Settings::get( 'definitions_daily' );
		$next = wp_next_scheduled( self::CRON_HOOK );
		if ( $want && ! $next ) {
			// Primeira vez (ou depois de mudar de edição): descarrega já, daqui a um minuto.
			$first = self::definitions() ? 10 * MINUTE_IN_SECONDS : MINUTE_IN_SECONDS;
			wp_schedule_event( time() + $first, 'daily', self::CRON_HOOK );
		} elseif ( ! $want && $next ) {
			wp_clear_scheduled_hook( self::CRON_HOOK );
		}
	}

	public static function unschedule() {
		wp_clear_scheduled_hook( self::CRON_HOOK );
	}

	private static function set_status( $key, $value ) {
		$status         = (array) get_option( self::STATUS_OPTION, array() );
		$status[ $key ] = $value;
		update_option( self::STATUS_OPTION, $status, false );
	}

	public static function status() {
		return (array) get_option( self::STATUS_OPTION, array() );
	}

	/* ---------- Definições ---------- */

	public static function message( $payload ) {
		return 'potamus-security|definitions|' . $payload;
	}

	/** Vai buscar definitions.json, confirma a assinatura e guarda. Nunca aceita uma versão mais antiga. */
	public static function refresh() {
		$wrap = self::fetch_json( 'definitions.json' );
		if ( is_wp_error( $wrap ) && 'psec_not_published' === $wrap->get_error_code() ) {
			self::set_status( 'error', self::definitions() ? '' : __( 'The Threat Radar has not been published yet.', 'potamus-security' ) );
			self::set_status( 'checked', time() );
			return false;
		}
		if ( is_wp_error( $wrap ) ) {
			self::set_status( 'error', $wrap->get_error_message() );
			return false;
		}
		// A lista de ameaças aceita a chave de código (assinatura manual) ou a chave de definições (automática).
		$signed = ! empty( $wrap['payload'] ) && ! empty( $wrap['signature'] ) && is_string( $wrap['payload'] );
		if ( $signed ) {
			$msg    = self::message( $wrap['payload'] );
			$signed = self::verify( $msg, $wrap['signature'] ) || ( self::definitions_key() && self::verify( $msg, $wrap['signature'], self::definitions_key() ) );
		}
		if ( ! $signed ) {
			self::set_status( 'error', __( 'The threat list received does not have a valid signature and was ignored.', 'potamus-security' ) );
			return false;
		}
		$data = json_decode( $wrap['payload'], true );
		if ( ! is_array( $data ) || 'potamus-definitions' !== ( isset( $data['type'] ) ? $data['type'] : '' ) || empty( $data['version'] ) ) {
			self::set_status( 'error', __( 'The threat list received is not in the expected format.', 'potamus-security' ) );
			return false;
		}
		$current = self::definitions();
		if ( $current && version_compare( (string) $data['version'], (string) $current['version'], '<' ) ) {
			self::set_status( 'error', __( 'An older version of the threat list was received and ignored.', 'potamus-security' ) );
			return false;
		}

		$clean = array(
			'version'         => (string) $data['version'],
			'created'         => isset( $data['created'] ) ? (string) $data['created'] : '',
			'sources'         => array(),
			'patterns'        => array(),
			'vulnerabilities' => array(),
		);
		foreach ( (array) ( isset( $data['sources'] ) ? $data['sources'] : array() ) as $src ) {
			if ( empty( $src['name'] ) ) {
				continue;
			}
			$clean['sources'][] = array(
				'name'    => sanitize_text_field( $src['name'] ),
				'url'     => isset( $src['url'] ) ? esc_url_raw( $src['url'] ) : '',
				'license' => isset( $src['license'] ) ? sanitize_text_field( $src['license'] ) : '',
				'notice'  => isset( $src['notice'] ) ? sanitize_text_field( $src['notice'] ) : '',
			);
		}
		foreach ( (array) ( isset( $data['patterns'] ) ? $data['patterns'] : array() ) as $p ) {
			if ( empty( $p['regex'] ) || empty( $p['label'] ) || ! is_string( $p['regex'] ) ) {
				continue;
			}
			if ( false === @preg_match( $p['regex'], '' ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors -- só valida a expressão.
				continue;
			}
			$clean['patterns'][] = array(
				'level' => in_array( isset( $p['level'] ) ? $p['level'] : '', array( 'high', 'medium', 'low' ), true ) ? $p['level'] : 'medium',
				'label' => sanitize_text_field( $p['label'] ),
				'regex' => $p['regex'],
			);
		}
		foreach ( (array) ( isset( $data['vulnerabilities'] ) ? $data['vulnerabilities'] : array() ) as $v ) {
			// Uma entrada precisa do nome da pasta e de pelo menos um limite de versão.
			if ( empty( $v['slug'] ) || ( empty( $v['max_version'] ) && empty( $v['fixed_in'] ) ) ) {
				continue;
			}
			$clean['vulnerabilities'][] = array(
				'type'        => ( isset( $v['type'] ) && 'theme' === $v['type'] ) ? 'theme' : 'plugin',
				'slug'        => sanitize_key( $v['slug'] ),
				'min_version' => isset( $v['min_version'] ) ? sanitize_text_field( $v['min_version'] ) : '',
				'max_version' => isset( $v['max_version'] ) ? sanitize_text_field( $v['max_version'] ) : '',
				'fixed_in'    => isset( $v['fixed_in'] ) ? sanitize_text_field( $v['fixed_in'] ) : '',
				'severity'    => in_array( isset( $v['severity'] ) ? $v['severity'] : '', array( 'critical', 'high', 'medium', 'low' ), true ) ? $v['severity'] : 'medium',
				'title'       => isset( $v['title'] ) ? sanitize_text_field( $v['title'] ) : '',
				'cve'         => isset( $v['cve'] ) ? sanitize_text_field( $v['cve'] ) : '',
				'url'         => isset( $v['url'] ) ? esc_url_raw( $v['url'] ) : '',
				'exploited'   => ! empty( $v['exploited'] ),
			);
		}

		update_option( self::DEFS_OPTION, $clean, false );
		self::set_status( 'error', '' );
		self::set_status( 'checked', time() );
		return true;
	}

	public static function definitions() {
		$d = get_option( self::DEFS_OPTION );
		return is_array( $d ) && ! empty( $d['version'] ) ? $d : null;
	}

	/** Padrões extra para a inspeção de ficheiros (formato: [nível, descrição, expressão]). */
	/**
	 * Nomes dos padrões publicados no Radar de Ameaças (vêm em inglês no ficheiro assinado).
	 * Só existem aqui para entrarem nos ficheiros de tradução; o plugin traduz o nome recebido com translate().
	 */
	public static function remote_labels() {
		return array(
			__( 'Dangerous functions hidden in concatenated text', 'potamus-security' ),
			__( 'Loading code from a remote URL', 'potamus-security' ),
		);
	}

	public static function extra_patterns() {
		$d   = self::definitions();
		$out = array();
		if ( $d ) {
			foreach ( $d['patterns'] as $p ) {
				$out[] = array( $p['level'], $p['label'], $p['regex'] );
			}
		}
		return $out;
	}

	/** Plugins e temas instalados que constam da lista de vulnerabilidades. */
	public static function vulnerable_items() {
		$d = self::definitions();
		if ( ! $d || empty( $d['vulnerabilities'] ) ) {
			return array();
		}
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$installed = array();
		foreach ( get_plugins() as $file => $data ) {
			$slug = dirname( $file );
			$slug = '.' === $slug ? basename( $file, '.php' ) : $slug;
			$installed[ 'plugin:' . $slug ] = array( $data['Name'], $data['Version'] );
		}
		foreach ( wp_get_themes() as $slug => $theme ) {
			$installed[ 'theme:' . $slug ] = array( $theme->get( 'Name' ), $theme->get( 'Version' ) );
		}

		$found = array();
		foreach ( $d['vulnerabilities'] as $v ) {
			$key = $v['type'] . ':' . $v['slug'];
			if ( ! isset( $installed[ $key ] ) ) {
				continue;
			}
			list( $name, $version ) = $installed[ $key ];
			if ( ! $version ) {
				continue;
			}
			// Afetado até "max_version" (inclusive) ou, sem ela, antes de "fixed_in".
			if ( $v['max_version'] ) {
				if ( version_compare( $version, $v['max_version'], '>' ) ) {
					continue;
				}
			} elseif ( ! $v['fixed_in'] || version_compare( $version, $v['fixed_in'], '>=' ) ) {
				continue;
			}
			if ( $v['min_version'] && version_compare( $version, $v['min_version'], '<' ) ) {
				continue;
			}
			$found[] = $v + array( 'name' => $name, 'installed' => $version );
		}
		return $found;
	}

	/* ---------- Ação manual ---------- */

	public static function refresh_now() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( __( 'You do not have permission to do this.', 'potamus-security' ) );
		}
		check_admin_referer( 'potamus_defs_now' );
		self::refresh();
		wp_safe_redirect( admin_url( 'admin.php?page=potamus-security&psec_tab=integrity' ) );
		exit;
	}
}
