<?php
/**
 * Atualizações do próprio plugin (só na edição ONLINE), publicadas no repositório público
 * e ASSINADAS com a chave privada da CodiPotamus (Ed25519).
 *
 * O plugin só instala uma versão nova se a assinatura bater certo com a chave pública.
 * Um servidor comprometido não consegue distribuir código falso.
 * O canal (repositório, chave, verificação) vem de Potamus_Definitions.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Potamus_Updates {

	const MANIFEST_CACHE = 'potamus_security_manifest';
	const STATUS_OPTION  = 'potamus_security_updates_status';

	/* ---------- Canal (partilhado com as definições) ---------- */

	public static function configured() {
		return Potamus_Definitions::configured();
	}

	public static function repo() {
		return Potamus_Definitions::repo();
	}

	public static function verify( $message, $signature_b64 ) {
		// Atualizações do plugin: SÓ a chave de código. A chave de definições nunca é aceite aqui.
		return Potamus_Definitions::verify( $message, $signature_b64, Potamus_Definitions::public_key() );
	}

	private static function fetch_json( $file ) {
		return Potamus_Definitions::fetch_json( $file );
	}

	/* ---------- Arranque ---------- */

	public static function init() {
		if ( ! self::configured() ) {
			return;
		}
		// O cabeçalho "Update URI" do plugin aponta para github.com: o WordPress pergunta-nos a nós, e nunca ao WordPress.org.
		add_filter( 'update_plugins_github.com', array( __CLASS__, 'check_update' ), 10, 3 );
		add_filter( 'plugins_api', array( __CLASS__, 'plugin_details' ), 20, 3 );
		add_filter( 'upgrader_pre_download', array( __CLASS__, 'verified_download' ), 10, 4 );
		add_filter( 'auto_update_plugin', array( __CLASS__, 'auto_update' ), 20, 2 );

		if ( is_admin() ) {
			add_action( 'admin_post_potamus_check_now', array( __CLASS__, 'check_now' ) );
		}
	}

	private static function set_status( $key, $value ) {
		$status         = (array) get_option( self::STATUS_OPTION, array() );
		$status[ $key ] = $value;
		update_option( self::STATUS_OPTION, $status, false );
	}

	public static function status() {
		return (array) get_option( self::STATUS_OPTION, array() );
	}

	/* ---------- Atualizações do plugin ---------- */

	/** Mensagem assinada: inclui a versão, para que um pacote antigo não possa ser reapresentado como novo. */
	public static function update_message( $version, $sha384 ) {
		return 'potamus-security|update|' . $version . '|' . strtolower( $sha384 );
	}

	/** Lê o manifesto (update.json) e confirma a assinatura. Guardado em cache 6 horas. */
	public static function manifest( $force = false ) {
		$cached = get_site_transient( self::MANIFEST_CACHE );
		if ( ! $force && is_array( $cached ) ) {
			return $cached;
		}
		$m = self::fetch_json( 'update.json' );
		// Ainda não há nenhuma versão publicada: não é um erro, a instalada é a mais recente.
		if ( is_wp_error( $m ) && 'psec_not_published' === $m->get_error_code() ) {
			self::set_status( 'update_error', '' );
			self::set_status( 'update_checked', time() );
			self::set_status( 'update_latest', '' );
			return null;
		}
		if ( is_wp_error( $m ) ) {
			self::set_status( 'update_error', $m->get_error_message() );
			return null;
		}
		$valid = isset( $m['version'], $m['package'], $m['sha384'], $m['signature'] )
			&& preg_match( '/^\d+\.\d+(\.\d+)?$/', (string) $m['version'] )
			&& preg_match( '/^[a-f0-9]{96}$/i', (string) $m['sha384'] )
			&& ( 0 === strpos( (string) $m['package'], 'https://' ) || ( defined( 'POTAMUS_UPDATE_BASE' ) && POTAMUS_UPDATE_BASE && 0 === strpos( (string) $m['package'], (string) POTAMUS_UPDATE_BASE ) ) );
		if ( ! $valid ) {
			self::set_status( 'update_error', __( 'The update manifest is incomplete or malformed. The update was ignored.', 'potamus-security' ) );
			return null;
		}
		if ( ! self::verify( self::update_message( $m['version'], $m['sha384'] ), $m['signature'] ) ) {
			self::set_status( 'update_error', __( 'The update manifest signature is not valid. The update was ignored.', 'potamus-security' ) );
			return null;
		}
		self::set_status( 'update_error', '' );
		self::set_status( 'update_checked', time() );
		self::set_status( 'update_latest', (string) $m['version'] );
		set_site_transient( self::MANIFEST_CACHE, $m, 6 * HOUR_IN_SECONDS );
		return $m;
	}

	/** Diz ao WordPress que há uma versão nova (filtro update_plugins_github.com). */
	public static function check_update( $update, $plugin_data, $plugin_file ) {
		if ( plugin_basename( POTAMUS_SECURITY_FILE ) !== $plugin_file ) {
			return $update;
		}
		$m = self::manifest();
		if ( ! $m || version_compare( $m['version'], POTAMUS_SECURITY_VERSION, '<=' ) ) {
			return $update;
		}
		return array(
			'id'           => 'https://github.com/' . self::repo(),
			'slug'         => 'potamus-security',
			'version'      => $m['version'],
			'url'          => 'https://github.com/' . self::repo(),
			'package'      => $m['package'],
			'tested'       => isset( $m['tested'] ) ? (string) $m['tested'] : '',
			'requires_php' => isset( $m['requires_php'] ) ? (string) $m['requires_php'] : '',
			'autoupdate'   => (bool) Potamus_Settings::get( 'auto_update_self' ),
		);
	}

	/** Janela "Ver detalhes" com o registo de alterações. */
	public static function plugin_details( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || 'potamus-security' !== $args->slug ) {
			return $result;
		}
		$m = self::manifest();
		if ( ! $m ) {
			return $result;
		}
		return (object) array(
			'name'          => 'Potamus Security',
			'slug'          => 'potamus-security',
			'version'       => $m['version'],
			'author'        => '<a href="https://codipotamus.site">CodiPotamus</a>',
			'homepage'      => 'https://codipotamus.site',
			'requires'      => isset( $m['requires'] ) ? $m['requires'] : '',
			'tested'        => isset( $m['tested'] ) ? $m['tested'] : '',
			'requires_php'  => isset( $m['requires_php'] ) ? $m['requires_php'] : '',
			'last_updated'  => isset( $m['released'] ) ? $m['released'] : '',
			'download_link' => $m['package'],
			'sections'      => array(
				'changelog' => wpautop( esc_html( isset( $m['changelog'] ) ? (string) $m['changelog'] : '' ) ),
			),
		);
	}

	/**
	 * Antes de instalar, descarrega o pacote e confirma a impressão digital e a assinatura.
	 * Se alguma coisa não bater certo, a instalação é cancelada.
	 */
	public static function verified_download( $reply, $package, $upgrader, $hook_extra = array() ) {
		$ours = ( isset( $hook_extra['plugin'] ) && plugin_basename( POTAMUS_SECURITY_FILE ) === $hook_extra['plugin'] );
		$m    = get_site_transient( self::MANIFEST_CACHE );
		if ( ! $ours && ! ( is_array( $m ) && isset( $m['package'] ) && $m['package'] === $package ) ) {
			return $reply;
		}
		$m = self::manifest( true );
		if ( ! $m || $m['package'] !== $package ) {
			return new WP_Error( 'psec_untrusted', __( 'Potamus Security: the origin of this update could not be confirmed. Installation cancelled.', 'potamus-security' ) );
		}
		if ( version_compare( $m['version'], POTAMUS_SECURITY_VERSION, '<=' ) ) {
			return new WP_Error( 'psec_downgrade', __( 'Potamus Security: the version offered is not newer than the installed one. Installation cancelled.', 'potamus-security' ) );
		}
		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$file = download_url( $package, 300 );
		if ( is_wp_error( $file ) ) {
			return $file;
		}
		$hash = hash_file( 'sha384', $file );
		if ( ! hash_equals( strtolower( $m['sha384'] ), (string) $hash ) || ! self::verify( self::update_message( $m['version'], $hash ), $m['signature'] ) ) {
			wp_delete_file( $file );
			self::set_status( 'update_error', __( 'A downloaded update did not have a valid signature and was rejected.', 'potamus-security' ) );
			return new WP_Error( 'psec_bad_signature', __( 'Potamus Security: the package signature is not valid. Installation cancelled for safety.', 'potamus-security' ) );
		}
		return $file;
	}

	public static function auto_update( $update, $item ) {
		if ( isset( $item->plugin ) && plugin_basename( POTAMUS_SECURITY_FILE ) === $item->plugin && Potamus_Settings::get( 'auto_update_self' ) ) {
			return true;
		}
		return $update;
	}

	/* ---------- Ação manual ---------- */

	public static function check_now() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( __( 'You do not have permission to do this.', 'potamus-security' ) );
		}
		check_admin_referer( 'potamus_check_now' );
		self::manifest( true );
		delete_site_transient( 'update_plugins' );
		wp_update_plugins();
		wp_safe_redirect( admin_url( 'admin.php?page=potamus-security&psec_tab=updates' ) );
		exit;
	}
}
