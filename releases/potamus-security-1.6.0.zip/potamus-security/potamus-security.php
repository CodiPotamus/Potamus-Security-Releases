<?php
/**
 * Plugin Name:       Potamus Security
 * Description:       Lightweight, simple security for WordPress: hides that the site runs WordPress, protects the login and closes unnecessary doors, without slowing the site down.
 * Version:           1.6.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            CodiPotamus
 * Author URI:        https://codipotamus.site
 * License:           GPL-2.0-or-later
 * Text Domain:       potamus-security
 * Domain Path:       /languages
 * Update URI:        https://github.com/CodiPotamus/Potamus-Security-Releases
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'POTAMUS_SECURITY_VERSION', '1.6.0' );
define( 'POTAMUS_SECURITY_FILE', __FILE__ );
define( 'POTAMUS_SECURITY_DIR', plugin_dir_path( __FILE__ ) );
define( 'POTAMUS_SECURITY_URL', plugin_dir_url( __FILE__ ) );

/*
 * Canal da CodiPotamus (preenchido antes de distribuir o plugin).
 * - POTAMUS_UPDATE_REPO: "utilizador/repositório" público no GitHub com definitions.json
 *   (e, na edição online, update.json e os pacotes).
 * - POTAMUS_SIGNING_PUBLIC_KEY: chave PÚBLICA (base64) gerada no Potamus Assinador.
 *   A chave PRIVADA nunca é colocada aqui nem no GitHub.
 * Enquanto estiverem vazios, as definições de ameaças (e as atualizações) ficam desligadas.
 */
if ( ! defined( 'POTAMUS_UPDATE_REPO' ) ) {
	define( 'POTAMUS_UPDATE_REPO', 'CodiPotamus/Potamus-Security-Releases' );
}
if ( ! defined( 'POTAMUS_SIGNING_PUBLIC_KEY' ) ) {
	define( 'POTAMUS_SIGNING_PUBLIC_KEY', 'AM+eE/+l2EqidcWCbfMp5oL0P+HPoLHR6K2hs8vG8eQ=' );
}
// Chave pública de DEFINIÇÕES: só valida a lista de ameaças, assinada automaticamente no GitHub.
// Nunca é aceite para atualizações do plugin.
if ( ! defined( 'POTAMUS_DEFINITIONS_PUBLIC_KEY' ) ) {
	define( 'POTAMUS_DEFINITIONS_PUBLIC_KEY', 'WKwDNsfe8wzXzcMR1xG6PZFx/3Addh/5MdKHbSH/nqc=' );
}

require_once POTAMUS_SECURITY_DIR . 'includes/class-potamus-settings.php';
require_once POTAMUS_SECURITY_DIR . 'includes/class-potamus-htaccess.php';
require_once POTAMUS_SECURITY_DIR . 'includes/class-potamus-hardening.php';
require_once POTAMUS_SECURITY_DIR . 'includes/class-potamus-login.php';
require_once POTAMUS_SECURITY_DIR . 'includes/class-potamus-twofa.php';
require_once POTAMUS_SECURITY_DIR . 'includes/class-potamus-integrity.php';
require_once POTAMUS_SECURITY_DIR . 'includes/class-potamus-login-style.php';
require_once POTAMUS_SECURITY_DIR . 'includes/class-potamus-definitions.php';
// Edição "online": canal de atualizações assinadas. A edição "offline" é distribuída sem este ficheiro.
if ( file_exists( POTAMUS_SECURITY_DIR . 'includes/class-potamus-updates.php' ) ) {
	require_once POTAMUS_SECURITY_DIR . 'includes/class-potamus-updates.php';
}

// Traduções: o plugin está escrito em inglês e inclui português (Portugal e Brasil) na pasta languages.
add_action(
	'init',
	function () {
		load_plugin_textdomain( 'potamus-security', false, dirname( plugin_basename( POTAMUS_SECURITY_FILE ) ) . '/languages' );
	},
	0
);

// Os módulos ligam-se apenas ao que está ativo nas definições: o que está desligado não corre.
Potamus_Hardening::init();
Potamus_Login::init();
Potamus_TwoFA::init();
Potamus_Integrity::init();
Potamus_Login_Style::init();
Potamus_Definitions::init();
if ( class_exists( 'Potamus_Updates' ) ) {
	Potamus_Updates::init();
} else {
	add_action( 'admin_init', array( 'Potamus_Settings', 'offline_cleanup' ) );
	add_filter( 'http_request_args', array( 'Potamus_Settings', 'offline_hide_from_wporg' ), 10, 2 );
}

if ( is_admin() ) {
	require_once POTAMUS_SECURITY_DIR . 'includes/class-potamus-admin.php';
	Potamus_Admin::init();
}

register_activation_hook( __FILE__, array( 'Potamus_Settings', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Potamus_Settings', 'deactivate' ) );
