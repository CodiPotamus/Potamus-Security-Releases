=== Potamus Security ===
Contributors: codipotamus
Tags: security, login, hide wordpress, hardening, 2fa
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.6.0
License: GPLv2 or later

Lightweight, simple security for WordPress.

== Description ==

Potamus Security protects the site without slowing it down:

* Hides that the site runs WordPress (versions, signatures, headers, readme.html).
* Custom login address: wp-login.php and /wp-admin no longer exist for visitors.
* Login attempt limit against brute-force attacks.
* Neutral error messages and hidden usernames.
* Disables XML-RPC and controls the REST API.
* Security headers, file editor turned off and PHP blocked in the uploads folder.
* Protection of sensitive files (wp-config.php, .env, .git, debug.log, backups) and directory listing turned off.
* Two-step verification (2FA) with an authenticator app and recovery codes.
* WordPress file integrity check, on demand or weekly, with inspection of suspicious files.
* Threat Radar: a signed list of malicious code patterns and plugins and themes with known vulnerabilities, built from public sources (CISA KEV and NVD).
* Login page customization: logo and link, background (color, gradient or image), rounded corners and colors, with a live preview.

Languages: English, Portuguese (Portugal) and Portuguese (Brazil). The plugin follows the language of WordPress (or of the user's profile).

Why it is lightweight:

* No new database tables.
* The only external connections are to WordPress.org (integrity check) and to the public Threat Radar file; both can be turned off.
* Blocking rules live in .htaccess (Apache/LiteSpeed) and are applied by the server before WordPress starts.
* Features that are turned off do not run at all.
* Styles and scripts only load on the plugin's own page.

== Locked out? ==

Add this line to wp-config.php, above "That's all, stop editing!":

define( 'POTAMUS_SECURITY_RECOVERY', true );

The login address goes back to wp-login.php and two-step verification is no longer asked. After logging in, remove the line.
Alternatively, rename the folder wp-content/plugins/potamus-security in your host's File Manager.

== Changelog ==

= 1.6.0 =
* New: the plugin is now translatable. It is written in English and includes Portuguese (Portugal, also the 1990 spelling agreement variant) and Portuguese (Brazil). It follows the language of WordPress or of the user's profile, so an English site shows it in English.
* The names of the malicious code patterns published in the Threat Radar are also translated.
* Dates follow the site's date and time format.

= 1.5.2 =
* The "Threat definitions" section is renamed "Threat Radar".
* The Threat Radar can be signed automatically on GitHub with its own key, which is only valid for the threat list. Plugin updates still require the code key.

= 1.5.1 =
* Threat definitions are now built from public, free sources: CISA KEV (CC0) and NVD. The screen shows the sources and the NVD notice.
* New: "Actively exploited" badge for flaws listed in the CISA catalog.
* Support for flaws described only by the version that fixes them.

= 1.5.0 =
* Threat definitions move to the "Integrity & Threats" tab (formerly "Integrity").
* Threat definitions are also available in the offline edition, which still has no automatic plugin updates.

= 1.4.1 =
* When no new version has been published yet, the Updates tab says "You are on the latest version" instead of a 404 error.
* First version distributed through the signed update channel.

= 1.4.0 =
* New: digitally signed automatic updates (Ed25519), published at CodiPotamus/potamus-security-releases.
* New: daily signed threat definitions, with warnings about plugins and themes with known vulnerabilities.
* New: "Updates" tab.

= 1.3.0 =
* New: "Login appearance" tab to customize the logo, link, background, rounded corners and colors of the login page, with a live preview.

= 1.2.1 =
* File inspection opens in a window (lightbox) without leaving the page.

= 1.2.0 =
* New: "Inspect" button on files found by the integrity check. It reads the file as text (without running it), looks for malicious code patterns and shows the content.

= 1.1.4 =
* Fixed: sites installed in English and later switched to another language no longer show false alerts in the integrity check.

= 1.1.3 =
* The note about translated files shows the site's real language.

= 1.1.2 =
* Fixed: on translated WordPress, the integrity check no longer flags files changed by the translation (version.php, wp-config-sample.php, readme.html); they are scanned for suspicious code instead.
* Security: the WordPress version is read without running version.php.

= 1.1.1 =
* New slogan on the dashboard.

= 1.1.0 =
* New: two-step verification (2FA), optionally required for administrators.
* New: WordPress integrity check (manual and weekly).
* New: sensitive file protection and directory listing turned off.
* New: .htaccess self-test, which restores the previous version if the site breaks.
* New: more checks on the Dashboard.

= 1.0.0 =
* First version.
