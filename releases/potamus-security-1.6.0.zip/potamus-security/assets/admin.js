/* Potamus Security — painel (sem dependências) */
(function () {
	var PT = window.PotamusI18n || {};
	var root = document.querySelector('.psec');
	if (!root) return;

	var tabs = root.querySelectorAll('.psec-tab');
	var panels = root.querySelectorAll('.psec-panel');
	var actions = root.querySelector('.psec-actions');

	function show(name) {
		tabs.forEach(function (t) { t.classList.toggle('is-active', t.dataset.tab === name); });
		panels.forEach(function (p) { p.classList.toggle('is-active', p.dataset.panel === name); });
		actions.hidden = name === 'dashboard';
		try { sessionStorage.setItem('psecTab', name); } catch (e) {}
	}

	tabs.forEach(function (t) {
		t.addEventListener('click', function () { show(t.dataset.tab); });
	});

	var start = 'dashboard';
	try { start = sessionStorage.getItem('psecTab') || 'dashboard'; } catch (e) {}
	var fromUrl = new URLSearchParams(window.location.search).get('psec_tab');
	if (fromUrl) start = fromUrl;
	if (!root.querySelector('[data-tab="' + start + '"]')) start = 'dashboard';
	show(start);

	// Escurece os campos extra quando o interruptor está desligado.
	function sync(input) {
		var row = input.closest('.psec-row');
		if (row) row.classList.toggle('is-off', !input.checked);
	}
	root.querySelectorAll('.psec-switch input').forEach(function (i) {
		sync(i);
		i.addEventListener('change', function () { sync(i); });
	});

	// Aplicar recomendado: liga as opções recomendadas sem mexer no endereço de login.
	var rec = root.querySelector('.psec-recommended');
	if (rec && window.PotamusDefaults) {
		rec.addEventListener('click', function () {
			root.querySelectorAll('.psec-switch input').forEach(function (i) {
				var key = i.dataset.key;
				if (key === 'login_enabled' || key.indexOf('ls_') === 0 || !(key in PotamusDefaults)) return;
				i.checked = !!Number(PotamusDefaults[key]);
				sync(i);
			});
			var mode = root.querySelector('input[name$="[rest_mode]"][value="' + PotamusDefaults.rest_mode + '"]');
			if (mode) mode.checked = true;
			rec.textContent = PT.applied;
		});
	}

	// Avisar antes de ativar o login personalizado.
	var login = root.querySelector('input[data-key="login_enabled"]');
	if (login) {
		login.addEventListener('change', function () {
			if (login.checked) {
				var slug = root.querySelector('.psec-slug');
				alert(String(PT.loginAlert).replace('%s', root.querySelector('.psec-prefix').textContent + (slug ? slug.value : '') + '/'));
			}
		});
	}

	// Verificação de integridade: mostrar que está a trabalhar.
	var run = root.querySelector('.psec-run');
	if (run) {
		run.addEventListener('click', function () {
			run.textContent = PT.checking;
			run.classList.add('disabled');
		});
	}

	// Inspeção numa janela (lightbox). Sem JavaScript, o link abre a inspeção na própria página.
	var dialog = document.getElementById('psec-dialog');
	if (dialog && typeof dialog.showModal === 'function' && window.PotamusInspect) {
		var dBody = dialog.querySelector('.psec-dialog__body');
		var dFile = dialog.querySelector('.psec-dialog__file');
		var lastLink = null;

		var closeDialog = function () {
			dialog.close();
		};
		dialog.addEventListener('close', function () {
			document.body.classList.remove('psec-modal-open');
			if (lastLink) lastLink.focus();
		});
		dialog.querySelector('.psec-dialog__close').addEventListener('click', closeDialog);
		// Clicar fora da janela fecha-a.
		dialog.addEventListener('click', function (e) {
			var r = dialog.getBoundingClientRect();
			if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) closeDialog();
		});

		root.querySelectorAll('.psec-inspect-link[data-file]').forEach(function (link) {
			link.addEventListener('click', function (e) {
				e.preventDefault();
				lastLink = link;
				var file = link.dataset.file;
				dFile.textContent = file;
				dBody.innerHTML = '<p class="psec-dialog__loading"></p>';
				dBody.firstChild.textContent = PT.reading;
				document.body.classList.add('psec-modal-open');
				dialog.showModal();
				var url = PotamusInspect.url + '?action=potamus_inspect&_ajax_nonce=' + encodeURIComponent(PotamusInspect.nonce) + '&file=' + encodeURIComponent(file);
				fetch(url, { credentials: 'same-origin' })
					.then(function (r) { return r.json(); })
					.then(function (res) {
						dBody.innerHTML = res && res.data && res.data.html ? res.data.html : '<p>' + PT.inspectFail + '</p>';
					})
					.catch(function () {
						// Se o pedido falhar, abre a versão em página.
						window.location.href = link.href;
					});
			});
		});
	}

	// Copiar endereço de login.
	root.querySelectorAll('[data-copy]').forEach(function (b) {
		b.addEventListener('click', function () {
			var el = root.querySelector(b.dataset.copy);
			if (!el || !navigator.clipboard) return;
			navigator.clipboard.writeText(el.textContent.trim()).then(function () {
				b.textContent = PT.copied;
				setTimeout(function () { b.textContent = 'Copiar'; }, 1800);
			});
		});
	});
})();
